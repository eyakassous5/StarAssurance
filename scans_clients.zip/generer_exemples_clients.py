"""
Génère des exemples de formulaires clients DÉJÀ REMPLIS (cases cochées),
avec un rendu légèrement "photographié" (rotation, grain, ombre légère),
pour tester le script d'analyse sans attendre de vrais scans clients.

Usage : python3 generer_exemples_clients.py
Sortie : dossier scans_clients/ avec plusieurs client_XXX.png
"""

import os
import random
from PIL import Image, ImageDraw, ImageFont, ImageFilter

random.seed(42)

FONT_DIR = "/usr/share/fonts/truetype/dejavu"
FONT_BOLD = os.path.join(FONT_DIR, "DejaVuSans-Bold.ttf")
FONT_REG = os.path.join(FONT_DIR, "DejaVuSans.ttf")
FONT_OBLIQUE = os.path.join(FONT_DIR, "DejaVuSans-Oblique.ttf")

GREEN = (30, 107, 60)
DARK = (26, 26, 26)
GREY = (110, 110, 110)
LINE = (190, 190, 190)
WHITE = (255, 255, 255)

SECTIONS = [
    ("TYPE DE QUITTANCE", ["C - Comptant", "R - Reglement", "T - Terme"]),
    ("SOUS-BRANCHE PRODUIT", ["Individuel a la carte", "Trik Slema",
                              "Vehicule etranger", "Flottes"]),
    ("TYPE DE PACK", ["Inconnu", "SECURITE", "SECURITE +",
                       "SERENITE", "SUPER SECURITE"]),
]

W, H = 1240, 1754  # ~A4 à 150 DPI
MARGIN = 90


def dessiner_formulaire(nom_client, choix_index, angle=0.0, bruit=0.0):
    """choix_index: liste de 3 index (un par section) indiquant la case cochée."""
    img = Image.new("RGB", (W, H), WHITE)
    draw = ImageDraw.Draw(img)

    f_title = ImageFont.truetype(FONT_BOLD, 40)
    f_subtitle = ImageFont.truetype(FONT_REG, 22)
    f_section = ImageFont.truetype(FONT_BOLD, 26)
    f_option = ImageFont.truetype(FONT_REG, 24)
    f_small = ImageFont.truetype(FONT_REG, 18)
    f_footer = ImageFont.truetype(FONT_OBLIQUE, 16)

    # Header
    draw.rectangle([0, 0, W, 130], fill=GREEN)
    draw.text((MARGIN, 30), "FICHE CLIENT — QUITTANCE D'ASSURANCE", font=f_title, fill=WHITE)
    draw.text((MARGIN, 90), "A remplir par le client (cocher une case par section)", font=f_subtitle, fill=WHITE)

    # Client info
    y = 175
    for label, x, w in [("NOM DU CLIENT", MARGIN, 380), ("N° POLICE", MARGIN + 420, 260), ("DATE", MARGIN + 720, 180)]:
        draw.text((x, y), label, font=f_small, fill=GREY)
        draw.line([(x, y + 30), (x + w, y + 30)], fill=LINE, width=2)
    draw.text((MARGIN, y + 32), nom_client, font=f_option, fill=DARK)

    y = 260
    box = 34
    for (titre, options), coche in zip(SECTIONS, choix_index):
        draw.text((MARGIN, y), titre, font=f_section, fill=GREEN)
        draw.line([(MARGIN, y + 36), (W - MARGIN, y + 36)], fill=GREEN, width=3)
        y += 65
        for i, opt in enumerate(options):
            draw.rectangle([MARGIN, y, MARGIN + box, y + box], outline=DARK, width=3)
            if i == coche:
                # coche à la main (ligne brisée type "check")
                draw.line([(MARGIN + 6, y + 18), (MARGIN + 14, y + 27),
                           (MARGIN + 29, y + 6)], fill=DARK, width=4, joint="curve")
            draw.text((MARGIN + box + 20, y + 2), opt, font=f_option, fill=DARK)
            y += 55
        y += 25

    # Signature
    draw.line([(MARGIN, y), (MARGIN + 260, y)], fill=LINE, width=2)
    draw.text((MARGIN, y + 8), "SIGNATURE DU CLIENT", font=f_small, fill=GREY)
    draw.line([(MARGIN + 340, y), (MARGIN + 560, y)], fill=LINE, width=2)
    draw.text((MARGIN + 340, y + 8), "CACHET / AGENCE", font=f_small, fill=GREY)

    draw.text((MARGIN, H - 60),
              "Document a remplir a la main puis a numeriser/photographier pour traitement automatique.",
              font=f_footer, fill=GREY)

    # --- rendu "photo" léger ---
    if angle:
        img = img.rotate(angle, expand=True, fillcolor=WHITE, resample=Image.BICUBIC)
    if bruit:
        img = img.filter(ImageFilter.GaussianBlur(radius=bruit))
    return img


if __name__ == "__main__":
    os.makedirs("scans_clients", exist_ok=True)

    # (nom, index coché par section, angle photo, flou léger)
    clients = [
        ("Ahmed Ben Salah",    [0, 1, 2], 0.0, 0.0),
        ("Sonia Trabelsi",     [0, 1, 2], 0.6, 0.3),
        ("Karim Jaziri",       [2, 3, 4], -0.8, 0.4),
        ("Mouna Gharbi",       [1, 0, 1], 0.0, 0.0),
        ("Walid Cherif",       [0, 1, 2], 1.2, 0.5),
        ("Amel Ferjani",       [2, 1, 2], -0.4, 0.2),
        ("Nizar Bouzid",       [0, 3, 3], 0.0, 0.3),
        ("Rania Hamdi",        [2, 1, 2], 0.5, 0.0),
    ]

    for i, (nom, choix, angle, bruit) in enumerate(clients, start=1):
        img = dessiner_formulaire(nom, choix, angle=angle, bruit=bruit)
        chemin = f"scans_clients/client_{i:03d}.png"
        img.save(chemin)
        print(f"Généré : {chemin}  (nom={nom}, choix par section={choix})")

    print("\nTerminé. Dossier 'scans_clients/' prêt à être utilisé avec le script d'analyse.")
