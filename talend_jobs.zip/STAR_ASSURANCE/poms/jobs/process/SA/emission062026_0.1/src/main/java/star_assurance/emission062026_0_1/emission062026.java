// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.

package star_assurance.emission062026_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: emission062026 Purpose: <br>
 * Description: <br>
 * 
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status
 */
public class emission062026 implements TalendJob {

	protected static void logIgnoredError(String message, Throwable cause) {
		System.err.println(message);
		if (cause != null) {
			cause.printStackTrace();
		}

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "emission062026";
	private final String projectName = "STAR_ASSURANCE";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					emission062026.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(emission062026.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tFileInputExcel_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputExcel_2_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_STAR_ASSURANCE_emission062026 = new byte[0];
		static byte[] commonByteArray_STAR_ASSURANCE_emission062026 = new byte[0];

		public Integer ARRETE_AU;

		public Integer getARRETE_AU() {
			return this.ARRETE_AU;
		}

		public String BRANCHE;

		public String getBRANCHE() {
			return this.BRANCHE;
		}

		public String POLICE;

		public String getPOLICE() {
			return this.POLICE;
		}

		public java.util.Date EFFET_ORIGINE;

		public java.util.Date getEFFET_ORIGINE() {
			return this.EFFET_ORIGINE;
		}

		public java.util.Date EFFET_COURANTE;

		public java.util.Date getEFFET_COURANTE() {
			return this.EFFET_COURANTE;
		}

		public java.util.Date ECHEANCE_ORIGINE;

		public java.util.Date getECHEANCE_ORIGINE() {
			return this.ECHEANCE_ORIGINE;
		}

		public java.util.Date ECHEANCE_COURANTE;

		public java.util.Date getECHEANCE_COURANTE() {
			return this.ECHEANCE_COURANTE;
		}

		public String DATE_RESILIATION;

		public String getDATE_RESILIATION() {
			return this.DATE_RESILIATION;
		}

		public Integer PT_DE_VENTE;

		public Integer getPT_DE_VENTE() {
			return this.PT_DE_VENTE;
		}

		public String TYPE_POINT_VENTE;

		public String getTYPE_POINT_VENTE() {
			return this.TYPE_POINT_VENTE;
		}

		public String TYPE_PACK;

		public String getTYPE_PACK() {
			return this.TYPE_PACK;
		}

		public Integer CODE_PRODUIT;

		public Integer getCODE_PRODUIT() {
			return this.CODE_PRODUIT;
		}

		public Integer CODE_USAGE;

		public Integer getCODE_USAGE() {
			return this.CODE_USAGE;
		}

		public String TACITE_RECONDUCTION;

		public String getTACITE_RECONDUCTION() {
			return this.TACITE_RECONDUCTION;
		}

		public String FRACTIONNEMENT;

		public String getFRACTIONNEMENT() {
			return this.FRACTIONNEMENT;
		}

		public String TYPE_POLICE;

		public String getTYPE_POLICE() {
			return this.TYPE_POLICE;
		}

		public String REGION_COMMERCIALE;

		public String getREGION_COMMERCIALE() {
			return this.REGION_COMMERCIALE;
		}

		public Integer ANNULATION_MEME_JOUR;

		public Integer getANNULATION_MEME_JOUR() {
			return this.ANNULATION_MEME_JOUR;
		}

		public Integer ENVIGUEUR;

		public Integer getENVIGUEUR() {
			return this.ENVIGUEUR;
		}

		public Integer RESILIE;

		public Integer getRESILIE() {
			return this.RESILIE;
		}

		public Integer SUSPENDU;

		public Integer getSUSPENDU() {
			return this.SUSPENDU;
		}

		public Integer ETTEINT;

		public Integer getETTEINT() {
			return this.ETTEINT;
		}

		public Integer AFFAIRE_NOUVELLE_DU_MOIS;

		public Integer getAFFAIRE_NOUVELLE_DU_MOIS() {
			return this.AFFAIRE_NOUVELLE_DU_MOIS;
		}

		public Integer AFFAIRE_NOUVELLE_AFIN_DU_MOIS;

		public Integer getAFFAIRE_NOUVELLE_AFIN_DU_MOIS() {
			return this.AFFAIRE_NOUVELLE_AFIN_DU_MOIS;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_emission062026.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_emission062026.length == 0) {
						commonByteArray_STAR_ASSURANCE_emission062026 = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_emission062026 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_STAR_ASSURANCE_emission062026, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_emission062026, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_emission062026.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_emission062026.length == 0) {
						commonByteArray_STAR_ASSURANCE_emission062026 = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_emission062026 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_STAR_ASSURANCE_emission062026, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_emission062026, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_emission062026) {

				try {

					int length = 0;

					this.ARRETE_AU = readInteger(dis);

					this.BRANCHE = readString(dis);

					this.POLICE = readString(dis);

					this.EFFET_ORIGINE = readDate(dis);

					this.EFFET_COURANTE = readDate(dis);

					this.ECHEANCE_ORIGINE = readDate(dis);

					this.ECHEANCE_COURANTE = readDate(dis);

					this.DATE_RESILIATION = readString(dis);

					this.PT_DE_VENTE = readInteger(dis);

					this.TYPE_POINT_VENTE = readString(dis);

					this.TYPE_PACK = readString(dis);

					this.CODE_PRODUIT = readInteger(dis);

					this.CODE_USAGE = readInteger(dis);

					this.TACITE_RECONDUCTION = readString(dis);

					this.FRACTIONNEMENT = readString(dis);

					this.TYPE_POLICE = readString(dis);

					this.REGION_COMMERCIALE = readString(dis);

					this.ANNULATION_MEME_JOUR = readInteger(dis);

					this.ENVIGUEUR = readInteger(dis);

					this.RESILIE = readInteger(dis);

					this.SUSPENDU = readInteger(dis);

					this.ETTEINT = readInteger(dis);

					this.AFFAIRE_NOUVELLE_DU_MOIS = readInteger(dis);

					this.AFFAIRE_NOUVELLE_AFIN_DU_MOIS = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_emission062026) {

				try {

					int length = 0;

					this.ARRETE_AU = readInteger(dis);

					this.BRANCHE = readString(dis);

					this.POLICE = readString(dis);

					this.EFFET_ORIGINE = readDate(dis);

					this.EFFET_COURANTE = readDate(dis);

					this.ECHEANCE_ORIGINE = readDate(dis);

					this.ECHEANCE_COURANTE = readDate(dis);

					this.DATE_RESILIATION = readString(dis);

					this.PT_DE_VENTE = readInteger(dis);

					this.TYPE_POINT_VENTE = readString(dis);

					this.TYPE_PACK = readString(dis);

					this.CODE_PRODUIT = readInteger(dis);

					this.CODE_USAGE = readInteger(dis);

					this.TACITE_RECONDUCTION = readString(dis);

					this.FRACTIONNEMENT = readString(dis);

					this.TYPE_POLICE = readString(dis);

					this.REGION_COMMERCIALE = readString(dis);

					this.ANNULATION_MEME_JOUR = readInteger(dis);

					this.ENVIGUEUR = readInteger(dis);

					this.RESILIE = readInteger(dis);

					this.SUSPENDU = readInteger(dis);

					this.ETTEINT = readInteger(dis);

					this.AFFAIRE_NOUVELLE_DU_MOIS = readInteger(dis);

					this.AFFAIRE_NOUVELLE_AFIN_DU_MOIS = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.ARRETE_AU, dos);

				// String

				writeString(this.BRANCHE, dos);

				// String

				writeString(this.POLICE, dos);

				// java.util.Date

				writeDate(this.EFFET_ORIGINE, dos);

				// java.util.Date

				writeDate(this.EFFET_COURANTE, dos);

				// java.util.Date

				writeDate(this.ECHEANCE_ORIGINE, dos);

				// java.util.Date

				writeDate(this.ECHEANCE_COURANTE, dos);

				// String

				writeString(this.DATE_RESILIATION, dos);

				// Integer

				writeInteger(this.PT_DE_VENTE, dos);

				// String

				writeString(this.TYPE_POINT_VENTE, dos);

				// String

				writeString(this.TYPE_PACK, dos);

				// Integer

				writeInteger(this.CODE_PRODUIT, dos);

				// Integer

				writeInteger(this.CODE_USAGE, dos);

				// String

				writeString(this.TACITE_RECONDUCTION, dos);

				// String

				writeString(this.FRACTIONNEMENT, dos);

				// String

				writeString(this.TYPE_POLICE, dos);

				// String

				writeString(this.REGION_COMMERCIALE, dos);

				// Integer

				writeInteger(this.ANNULATION_MEME_JOUR, dos);

				// Integer

				writeInteger(this.ENVIGUEUR, dos);

				// Integer

				writeInteger(this.RESILIE, dos);

				// Integer

				writeInteger(this.SUSPENDU, dos);

				// Integer

				writeInteger(this.ETTEINT, dos);

				// Integer

				writeInteger(this.AFFAIRE_NOUVELLE_DU_MOIS, dos);

				// Integer

				writeInteger(this.AFFAIRE_NOUVELLE_AFIN_DU_MOIS, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.ARRETE_AU, dos);

				// String

				writeString(this.BRANCHE, dos);

				// String

				writeString(this.POLICE, dos);

				// java.util.Date

				writeDate(this.EFFET_ORIGINE, dos);

				// java.util.Date

				writeDate(this.EFFET_COURANTE, dos);

				// java.util.Date

				writeDate(this.ECHEANCE_ORIGINE, dos);

				// java.util.Date

				writeDate(this.ECHEANCE_COURANTE, dos);

				// String

				writeString(this.DATE_RESILIATION, dos);

				// Integer

				writeInteger(this.PT_DE_VENTE, dos);

				// String

				writeString(this.TYPE_POINT_VENTE, dos);

				// String

				writeString(this.TYPE_PACK, dos);

				// Integer

				writeInteger(this.CODE_PRODUIT, dos);

				// Integer

				writeInteger(this.CODE_USAGE, dos);

				// String

				writeString(this.TACITE_RECONDUCTION, dos);

				// String

				writeString(this.FRACTIONNEMENT, dos);

				// String

				writeString(this.TYPE_POLICE, dos);

				// String

				writeString(this.REGION_COMMERCIALE, dos);

				// Integer

				writeInteger(this.ANNULATION_MEME_JOUR, dos);

				// Integer

				writeInteger(this.ENVIGUEUR, dos);

				// Integer

				writeInteger(this.RESILIE, dos);

				// Integer

				writeInteger(this.SUSPENDU, dos);

				// Integer

				writeInteger(this.ETTEINT, dos);

				// Integer

				writeInteger(this.AFFAIRE_NOUVELLE_DU_MOIS, dos);

				// Integer

				writeInteger(this.AFFAIRE_NOUVELLE_AFIN_DU_MOIS, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("ARRETE_AU=" + String.valueOf(ARRETE_AU));
			sb.append(",BRANCHE=" + BRANCHE);
			sb.append(",POLICE=" + POLICE);
			sb.append(",EFFET_ORIGINE=" + String.valueOf(EFFET_ORIGINE));
			sb.append(",EFFET_COURANTE=" + String.valueOf(EFFET_COURANTE));
			sb.append(",ECHEANCE_ORIGINE=" + String.valueOf(ECHEANCE_ORIGINE));
			sb.append(",ECHEANCE_COURANTE=" + String.valueOf(ECHEANCE_COURANTE));
			sb.append(",DATE_RESILIATION=" + DATE_RESILIATION);
			sb.append(",PT_DE_VENTE=" + String.valueOf(PT_DE_VENTE));
			sb.append(",TYPE_POINT_VENTE=" + TYPE_POINT_VENTE);
			sb.append(",TYPE_PACK=" + TYPE_PACK);
			sb.append(",CODE_PRODUIT=" + String.valueOf(CODE_PRODUIT));
			sb.append(",CODE_USAGE=" + String.valueOf(CODE_USAGE));
			sb.append(",TACITE_RECONDUCTION=" + TACITE_RECONDUCTION);
			sb.append(",FRACTIONNEMENT=" + FRACTIONNEMENT);
			sb.append(",TYPE_POLICE=" + TYPE_POLICE);
			sb.append(",REGION_COMMERCIALE=" + REGION_COMMERCIALE);
			sb.append(",ANNULATION_MEME_JOUR=" + String.valueOf(ANNULATION_MEME_JOUR));
			sb.append(",ENVIGUEUR=" + String.valueOf(ENVIGUEUR));
			sb.append(",RESILIE=" + String.valueOf(RESILIE));
			sb.append(",SUSPENDU=" + String.valueOf(SUSPENDU));
			sb.append(",ETTEINT=" + String.valueOf(ETTEINT));
			sb.append(",AFFAIRE_NOUVELLE_DU_MOIS=" + String.valueOf(AFFAIRE_NOUVELLE_DU_MOIS));
			sb.append(",AFFAIRE_NOUVELLE_AFIN_DU_MOIS=" + String.valueOf(AFFAIRE_NOUVELLE_AFIN_DU_MOIS));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputExcel_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputExcel_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();

				/**
				 * [tDBOutput_1 begin ] start
				 */

				ok_Hash.put("tDBOutput_1", false);
				start_Hash.put("tDBOutput_1", System.currentTimeMillis());

				currentComponent = "tDBOutput_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row1");
				}

				int tos_count_tDBOutput_1 = 0;

				int nb_line_tDBOutput_1 = 0;
				int nb_line_update_tDBOutput_1 = 0;
				int nb_line_inserted_tDBOutput_1 = 0;
				int nb_line_deleted_tDBOutput_1 = 0;
				int nb_line_rejected_tDBOutput_1 = 0;

				int deletedCount_tDBOutput_1 = 0;
				int updatedCount_tDBOutput_1 = 0;
				int insertedCount_tDBOutput_1 = 0;
				int rowsToCommitCount_tDBOutput_1 = 0;
				int rejectedCount_tDBOutput_1 = 0;
				String dbschema_tDBOutput_1 = null;
				String tableName_tDBOutput_1 = null;
				boolean whetherReject_tDBOutput_1 = false;

				java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar.getInstance();
				long year1_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_1;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_1 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_1 = null;
				String dbUser_tDBOutput_1 = null;
				dbschema_tDBOutput_1 = "dbo";
				String driverClass_tDBOutput_1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";

				java.lang.Class.forName(driverClass_tDBOutput_1);
				String port_tDBOutput_1 = "1433";
				String dbname_tDBOutput_1 = "AUTO_SA";
				String url_tDBOutput_1 = "jdbc:sqlserver://" + "DESKTOP-6EEKMMP";
				if (!"".equals(port_tDBOutput_1)) {
					url_tDBOutput_1 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_1)) {
					url_tDBOutput_1 += ";databaseName=" + "AUTO_SA";

				}
				url_tDBOutput_1 += ";appName=" + projectName + ";" + "trustServerCertificate=true";
				dbUser_tDBOutput_1 = "talend_user";

				final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:ZlIJVRAHtMi/EB7yFXEAc2WwueRl4Bnqb3UIt6tBcLzqdCpti+8=");

				String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;
				conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1, dbUser_tDBOutput_1,
						dbPwd_tDBOutput_1);

				resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);

				conn_tDBOutput_1.setAutoCommit(false);
				int commitEvery_tDBOutput_1 = 10000;
				int commitCounter_tDBOutput_1 = 0;

				int batchSize_tDBOutput_1 = 10000;
				int batchSizeCounter_tDBOutput_1 = 0;

				if (dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
					tableName_tDBOutput_1 = "SA_NombreEmission";
				} else {
					tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "].[" + "SA_NombreEmission";
				}
				int count_tDBOutput_1 = 0;

				try (java.sql.Statement stmtClear_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
					stmtClear_tDBOutput_1.executeUpdate("DELETE FROM [" + tableName_tDBOutput_1 + "]");
				}
				String insert_tDBOutput_1 = "INSERT INTO [" + tableName_tDBOutput_1
						+ "] ([ARRETE_AU],[BRANCHE],[POLICE],[EFFET_ORIGINE],[EFFET_COURANTE],[ECHEANCE_ORIGINE],[ECHEANCE_COURANTE],[DATE_RESILIATION],[PT_DE_VENTE],[TYPE_POINT_VENTE],[TYPE_PACK],[CODE_PRODUIT],[CODE_USAGE],[TACITE_RECONDUCTION],[FRACTIONNEMENT],[TYPE_POLICE],[REGION_COMMERCIALE],[ANNULATION_MEME_JOUR],[ENVIGUEUR],[RESILIE],[SUSPENDU],[ETTEINT],[AFFAIRE_NOUVELLE_DU_MOIS],[AFFAIRE_NOUVELLE_AFIN_DU_MOIS]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);

				/**
				 * [tDBOutput_1 begin ] stop
				 */

				/**
				 * [tFileInputExcel_2 begin ] start
				 */

				ok_Hash.put("tFileInputExcel_2", false);
				start_Hash.put("tFileInputExcel_2", System.currentTimeMillis());

				currentComponent = "tFileInputExcel_2";

				int tos_count_tFileInputExcel_2 = 0;

				final String decryptedPassword_tFileInputExcel_2 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:PcWo6cZCo64kURtByBvSac96vGZPAnKopP7tqw==");
				String password_tFileInputExcel_2 = decryptedPassword_tFileInputExcel_2;
				if (password_tFileInputExcel_2.isEmpty()) {
					password_tFileInputExcel_2 = null;
				}
				Object source_tFileInputExcel_2 = "C:/Users/Mega Pc/Desktop/stage_4eme_STAR_assurance/donnees2/RapportNombre_Afin_062026_Stag2.xlsx";
				com.talend.excel.xssf.event.ExcelReader excelReader_tFileInputExcel_2 = null;

				if (source_tFileInputExcel_2 instanceof java.io.InputStream
						|| source_tFileInputExcel_2 instanceof String) {
					excelReader_tFileInputExcel_2 = new com.talend.excel.xssf.event.ExcelReader();
					excelReader_tFileInputExcel_2.setIncludePhoneticRuns(true);
				} else {
					throw new java.lang.Exception("The data source should be specified as Inputstream or File Path!");
				}

				try {
					excelReader_tFileInputExcel_2.addSheetName(".*", true);
					int start_column_tFileInputExcel_2 = 1 - 1;
					int end_column_tFileInputExcel_2 = -1;
					if (start_column_tFileInputExcel_2 >= 0) {// follow start column

						end_column_tFileInputExcel_2 = start_column_tFileInputExcel_2 + 24 - 1;

					} else if (end_column_tFileInputExcel_2 >= 0) {// follow end column
						start_column_tFileInputExcel_2 = end_column_tFileInputExcel_2 - 24 + 1;
					}

					if (end_column_tFileInputExcel_2 < 0 || start_column_tFileInputExcel_2 < 0) {
						throw new RuntimeException("Error start column and end column.");
					}
					int actual_end_column_tFileInputExcel_2 = end_column_tFileInputExcel_2;

					int header_tFileInputExcel_2 = 1;
					int limit_tFileInputExcel_2 = -1;

					int nb_line_tFileInputExcel_2 = 0;

					// for the number format
					java.text.DecimalFormat df_tFileInputExcel_2 = new java.text.DecimalFormat(
							"#.####################################");
					char decimalChar_tFileInputExcel_2 = df_tFileInputExcel_2.getDecimalFormatSymbols()
							.getDecimalSeparator();

					excelReader_tFileInputExcel_2.addDateFormat(3,
							new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
					excelReader_tFileInputExcel_2.addDateFormat(4,
							new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
					excelReader_tFileInputExcel_2.addDateFormat(5,
							new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
					excelReader_tFileInputExcel_2.addDateFormat(6,
							new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));

					if (source_tFileInputExcel_2 instanceof String) {
						excelReader_tFileInputExcel_2.parse((String) source_tFileInputExcel_2, "UTF-8",
								password_tFileInputExcel_2);
					} else if (source_tFileInputExcel_2 instanceof java.io.InputStream) {
						excelReader_tFileInputExcel_2.parse((java.io.InputStream) source_tFileInputExcel_2, "UTF-8",
								password_tFileInputExcel_2);
					}

					while ((header_tFileInputExcel_2--) > 0 && excelReader_tFileInputExcel_2.hasNext()) {// skip the
																											// header
						excelReader_tFileInputExcel_2.next();
					}

					while (excelReader_tFileInputExcel_2.hasNext()) {
						int emptyColumnCount_tFileInputExcel_2 = 0;

						if (limit_tFileInputExcel_2 != -1 && nb_line_tFileInputExcel_2 >= limit_tFileInputExcel_2) {
							excelReader_tFileInputExcel_2.stopRead();
							break;
						}

						java.util.List<String> row_tFileInputExcel_2 = excelReader_tFileInputExcel_2.next();
						row1 = null;
						int tempRowLength_tFileInputExcel_2 = 24;

						int columnIndex_tFileInputExcel_2 = 0;

						String[] temp_row_tFileInputExcel_2 = new String[tempRowLength_tFileInputExcel_2];

						for (int i_tFileInputExcel_2 = 0; i_tFileInputExcel_2 < tempRowLength_tFileInputExcel_2; i_tFileInputExcel_2++) {
							int current_tFileInputExcel_2 = i_tFileInputExcel_2 + start_column_tFileInputExcel_2;
							if (current_tFileInputExcel_2 <= actual_end_column_tFileInputExcel_2) {
								if (current_tFileInputExcel_2 < row_tFileInputExcel_2.size()) {
									String column_tFileInputExcel_2 = row_tFileInputExcel_2
											.get(current_tFileInputExcel_2);
									if (column_tFileInputExcel_2 != null) {
										temp_row_tFileInputExcel_2[i_tFileInputExcel_2] = column_tFileInputExcel_2;
									} else {
										temp_row_tFileInputExcel_2[i_tFileInputExcel_2] = "";
									}
								} else {
									temp_row_tFileInputExcel_2[i_tFileInputExcel_2] = "";
								}
							} else {
								temp_row_tFileInputExcel_2[i_tFileInputExcel_2] = "";
							}
						}

						boolean whetherReject_tFileInputExcel_2 = false;
						row1 = new row1Struct();
						int curColNum_tFileInputExcel_2 = -1;
						String curColName_tFileInputExcel_2 = "";

						try {
							columnIndex_tFileInputExcel_2 = 0;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "ARRETE_AU";

								row1.ARRETE_AU = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(
										temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2], null,
										'.' == decimalChar_tFileInputExcel_2 ? null : decimalChar_tFileInputExcel_2));
							} else {
								row1.ARRETE_AU = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 1;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "BRANCHE";

								row1.BRANCHE = temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2];
							} else {
								row1.BRANCHE = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 2;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "POLICE";

								row1.POLICE = temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2];
							} else {
								row1.POLICE = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 3;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "EFFET_ORIGINE";

								try {
									row1.EFFET_ORIGINE = ParserUtils.parseTo_Date(
											temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2],
											"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
								} catch (java.lang.Exception e) {
									globalMap.put("tFileInputExcel_2_ERROR_MESSAGE", e.getMessage());

									throw new RuntimeException(
											"The cell format is not Date in ( Row. " + (nb_line_tFileInputExcel_2 + 1)
													+ " and ColumnNum. " + curColNum_tFileInputExcel_2 + " )");
								}

							} else {
								row1.EFFET_ORIGINE = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 4;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "EFFET_COURANTE";

								try {
									row1.EFFET_COURANTE = ParserUtils.parseTo_Date(
											temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2],
											"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
								} catch (java.lang.Exception e) {
									globalMap.put("tFileInputExcel_2_ERROR_MESSAGE", e.getMessage());

									throw new RuntimeException(
											"The cell format is not Date in ( Row. " + (nb_line_tFileInputExcel_2 + 1)
													+ " and ColumnNum. " + curColNum_tFileInputExcel_2 + " )");
								}

							} else {
								row1.EFFET_COURANTE = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 5;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "ECHEANCE_ORIGINE";

								try {
									row1.ECHEANCE_ORIGINE = ParserUtils.parseTo_Date(
											temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2],
											"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
								} catch (java.lang.Exception e) {
									globalMap.put("tFileInputExcel_2_ERROR_MESSAGE", e.getMessage());

									throw new RuntimeException(
											"The cell format is not Date in ( Row. " + (nb_line_tFileInputExcel_2 + 1)
													+ " and ColumnNum. " + curColNum_tFileInputExcel_2 + " )");
								}

							} else {
								row1.ECHEANCE_ORIGINE = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 6;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "ECHEANCE_COURANTE";

								try {
									row1.ECHEANCE_COURANTE = ParserUtils.parseTo_Date(
											temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2],
											"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
								} catch (java.lang.Exception e) {
									globalMap.put("tFileInputExcel_2_ERROR_MESSAGE", e.getMessage());

									throw new RuntimeException(
											"The cell format is not Date in ( Row. " + (nb_line_tFileInputExcel_2 + 1)
													+ " and ColumnNum. " + curColNum_tFileInputExcel_2 + " )");
								}

							} else {
								row1.ECHEANCE_COURANTE = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 7;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "DATE_RESILIATION";

								row1.DATE_RESILIATION = temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2];
							} else {
								row1.DATE_RESILIATION = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 8;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "PT_DE_VENTE";

								row1.PT_DE_VENTE = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(
										temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2], null,
										'.' == decimalChar_tFileInputExcel_2 ? null : decimalChar_tFileInputExcel_2));
							} else {
								row1.PT_DE_VENTE = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 9;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "TYPE_POINT_VENTE";

								row1.TYPE_POINT_VENTE = temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2];
							} else {
								row1.TYPE_POINT_VENTE = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 10;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "TYPE_PACK";

								row1.TYPE_PACK = temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2];
							} else {
								row1.TYPE_PACK = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 11;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "CODE_PRODUIT";

								row1.CODE_PRODUIT = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(
										temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2], null,
										'.' == decimalChar_tFileInputExcel_2 ? null : decimalChar_tFileInputExcel_2));
							} else {
								row1.CODE_PRODUIT = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 12;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "CODE_USAGE";

								row1.CODE_USAGE = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(
										temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2], null,
										'.' == decimalChar_tFileInputExcel_2 ? null : decimalChar_tFileInputExcel_2));
							} else {
								row1.CODE_USAGE = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 13;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "TACITE_RECONDUCTION";

								row1.TACITE_RECONDUCTION = temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2];
							} else {
								row1.TACITE_RECONDUCTION = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 14;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "FRACTIONNEMENT";

								row1.FRACTIONNEMENT = temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2];
							} else {
								row1.FRACTIONNEMENT = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 15;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "TYPE_POLICE";

								row1.TYPE_POLICE = temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2];
							} else {
								row1.TYPE_POLICE = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 16;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "REGION_COMMERCIALE";

								row1.REGION_COMMERCIALE = temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2];
							} else {
								row1.REGION_COMMERCIALE = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 17;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "ANNULATION_MEME_JOUR";

								row1.ANNULATION_MEME_JOUR = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(
										temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2], null,
										'.' == decimalChar_tFileInputExcel_2 ? null : decimalChar_tFileInputExcel_2));
							} else {
								row1.ANNULATION_MEME_JOUR = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 18;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "ENVIGUEUR";

								row1.ENVIGUEUR = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(
										temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2], null,
										'.' == decimalChar_tFileInputExcel_2 ? null : decimalChar_tFileInputExcel_2));
							} else {
								row1.ENVIGUEUR = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 19;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "RESILIE";

								row1.RESILIE = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(
										temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2], null,
										'.' == decimalChar_tFileInputExcel_2 ? null : decimalChar_tFileInputExcel_2));
							} else {
								row1.RESILIE = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 20;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "SUSPENDU";

								row1.SUSPENDU = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(
										temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2], null,
										'.' == decimalChar_tFileInputExcel_2 ? null : decimalChar_tFileInputExcel_2));
							} else {
								row1.SUSPENDU = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 21;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "ETTEINT";

								row1.ETTEINT = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(
										temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2], null,
										'.' == decimalChar_tFileInputExcel_2 ? null : decimalChar_tFileInputExcel_2));
							} else {
								row1.ETTEINT = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 22;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "AFFAIRE_NOUVELLE_DU_MOIS";

								row1.AFFAIRE_NOUVELLE_DU_MOIS = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(
										temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2], null,
										'.' == decimalChar_tFileInputExcel_2 ? null : decimalChar_tFileInputExcel_2));
							} else {
								row1.AFFAIRE_NOUVELLE_DU_MOIS = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							columnIndex_tFileInputExcel_2 = 23;

							if (temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
								curColNum_tFileInputExcel_2 = columnIndex_tFileInputExcel_2
										+ start_column_tFileInputExcel_2 + 1;
								curColName_tFileInputExcel_2 = "AFFAIRE_NOUVELLE_AFIN_DU_MOIS";

								row1.AFFAIRE_NOUVELLE_AFIN_DU_MOIS = ParserUtils.parseTo_Integer(ParserUtils
										.parseTo_Number(temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2], null,
												'.' == decimalChar_tFileInputExcel_2 ? null
														: decimalChar_tFileInputExcel_2));
							} else {
								row1.AFFAIRE_NOUVELLE_AFIN_DU_MOIS = null;
								emptyColumnCount_tFileInputExcel_2++;
							}
							nb_line_tFileInputExcel_2++;

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputExcel_2_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputExcel_2 = true;
							System.err.println(e.getMessage());
							row1 = null;
						}

						/**
						 * [tFileInputExcel_2 begin ] stop
						 */

						/**
						 * [tFileInputExcel_2 main ] start
						 */

						currentComponent = "tFileInputExcel_2";

						tos_count_tFileInputExcel_2++;

						/**
						 * [tFileInputExcel_2 main ] stop
						 */

						/**
						 * [tFileInputExcel_2 process_data_begin ] start
						 */

						currentComponent = "tFileInputExcel_2";

						/**
						 * [tFileInputExcel_2 process_data_begin ] stop
						 */
// Start of branch "row1"
						if (row1 != null) {

							/**
							 * [tDBOutput_1 main ] start
							 */

							currentComponent = "tDBOutput_1";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row1"

								);
							}

							whetherReject_tDBOutput_1 = false;
							if (row1.ARRETE_AU == null) {
								pstmt_tDBOutput_1.setNull(1, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_1.setInt(1, row1.ARRETE_AU);
							}

							if (row1.BRANCHE == null) {
								pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_1.setString(2, row1.BRANCHE);
							}

							if (row1.POLICE == null) {
								pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_1.setString(3, row1.POLICE);
							}

							if (row1.EFFET_ORIGINE != null) {
								pstmt_tDBOutput_1.setTimestamp(4, new java.sql.Timestamp(row1.EFFET_ORIGINE.getTime()));
							} else {
								pstmt_tDBOutput_1.setNull(4, java.sql.Types.TIMESTAMP);
							}

							if (row1.EFFET_COURANTE != null) {
								pstmt_tDBOutput_1.setTimestamp(5,
										new java.sql.Timestamp(row1.EFFET_COURANTE.getTime()));
							} else {
								pstmt_tDBOutput_1.setNull(5, java.sql.Types.TIMESTAMP);
							}

							if (row1.ECHEANCE_ORIGINE != null) {
								pstmt_tDBOutput_1.setTimestamp(6,
										new java.sql.Timestamp(row1.ECHEANCE_ORIGINE.getTime()));
							} else {
								pstmt_tDBOutput_1.setNull(6, java.sql.Types.TIMESTAMP);
							}

							if (row1.ECHEANCE_COURANTE != null) {
								pstmt_tDBOutput_1.setTimestamp(7,
										new java.sql.Timestamp(row1.ECHEANCE_COURANTE.getTime()));
							} else {
								pstmt_tDBOutput_1.setNull(7, java.sql.Types.TIMESTAMP);
							}

							if (row1.DATE_RESILIATION == null) {
								pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_1.setString(8, row1.DATE_RESILIATION);
							}

							if (row1.PT_DE_VENTE == null) {
								pstmt_tDBOutput_1.setNull(9, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_1.setInt(9, row1.PT_DE_VENTE);
							}

							if (row1.TYPE_POINT_VENTE == null) {
								pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_1.setString(10, row1.TYPE_POINT_VENTE);
							}

							if (row1.TYPE_PACK == null) {
								pstmt_tDBOutput_1.setNull(11, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_1.setString(11, row1.TYPE_PACK);
							}

							if (row1.CODE_PRODUIT == null) {
								pstmt_tDBOutput_1.setNull(12, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_1.setInt(12, row1.CODE_PRODUIT);
							}

							if (row1.CODE_USAGE == null) {
								pstmt_tDBOutput_1.setNull(13, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_1.setInt(13, row1.CODE_USAGE);
							}

							if (row1.TACITE_RECONDUCTION == null) {
								pstmt_tDBOutput_1.setNull(14, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_1.setString(14, row1.TACITE_RECONDUCTION);
							}

							if (row1.FRACTIONNEMENT == null) {
								pstmt_tDBOutput_1.setNull(15, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_1.setString(15, row1.FRACTIONNEMENT);
							}

							if (row1.TYPE_POLICE == null) {
								pstmt_tDBOutput_1.setNull(16, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_1.setString(16, row1.TYPE_POLICE);
							}

							if (row1.REGION_COMMERCIALE == null) {
								pstmt_tDBOutput_1.setNull(17, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_1.setString(17, row1.REGION_COMMERCIALE);
							}

							if (row1.ANNULATION_MEME_JOUR == null) {
								pstmt_tDBOutput_1.setNull(18, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_1.setInt(18, row1.ANNULATION_MEME_JOUR);
							}

							if (row1.ENVIGUEUR == null) {
								pstmt_tDBOutput_1.setNull(19, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_1.setInt(19, row1.ENVIGUEUR);
							}

							if (row1.RESILIE == null) {
								pstmt_tDBOutput_1.setNull(20, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_1.setInt(20, row1.RESILIE);
							}

							if (row1.SUSPENDU == null) {
								pstmt_tDBOutput_1.setNull(21, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_1.setInt(21, row1.SUSPENDU);
							}

							if (row1.ETTEINT == null) {
								pstmt_tDBOutput_1.setNull(22, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_1.setInt(22, row1.ETTEINT);
							}

							if (row1.AFFAIRE_NOUVELLE_DU_MOIS == null) {
								pstmt_tDBOutput_1.setNull(23, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_1.setInt(23, row1.AFFAIRE_NOUVELLE_DU_MOIS);
							}

							if (row1.AFFAIRE_NOUVELLE_AFIN_DU_MOIS == null) {
								pstmt_tDBOutput_1.setNull(24, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_1.setInt(24, row1.AFFAIRE_NOUVELLE_AFIN_DU_MOIS);
							}

							pstmt_tDBOutput_1.addBatch();
							nb_line_tDBOutput_1++;

							batchSizeCounter_tDBOutput_1++;

							////////// batch execute by batch size///////
							class LimitBytesHelper_tDBOutput_1 {
								public int limitBytePart1(int counter, java.sql.PreparedStatement pstmt_tDBOutput_1)
										throws Exception {
									try {

										for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
											if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
												break;
											}
											counter += countEach_tDBOutput_1;
										}

									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

										int countSum_tDBOutput_1 = 0;
										for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
											counter += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
										}

										System.err.println(e.getMessage());

									}
									return counter;
								}

								public int limitBytePart2(int counter, java.sql.PreparedStatement pstmt_tDBOutput_1)
										throws Exception {
									try {

										for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
											if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
												break;
											}
											counter += countEach_tDBOutput_1;
										}

									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

										for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
											counter += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
										}

										System.err.println(e.getMessage());

									}
									return counter;
								}
							}
							if ((batchSize_tDBOutput_1 > 0)
									&& (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {

								insertedCount_tDBOutput_1 = new LimitBytesHelper_tDBOutput_1()
										.limitBytePart1(insertedCount_tDBOutput_1, pstmt_tDBOutput_1);
								rowsToCommitCount_tDBOutput_1 = insertedCount_tDBOutput_1;

								batchSizeCounter_tDBOutput_1 = 0;
							}

							//////////// commit every////////////

							commitCounter_tDBOutput_1++;
							if (commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
								if ((batchSize_tDBOutput_1 > 0) && (batchSizeCounter_tDBOutput_1 > 0)) {

									insertedCount_tDBOutput_1 = new LimitBytesHelper_tDBOutput_1()
											.limitBytePart1(insertedCount_tDBOutput_1, pstmt_tDBOutput_1);

									batchSizeCounter_tDBOutput_1 = 0;
								}
								if (rowsToCommitCount_tDBOutput_1 != 0) {

								}
								conn_tDBOutput_1.commit();
								if (rowsToCommitCount_tDBOutput_1 != 0) {

									rowsToCommitCount_tDBOutput_1 = 0;
								}
								commitCounter_tDBOutput_1 = 0;
							}

							tos_count_tDBOutput_1++;

							/**
							 * [tDBOutput_1 main ] stop
							 */

							/**
							 * [tDBOutput_1 process_data_begin ] start
							 */

							currentComponent = "tDBOutput_1";

							/**
							 * [tDBOutput_1 process_data_begin ] stop
							 */

							/**
							 * [tDBOutput_1 process_data_end ] start
							 */

							currentComponent = "tDBOutput_1";

							/**
							 * [tDBOutput_1 process_data_end ] stop
							 */

						} // End of branch "row1"

						/**
						 * [tFileInputExcel_2 process_data_end ] start
						 */

						currentComponent = "tFileInputExcel_2";

						/**
						 * [tFileInputExcel_2 process_data_end ] stop
						 */

						/**
						 * [tFileInputExcel_2 end ] start
						 */

						currentComponent = "tFileInputExcel_2";

					}

					try {
						if (excelReader_tFileInputExcel_2 != null) {
							excelReader_tFileInputExcel_2.handleException();
						}
					} catch (java.lang.Exception e_tFileInputExcel_2) {
						globalMap.put("tFileInputExcel_2_ERROR_MESSAGE", e_tFileInputExcel_2.getMessage());
						if (!(e_tFileInputExcel_2
								.getCause() instanceof com.talend.excel.xssf.event.EnoughDataException)) {

							System.err.println(e_tFileInputExcel_2.getMessage());

						}
					}

					globalMap.put("tFileInputExcel_2_NB_LINE", nb_line_tFileInputExcel_2);

				} finally {

				}

				ok_Hash.put("tFileInputExcel_2", true);
				end_Hash.put("tFileInputExcel_2", System.currentTimeMillis());

				/**
				 * [tFileInputExcel_2 end ] stop
				 */

				/**
				 * [tDBOutput_1 end ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					int countSum_tDBOutput_1 = 0;
					if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {

						for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
							if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
								break;
							}
							countSum_tDBOutput_1 += countEach_tDBOutput_1;
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

					}

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_1 = 0;
					for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_1 != null) {

					pstmt_tDBOutput_1.close();
					resourceMap.remove("pstmt_tDBOutput_1");

				}
				resourceMap.put("statementClosed_tDBOutput_1", true);
				if (rowsToCommitCount_tDBOutput_1 != 0) {

				}
				conn_tDBOutput_1.commit();
				if (rowsToCommitCount_tDBOutput_1 != 0) {

					rowsToCommitCount_tDBOutput_1 = 0;
				}
				commitCounter_tDBOutput_1 = 0;
				conn_tDBOutput_1.close();
				resourceMap.put("finish_tDBOutput_1", true);

				nb_line_deleted_tDBOutput_1 = nb_line_deleted_tDBOutput_1 + deletedCount_tDBOutput_1;
				nb_line_update_tDBOutput_1 = nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
				nb_line_inserted_tDBOutput_1 = nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
				nb_line_rejected_tDBOutput_1 = nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;

				globalMap.put("tDBOutput_1_NB_LINE", nb_line_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_UPDATED", nb_line_update_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_DELETED", nb_line_deleted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row1");
				}

				ok_Hash.put("tDBOutput_1", true);
				end_Hash.put("tDBOutput_1", System.currentTimeMillis());

				/**
				 * [tDBOutput_1 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputExcel_2 finally ] start
				 */

				currentComponent = "tFileInputExcel_2";

				/**
				 * [tFileInputExcel_2 finally ] stop
				 */

				/**
				 * [tDBOutput_1 finally ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
						if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_1")) != null) {
							pstmtToClose_tDBOutput_1.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_1") == null) {
						java.sql.Connection ctn_tDBOutput_1 = null;
						if ((ctn_tDBOutput_1 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_1")) != null) {
							try {
								ctn_tDBOutput_1.close();
							} catch (java.sql.SQLException sqlEx_tDBOutput_1) {
								String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :"
										+ sqlEx_tDBOutput_1.getMessage();
								System.err.println(errorMessage_tDBOutput_1);
							}
						}
					}
				}

				/**
				 * [tDBOutput_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputExcel_2_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final emission062026 emission062026Class = new emission062026();

		int exitCode = emission062026Class.runJobInTOS(args);

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		if (inOSGi) {
			java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

			if (jobProperties != null && jobProperties.get("context") != null) {
				contextStr = (String) jobProperties.get("context");
			}
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = emission062026.class.getClassLoader()
					.getResourceAsStream("star_assurance/emission062026_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = emission062026.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tFileInputExcel_2Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputExcel_2) {
			globalMap.put("tFileInputExcel_2_SUBPROCESS_STATE", -1);

			e_tFileInputExcel_2.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println(
					(endUsedMemory - startUsedMemory) + " bytes memory increase when running : emission062026");
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 80572 characters generated by Talend Open Studio for Data Integration on the
 * 13 juillet 2026 à 11:36:41 WAT
 ************************************************************************************************/