// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.

package star_assurance.factprime_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: factPrime Purpose: <br>
 * Description: <br>
 * 
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status
 */
public class factPrime implements TalendJob {

	protected static void logIgnoredError(String message, Throwable cause) {
		System.err.println(message);
		if (cause != null) {
			cause.printStackTrace();
		}

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "factPrime";
	private final String projectName = "STAR_ASSURANCE";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					factPrime.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(factPrime.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tFileInputExcel_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_6_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_7_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row6_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row7_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row8_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row9_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputExcel_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_STAR_ASSURANCE_factPrime = new byte[0];
		static byte[] commonByteArray_STAR_ASSURANCE_factPrime = new byte[0];

		public String MOIS;

		public String getMOIS() {
			return this.MOIS;
		}

		public Integer ANNEE;

		public Integer getANNEE() {
			return this.ANNEE;
		}

		public String BRANCHE;

		public String getBRANCHE() {
			return this.BRANCHE;
		}

		public String POLICE;

		public String getPOLICE() {
			return this.POLICE;
		}

		public String EFFET_ORIGINE;

		public String getEFFET_ORIGINE() {
			return this.EFFET_ORIGINE;
		}

		public String EFFET_COURANTE;

		public String getEFFET_COURANTE() {
			return this.EFFET_COURANTE;
		}

		public String ECHEANCE_ORIGINE;

		public String getECHEANCE_ORIGINE() {
			return this.ECHEANCE_ORIGINE;
		}

		public String ECHEANCE_COURANTE;

		public String getECHEANCE_COURANTE() {
			return this.ECHEANCE_COURANTE;
		}

		public String DATE_RESILIATION;

		public String getDATE_RESILIATION() {
			return this.DATE_RESILIATION;
		}

		public String PT_DE_VENTE;

		public String getPT_DE_VENTE() {
			return this.PT_DE_VENTE;
		}

		public String TYPE_POINT_VENTE;

		public String getTYPE_POINT_VENTE() {
			return this.TYPE_POINT_VENTE;
		}

		public Character TYPE_PACK;

		public Character getTYPE_PACK() {
			return this.TYPE_PACK;
		}

		public String CODE_PRODUIT;

		public String getCODE_PRODUIT() {
			return this.CODE_PRODUIT;
		}

		public Integer CODE_USAGE;

		public Integer getCODE_USAGE() {
			return this.CODE_USAGE;
		}

		public String TACITE_RECONDUCTION;

		public String getTACITE_RECONDUCTION() {
			return this.TACITE_RECONDUCTION;
		}

		public String FRACTIONNEMENT;

		public String getFRACTIONNEMENT() {
			return this.FRACTIONNEMENT;
		}

		public String ETAT_POLICE;

		public String getETAT_POLICE() {
			return this.ETAT_POLICE;
		}

		public String TYPE_POLICE;

		public String getTYPE_POLICE() {
			return this.TYPE_POLICE;
		}

		public String CONVENTION;

		public String getCONVENTION() {
			return this.CONVENTION;
		}

		public String EMMISSION_ACTE;

		public String getEMMISSION_ACTE() {
			return this.EMMISSION_ACTE;
		}

		public String ANNULATION_ACTE;

		public String getANNULATION_ACTE() {
			return this.ANNULATION_ACTE;
		}

		public String DATE_ANNUL_SYSTEM;

		public String getDATE_ANNUL_SYSTEM() {
			return this.DATE_ANNUL_SYSTEM;
		}

		public String EFFET_ACTE;

		public String getEFFET_ACTE() {
			return this.EFFET_ACTE;
		}

		public Integer STATUT_QUITT;

		public Integer getSTATUT_QUITT() {
			return this.STATUT_QUITT;
		}

		public String TYPE_AVENANT;

		public String getTYPE_AVENANT() {
			return this.TYPE_AVENANT;
		}

		public String PRIME_ARRIERE;

		public String getPRIME_ARRIERE() {
			return this.PRIME_ARRIERE;
		}

		public String PRIME_ENCAISSE;

		public String getPRIME_ENCAISSE() {
			return this.PRIME_ENCAISSE;
		}

		public Integer RESTOURNE_ARRIERE;

		public Integer getRESTOURNE_ARRIERE() {
			return this.RESTOURNE_ARRIERE;
		}

		public Integer RES_AR_ANNEECOURANTE;

		public Integer getRES_AR_ANNEECOURANTE() {
			return this.RES_AR_ANNEECOURANTE;
		}

		public String RESTOURNE_ENCAISSE;

		public String getRESTOURNE_ENCAISSE() {
			return this.RESTOURNE_ENCAISSE;
		}

		public Integer RES_EN_ANNEECOURANTE;

		public Integer getRES_EN_ANNEECOURANTE() {
			return this.RES_EN_ANNEECOURANTE;
		}

		public Integer MONTANT_PARTIEL;

		public Integer getMONTANT_PARTIEL() {
			return this.MONTANT_PARTIEL;
		}

		public String PRIME_HT;

		public String getPRIME_HT() {
			return this.PRIME_HT;
		}

		public Character TYPE_QUITTANCE;

		public Character getTYPE_QUITTANCE() {
			return this.TYPE_QUITTANCE;
		}

		public String SOUS_TYPE_QUITTANCE;

		public String getSOUS_TYPE_QUITTANCE() {
			return this.SOUS_TYPE_QUITTANCE;
		}

		public String REGION_COMMERCIALE;

		public String getREGION_COMMERCIALE() {
			return this.REGION_COMMERCIALE;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_factPrime.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_factPrime.length == 0) {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_STAR_ASSURANCE_factPrime, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_factPrime, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_factPrime.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_factPrime.length == 0) {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_STAR_ASSURANCE_factPrime, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_factPrime, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.MOIS = readString(dis);

					this.ANNEE = readInteger(dis);

					this.BRANCHE = readString(dis);

					this.POLICE = readString(dis);

					this.EFFET_ORIGINE = readString(dis);

					this.EFFET_COURANTE = readString(dis);

					this.ECHEANCE_ORIGINE = readString(dis);

					this.ECHEANCE_COURANTE = readString(dis);

					this.DATE_RESILIATION = readString(dis);

					this.PT_DE_VENTE = readString(dis);

					this.TYPE_POINT_VENTE = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.TYPE_PACK = null;
					} else {
						this.TYPE_PACK = dis.readChar();
					}

					this.CODE_PRODUIT = readString(dis);

					this.CODE_USAGE = readInteger(dis);

					this.TACITE_RECONDUCTION = readString(dis);

					this.FRACTIONNEMENT = readString(dis);

					this.ETAT_POLICE = readString(dis);

					this.TYPE_POLICE = readString(dis);

					this.CONVENTION = readString(dis);

					this.EMMISSION_ACTE = readString(dis);

					this.ANNULATION_ACTE = readString(dis);

					this.DATE_ANNUL_SYSTEM = readString(dis);

					this.EFFET_ACTE = readString(dis);

					this.STATUT_QUITT = readInteger(dis);

					this.TYPE_AVENANT = readString(dis);

					this.PRIME_ARRIERE = readString(dis);

					this.PRIME_ENCAISSE = readString(dis);

					this.RESTOURNE_ARRIERE = readInteger(dis);

					this.RES_AR_ANNEECOURANTE = readInteger(dis);

					this.RESTOURNE_ENCAISSE = readString(dis);

					this.RES_EN_ANNEECOURANTE = readInteger(dis);

					this.MONTANT_PARTIEL = readInteger(dis);

					this.PRIME_HT = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.TYPE_QUITTANCE = null;
					} else {
						this.TYPE_QUITTANCE = dis.readChar();
					}

					this.SOUS_TYPE_QUITTANCE = readString(dis);

					this.REGION_COMMERCIALE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.MOIS = readString(dis);

					this.ANNEE = readInteger(dis);

					this.BRANCHE = readString(dis);

					this.POLICE = readString(dis);

					this.EFFET_ORIGINE = readString(dis);

					this.EFFET_COURANTE = readString(dis);

					this.ECHEANCE_ORIGINE = readString(dis);

					this.ECHEANCE_COURANTE = readString(dis);

					this.DATE_RESILIATION = readString(dis);

					this.PT_DE_VENTE = readString(dis);

					this.TYPE_POINT_VENTE = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.TYPE_PACK = null;
					} else {
						this.TYPE_PACK = dis.readChar();
					}

					this.CODE_PRODUIT = readString(dis);

					this.CODE_USAGE = readInteger(dis);

					this.TACITE_RECONDUCTION = readString(dis);

					this.FRACTIONNEMENT = readString(dis);

					this.ETAT_POLICE = readString(dis);

					this.TYPE_POLICE = readString(dis);

					this.CONVENTION = readString(dis);

					this.EMMISSION_ACTE = readString(dis);

					this.ANNULATION_ACTE = readString(dis);

					this.DATE_ANNUL_SYSTEM = readString(dis);

					this.EFFET_ACTE = readString(dis);

					this.STATUT_QUITT = readInteger(dis);

					this.TYPE_AVENANT = readString(dis);

					this.PRIME_ARRIERE = readString(dis);

					this.PRIME_ENCAISSE = readString(dis);

					this.RESTOURNE_ARRIERE = readInteger(dis);

					this.RES_AR_ANNEECOURANTE = readInteger(dis);

					this.RESTOURNE_ENCAISSE = readString(dis);

					this.RES_EN_ANNEECOURANTE = readInteger(dis);

					this.MONTANT_PARTIEL = readInteger(dis);

					this.PRIME_HT = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.TYPE_QUITTANCE = null;
					} else {
						this.TYPE_QUITTANCE = dis.readChar();
					}

					this.SOUS_TYPE_QUITTANCE = readString(dis);

					this.REGION_COMMERCIALE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.MOIS, dos);

				// Integer

				writeInteger(this.ANNEE, dos);

				// String

				writeString(this.BRANCHE, dos);

				// String

				writeString(this.POLICE, dos);

				// String

				writeString(this.EFFET_ORIGINE, dos);

				// String

				writeString(this.EFFET_COURANTE, dos);

				// String

				writeString(this.ECHEANCE_ORIGINE, dos);

				// String

				writeString(this.ECHEANCE_COURANTE, dos);

				// String

				writeString(this.DATE_RESILIATION, dos);

				// String

				writeString(this.PT_DE_VENTE, dos);

				// String

				writeString(this.TYPE_POINT_VENTE, dos);

				// Character

				if (this.TYPE_PACK == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.TYPE_PACK);
				}

				// String

				writeString(this.CODE_PRODUIT, dos);

				// Integer

				writeInteger(this.CODE_USAGE, dos);

				// String

				writeString(this.TACITE_RECONDUCTION, dos);

				// String

				writeString(this.FRACTIONNEMENT, dos);

				// String

				writeString(this.ETAT_POLICE, dos);

				// String

				writeString(this.TYPE_POLICE, dos);

				// String

				writeString(this.CONVENTION, dos);

				// String

				writeString(this.EMMISSION_ACTE, dos);

				// String

				writeString(this.ANNULATION_ACTE, dos);

				// String

				writeString(this.DATE_ANNUL_SYSTEM, dos);

				// String

				writeString(this.EFFET_ACTE, dos);

				// Integer

				writeInteger(this.STATUT_QUITT, dos);

				// String

				writeString(this.TYPE_AVENANT, dos);

				// String

				writeString(this.PRIME_ARRIERE, dos);

				// String

				writeString(this.PRIME_ENCAISSE, dos);

				// Integer

				writeInteger(this.RESTOURNE_ARRIERE, dos);

				// Integer

				writeInteger(this.RES_AR_ANNEECOURANTE, dos);

				// String

				writeString(this.RESTOURNE_ENCAISSE, dos);

				// Integer

				writeInteger(this.RES_EN_ANNEECOURANTE, dos);

				// Integer

				writeInteger(this.MONTANT_PARTIEL, dos);

				// String

				writeString(this.PRIME_HT, dos);

				// Character

				if (this.TYPE_QUITTANCE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.TYPE_QUITTANCE);
				}

				// String

				writeString(this.SOUS_TYPE_QUITTANCE, dos);

				// String

				writeString(this.REGION_COMMERCIALE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.MOIS, dos);

				// Integer

				writeInteger(this.ANNEE, dos);

				// String

				writeString(this.BRANCHE, dos);

				// String

				writeString(this.POLICE, dos);

				// String

				writeString(this.EFFET_ORIGINE, dos);

				// String

				writeString(this.EFFET_COURANTE, dos);

				// String

				writeString(this.ECHEANCE_ORIGINE, dos);

				// String

				writeString(this.ECHEANCE_COURANTE, dos);

				// String

				writeString(this.DATE_RESILIATION, dos);

				// String

				writeString(this.PT_DE_VENTE, dos);

				// String

				writeString(this.TYPE_POINT_VENTE, dos);

				// Character

				if (this.TYPE_PACK == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.TYPE_PACK);
				}

				// String

				writeString(this.CODE_PRODUIT, dos);

				// Integer

				writeInteger(this.CODE_USAGE, dos);

				// String

				writeString(this.TACITE_RECONDUCTION, dos);

				// String

				writeString(this.FRACTIONNEMENT, dos);

				// String

				writeString(this.ETAT_POLICE, dos);

				// String

				writeString(this.TYPE_POLICE, dos);

				// String

				writeString(this.CONVENTION, dos);

				// String

				writeString(this.EMMISSION_ACTE, dos);

				// String

				writeString(this.ANNULATION_ACTE, dos);

				// String

				writeString(this.DATE_ANNUL_SYSTEM, dos);

				// String

				writeString(this.EFFET_ACTE, dos);

				// Integer

				writeInteger(this.STATUT_QUITT, dos);

				// String

				writeString(this.TYPE_AVENANT, dos);

				// String

				writeString(this.PRIME_ARRIERE, dos);

				// String

				writeString(this.PRIME_ENCAISSE, dos);

				// Integer

				writeInteger(this.RESTOURNE_ARRIERE, dos);

				// Integer

				writeInteger(this.RES_AR_ANNEECOURANTE, dos);

				// String

				writeString(this.RESTOURNE_ENCAISSE, dos);

				// Integer

				writeInteger(this.RES_EN_ANNEECOURANTE, dos);

				// Integer

				writeInteger(this.MONTANT_PARTIEL, dos);

				// String

				writeString(this.PRIME_HT, dos);

				// Character

				if (this.TYPE_QUITTANCE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.TYPE_QUITTANCE);
				}

				// String

				writeString(this.SOUS_TYPE_QUITTANCE, dos);

				// String

				writeString(this.REGION_COMMERCIALE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("MOIS=" + MOIS);
			sb.append(",ANNEE=" + String.valueOf(ANNEE));
			sb.append(",BRANCHE=" + BRANCHE);
			sb.append(",POLICE=" + POLICE);
			sb.append(",EFFET_ORIGINE=" + EFFET_ORIGINE);
			sb.append(",EFFET_COURANTE=" + EFFET_COURANTE);
			sb.append(",ECHEANCE_ORIGINE=" + ECHEANCE_ORIGINE);
			sb.append(",ECHEANCE_COURANTE=" + ECHEANCE_COURANTE);
			sb.append(",DATE_RESILIATION=" + DATE_RESILIATION);
			sb.append(",PT_DE_VENTE=" + PT_DE_VENTE);
			sb.append(",TYPE_POINT_VENTE=" + TYPE_POINT_VENTE);
			sb.append(",TYPE_PACK=" + String.valueOf(TYPE_PACK));
			sb.append(",CODE_PRODUIT=" + CODE_PRODUIT);
			sb.append(",CODE_USAGE=" + String.valueOf(CODE_USAGE));
			sb.append(",TACITE_RECONDUCTION=" + TACITE_RECONDUCTION);
			sb.append(",FRACTIONNEMENT=" + FRACTIONNEMENT);
			sb.append(",ETAT_POLICE=" + ETAT_POLICE);
			sb.append(",TYPE_POLICE=" + TYPE_POLICE);
			sb.append(",CONVENTION=" + CONVENTION);
			sb.append(",EMMISSION_ACTE=" + EMMISSION_ACTE);
			sb.append(",ANNULATION_ACTE=" + ANNULATION_ACTE);
			sb.append(",DATE_ANNUL_SYSTEM=" + DATE_ANNUL_SYSTEM);
			sb.append(",EFFET_ACTE=" + EFFET_ACTE);
			sb.append(",STATUT_QUITT=" + String.valueOf(STATUT_QUITT));
			sb.append(",TYPE_AVENANT=" + TYPE_AVENANT);
			sb.append(",PRIME_ARRIERE=" + PRIME_ARRIERE);
			sb.append(",PRIME_ENCAISSE=" + PRIME_ENCAISSE);
			sb.append(",RESTOURNE_ARRIERE=" + String.valueOf(RESTOURNE_ARRIERE));
			sb.append(",RES_AR_ANNEECOURANTE=" + String.valueOf(RES_AR_ANNEECOURANTE));
			sb.append(",RESTOURNE_ENCAISSE=" + RESTOURNE_ENCAISSE);
			sb.append(",RES_EN_ANNEECOURANTE=" + String.valueOf(RES_EN_ANNEECOURANTE));
			sb.append(",MONTANT_PARTIEL=" + String.valueOf(MONTANT_PARTIEL));
			sb.append(",PRIME_HT=" + PRIME_HT);
			sb.append(",TYPE_QUITTANCE=" + String.valueOf(TYPE_QUITTANCE));
			sb.append(",SOUS_TYPE_QUITTANCE=" + SOUS_TYPE_QUITTANCE);
			sb.append(",REGION_COMMERCIALE=" + REGION_COMMERCIALE);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class after_tFileInputExcel_1Struct
			implements routines.system.IPersistableRow<after_tFileInputExcel_1Struct> {
		final static byte[] commonByteArrayLock_STAR_ASSURANCE_factPrime = new byte[0];
		static byte[] commonByteArray_STAR_ASSURANCE_factPrime = new byte[0];

		public String MOIS;

		public String getMOIS() {
			return this.MOIS;
		}

		public Integer ANNEE;

		public Integer getANNEE() {
			return this.ANNEE;
		}

		public String BRANCHE;

		public String getBRANCHE() {
			return this.BRANCHE;
		}

		public String POLICE;

		public String getPOLICE() {
			return this.POLICE;
		}

		public String EFFET_ORIGINE;

		public String getEFFET_ORIGINE() {
			return this.EFFET_ORIGINE;
		}

		public String EFFET_COURANTE;

		public String getEFFET_COURANTE() {
			return this.EFFET_COURANTE;
		}

		public String ECHEANCE_ORIGINE;

		public String getECHEANCE_ORIGINE() {
			return this.ECHEANCE_ORIGINE;
		}

		public String ECHEANCE_COURANTE;

		public String getECHEANCE_COURANTE() {
			return this.ECHEANCE_COURANTE;
		}

		public String DATE_RESILIATION;

		public String getDATE_RESILIATION() {
			return this.DATE_RESILIATION;
		}

		public String PT_DE_VENTE;

		public String getPT_DE_VENTE() {
			return this.PT_DE_VENTE;
		}

		public String TYPE_POINT_VENTE;

		public String getTYPE_POINT_VENTE() {
			return this.TYPE_POINT_VENTE;
		}

		public Character TYPE_PACK;

		public Character getTYPE_PACK() {
			return this.TYPE_PACK;
		}

		public String CODE_PRODUIT;

		public String getCODE_PRODUIT() {
			return this.CODE_PRODUIT;
		}

		public Integer CODE_USAGE;

		public Integer getCODE_USAGE() {
			return this.CODE_USAGE;
		}

		public String TACITE_RECONDUCTION;

		public String getTACITE_RECONDUCTION() {
			return this.TACITE_RECONDUCTION;
		}

		public String FRACTIONNEMENT;

		public String getFRACTIONNEMENT() {
			return this.FRACTIONNEMENT;
		}

		public String ETAT_POLICE;

		public String getETAT_POLICE() {
			return this.ETAT_POLICE;
		}

		public String TYPE_POLICE;

		public String getTYPE_POLICE() {
			return this.TYPE_POLICE;
		}

		public String CONVENTION;

		public String getCONVENTION() {
			return this.CONVENTION;
		}

		public String EMMISSION_ACTE;

		public String getEMMISSION_ACTE() {
			return this.EMMISSION_ACTE;
		}

		public String ANNULATION_ACTE;

		public String getANNULATION_ACTE() {
			return this.ANNULATION_ACTE;
		}

		public String DATE_ANNUL_SYSTEM;

		public String getDATE_ANNUL_SYSTEM() {
			return this.DATE_ANNUL_SYSTEM;
		}

		public String EFFET_ACTE;

		public String getEFFET_ACTE() {
			return this.EFFET_ACTE;
		}

		public Integer STATUT_QUITT;

		public Integer getSTATUT_QUITT() {
			return this.STATUT_QUITT;
		}

		public String TYPE_AVENANT;

		public String getTYPE_AVENANT() {
			return this.TYPE_AVENANT;
		}

		public String PRIME_ARRIERE;

		public String getPRIME_ARRIERE() {
			return this.PRIME_ARRIERE;
		}

		public String PRIME_ENCAISSE;

		public String getPRIME_ENCAISSE() {
			return this.PRIME_ENCAISSE;
		}

		public Integer RESTOURNE_ARRIERE;

		public Integer getRESTOURNE_ARRIERE() {
			return this.RESTOURNE_ARRIERE;
		}

		public Integer RES_AR_ANNEECOURANTE;

		public Integer getRES_AR_ANNEECOURANTE() {
			return this.RES_AR_ANNEECOURANTE;
		}

		public String RESTOURNE_ENCAISSE;

		public String getRESTOURNE_ENCAISSE() {
			return this.RESTOURNE_ENCAISSE;
		}

		public Integer RES_EN_ANNEECOURANTE;

		public Integer getRES_EN_ANNEECOURANTE() {
			return this.RES_EN_ANNEECOURANTE;
		}

		public Integer MONTANT_PARTIEL;

		public Integer getMONTANT_PARTIEL() {
			return this.MONTANT_PARTIEL;
		}

		public String PRIME_HT;

		public String getPRIME_HT() {
			return this.PRIME_HT;
		}

		public Character TYPE_QUITTANCE;

		public Character getTYPE_QUITTANCE() {
			return this.TYPE_QUITTANCE;
		}

		public String SOUS_TYPE_QUITTANCE;

		public String getSOUS_TYPE_QUITTANCE() {
			return this.SOUS_TYPE_QUITTANCE;
		}

		public String REGION_COMMERCIALE;

		public String getREGION_COMMERCIALE() {
			return this.REGION_COMMERCIALE;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_factPrime.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_factPrime.length == 0) {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_STAR_ASSURANCE_factPrime, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_factPrime, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_factPrime.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_factPrime.length == 0) {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_STAR_ASSURANCE_factPrime, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_factPrime, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.MOIS = readString(dis);

					this.ANNEE = readInteger(dis);

					this.BRANCHE = readString(dis);

					this.POLICE = readString(dis);

					this.EFFET_ORIGINE = readString(dis);

					this.EFFET_COURANTE = readString(dis);

					this.ECHEANCE_ORIGINE = readString(dis);

					this.ECHEANCE_COURANTE = readString(dis);

					this.DATE_RESILIATION = readString(dis);

					this.PT_DE_VENTE = readString(dis);

					this.TYPE_POINT_VENTE = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.TYPE_PACK = null;
					} else {
						this.TYPE_PACK = dis.readChar();
					}

					this.CODE_PRODUIT = readString(dis);

					this.CODE_USAGE = readInteger(dis);

					this.TACITE_RECONDUCTION = readString(dis);

					this.FRACTIONNEMENT = readString(dis);

					this.ETAT_POLICE = readString(dis);

					this.TYPE_POLICE = readString(dis);

					this.CONVENTION = readString(dis);

					this.EMMISSION_ACTE = readString(dis);

					this.ANNULATION_ACTE = readString(dis);

					this.DATE_ANNUL_SYSTEM = readString(dis);

					this.EFFET_ACTE = readString(dis);

					this.STATUT_QUITT = readInteger(dis);

					this.TYPE_AVENANT = readString(dis);

					this.PRIME_ARRIERE = readString(dis);

					this.PRIME_ENCAISSE = readString(dis);

					this.RESTOURNE_ARRIERE = readInteger(dis);

					this.RES_AR_ANNEECOURANTE = readInteger(dis);

					this.RESTOURNE_ENCAISSE = readString(dis);

					this.RES_EN_ANNEECOURANTE = readInteger(dis);

					this.MONTANT_PARTIEL = readInteger(dis);

					this.PRIME_HT = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.TYPE_QUITTANCE = null;
					} else {
						this.TYPE_QUITTANCE = dis.readChar();
					}

					this.SOUS_TYPE_QUITTANCE = readString(dis);

					this.REGION_COMMERCIALE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.MOIS = readString(dis);

					this.ANNEE = readInteger(dis);

					this.BRANCHE = readString(dis);

					this.POLICE = readString(dis);

					this.EFFET_ORIGINE = readString(dis);

					this.EFFET_COURANTE = readString(dis);

					this.ECHEANCE_ORIGINE = readString(dis);

					this.ECHEANCE_COURANTE = readString(dis);

					this.DATE_RESILIATION = readString(dis);

					this.PT_DE_VENTE = readString(dis);

					this.TYPE_POINT_VENTE = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.TYPE_PACK = null;
					} else {
						this.TYPE_PACK = dis.readChar();
					}

					this.CODE_PRODUIT = readString(dis);

					this.CODE_USAGE = readInteger(dis);

					this.TACITE_RECONDUCTION = readString(dis);

					this.FRACTIONNEMENT = readString(dis);

					this.ETAT_POLICE = readString(dis);

					this.TYPE_POLICE = readString(dis);

					this.CONVENTION = readString(dis);

					this.EMMISSION_ACTE = readString(dis);

					this.ANNULATION_ACTE = readString(dis);

					this.DATE_ANNUL_SYSTEM = readString(dis);

					this.EFFET_ACTE = readString(dis);

					this.STATUT_QUITT = readInteger(dis);

					this.TYPE_AVENANT = readString(dis);

					this.PRIME_ARRIERE = readString(dis);

					this.PRIME_ENCAISSE = readString(dis);

					this.RESTOURNE_ARRIERE = readInteger(dis);

					this.RES_AR_ANNEECOURANTE = readInteger(dis);

					this.RESTOURNE_ENCAISSE = readString(dis);

					this.RES_EN_ANNEECOURANTE = readInteger(dis);

					this.MONTANT_PARTIEL = readInteger(dis);

					this.PRIME_HT = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.TYPE_QUITTANCE = null;
					} else {
						this.TYPE_QUITTANCE = dis.readChar();
					}

					this.SOUS_TYPE_QUITTANCE = readString(dis);

					this.REGION_COMMERCIALE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.MOIS, dos);

				// Integer

				writeInteger(this.ANNEE, dos);

				// String

				writeString(this.BRANCHE, dos);

				// String

				writeString(this.POLICE, dos);

				// String

				writeString(this.EFFET_ORIGINE, dos);

				// String

				writeString(this.EFFET_COURANTE, dos);

				// String

				writeString(this.ECHEANCE_ORIGINE, dos);

				// String

				writeString(this.ECHEANCE_COURANTE, dos);

				// String

				writeString(this.DATE_RESILIATION, dos);

				// String

				writeString(this.PT_DE_VENTE, dos);

				// String

				writeString(this.TYPE_POINT_VENTE, dos);

				// Character

				if (this.TYPE_PACK == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.TYPE_PACK);
				}

				// String

				writeString(this.CODE_PRODUIT, dos);

				// Integer

				writeInteger(this.CODE_USAGE, dos);

				// String

				writeString(this.TACITE_RECONDUCTION, dos);

				// String

				writeString(this.FRACTIONNEMENT, dos);

				// String

				writeString(this.ETAT_POLICE, dos);

				// String

				writeString(this.TYPE_POLICE, dos);

				// String

				writeString(this.CONVENTION, dos);

				// String

				writeString(this.EMMISSION_ACTE, dos);

				// String

				writeString(this.ANNULATION_ACTE, dos);

				// String

				writeString(this.DATE_ANNUL_SYSTEM, dos);

				// String

				writeString(this.EFFET_ACTE, dos);

				// Integer

				writeInteger(this.STATUT_QUITT, dos);

				// String

				writeString(this.TYPE_AVENANT, dos);

				// String

				writeString(this.PRIME_ARRIERE, dos);

				// String

				writeString(this.PRIME_ENCAISSE, dos);

				// Integer

				writeInteger(this.RESTOURNE_ARRIERE, dos);

				// Integer

				writeInteger(this.RES_AR_ANNEECOURANTE, dos);

				// String

				writeString(this.RESTOURNE_ENCAISSE, dos);

				// Integer

				writeInteger(this.RES_EN_ANNEECOURANTE, dos);

				// Integer

				writeInteger(this.MONTANT_PARTIEL, dos);

				// String

				writeString(this.PRIME_HT, dos);

				// Character

				if (this.TYPE_QUITTANCE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.TYPE_QUITTANCE);
				}

				// String

				writeString(this.SOUS_TYPE_QUITTANCE, dos);

				// String

				writeString(this.REGION_COMMERCIALE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.MOIS, dos);

				// Integer

				writeInteger(this.ANNEE, dos);

				// String

				writeString(this.BRANCHE, dos);

				// String

				writeString(this.POLICE, dos);

				// String

				writeString(this.EFFET_ORIGINE, dos);

				// String

				writeString(this.EFFET_COURANTE, dos);

				// String

				writeString(this.ECHEANCE_ORIGINE, dos);

				// String

				writeString(this.ECHEANCE_COURANTE, dos);

				// String

				writeString(this.DATE_RESILIATION, dos);

				// String

				writeString(this.PT_DE_VENTE, dos);

				// String

				writeString(this.TYPE_POINT_VENTE, dos);

				// Character

				if (this.TYPE_PACK == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.TYPE_PACK);
				}

				// String

				writeString(this.CODE_PRODUIT, dos);

				// Integer

				writeInteger(this.CODE_USAGE, dos);

				// String

				writeString(this.TACITE_RECONDUCTION, dos);

				// String

				writeString(this.FRACTIONNEMENT, dos);

				// String

				writeString(this.ETAT_POLICE, dos);

				// String

				writeString(this.TYPE_POLICE, dos);

				// String

				writeString(this.CONVENTION, dos);

				// String

				writeString(this.EMMISSION_ACTE, dos);

				// String

				writeString(this.ANNULATION_ACTE, dos);

				// String

				writeString(this.DATE_ANNUL_SYSTEM, dos);

				// String

				writeString(this.EFFET_ACTE, dos);

				// Integer

				writeInteger(this.STATUT_QUITT, dos);

				// String

				writeString(this.TYPE_AVENANT, dos);

				// String

				writeString(this.PRIME_ARRIERE, dos);

				// String

				writeString(this.PRIME_ENCAISSE, dos);

				// Integer

				writeInteger(this.RESTOURNE_ARRIERE, dos);

				// Integer

				writeInteger(this.RES_AR_ANNEECOURANTE, dos);

				// String

				writeString(this.RESTOURNE_ENCAISSE, dos);

				// Integer

				writeInteger(this.RES_EN_ANNEECOURANTE, dos);

				// Integer

				writeInteger(this.MONTANT_PARTIEL, dos);

				// String

				writeString(this.PRIME_HT, dos);

				// Character

				if (this.TYPE_QUITTANCE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeChar(this.TYPE_QUITTANCE);
				}

				// String

				writeString(this.SOUS_TYPE_QUITTANCE, dos);

				// String

				writeString(this.REGION_COMMERCIALE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("MOIS=" + MOIS);
			sb.append(",ANNEE=" + String.valueOf(ANNEE));
			sb.append(",BRANCHE=" + BRANCHE);
			sb.append(",POLICE=" + POLICE);
			sb.append(",EFFET_ORIGINE=" + EFFET_ORIGINE);
			sb.append(",EFFET_COURANTE=" + EFFET_COURANTE);
			sb.append(",ECHEANCE_ORIGINE=" + ECHEANCE_ORIGINE);
			sb.append(",ECHEANCE_COURANTE=" + ECHEANCE_COURANTE);
			sb.append(",DATE_RESILIATION=" + DATE_RESILIATION);
			sb.append(",PT_DE_VENTE=" + PT_DE_VENTE);
			sb.append(",TYPE_POINT_VENTE=" + TYPE_POINT_VENTE);
			sb.append(",TYPE_PACK=" + String.valueOf(TYPE_PACK));
			sb.append(",CODE_PRODUIT=" + CODE_PRODUIT);
			sb.append(",CODE_USAGE=" + String.valueOf(CODE_USAGE));
			sb.append(",TACITE_RECONDUCTION=" + TACITE_RECONDUCTION);
			sb.append(",FRACTIONNEMENT=" + FRACTIONNEMENT);
			sb.append(",ETAT_POLICE=" + ETAT_POLICE);
			sb.append(",TYPE_POLICE=" + TYPE_POLICE);
			sb.append(",CONVENTION=" + CONVENTION);
			sb.append(",EMMISSION_ACTE=" + EMMISSION_ACTE);
			sb.append(",ANNULATION_ACTE=" + ANNULATION_ACTE);
			sb.append(",DATE_ANNUL_SYSTEM=" + DATE_ANNUL_SYSTEM);
			sb.append(",EFFET_ACTE=" + EFFET_ACTE);
			sb.append(",STATUT_QUITT=" + String.valueOf(STATUT_QUITT));
			sb.append(",TYPE_AVENANT=" + TYPE_AVENANT);
			sb.append(",PRIME_ARRIERE=" + PRIME_ARRIERE);
			sb.append(",PRIME_ENCAISSE=" + PRIME_ENCAISSE);
			sb.append(",RESTOURNE_ARRIERE=" + String.valueOf(RESTOURNE_ARRIERE));
			sb.append(",RES_AR_ANNEECOURANTE=" + String.valueOf(RES_AR_ANNEECOURANTE));
			sb.append(",RESTOURNE_ENCAISSE=" + RESTOURNE_ENCAISSE);
			sb.append(",RES_EN_ANNEECOURANTE=" + String.valueOf(RES_EN_ANNEECOURANTE));
			sb.append(",MONTANT_PARTIEL=" + String.valueOf(MONTANT_PARTIEL));
			sb.append(",PRIME_HT=" + PRIME_HT);
			sb.append(",TYPE_QUITTANCE=" + String.valueOf(TYPE_QUITTANCE));
			sb.append(",SOUS_TYPE_QUITTANCE=" + SOUS_TYPE_QUITTANCE);
			sb.append(",REGION_COMMERCIALE=" + REGION_COMMERCIALE);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(after_tFileInputExcel_1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputExcel_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				tDBInput_1Process(globalMap);
				tDBInput_2Process(globalMap);
				tDBInput_3Process(globalMap);
				tDBInput_4Process(globalMap);
				tDBInput_5Process(globalMap);
				tDBInput_6Process(globalMap);
				tDBInput_7Process(globalMap);
				tDBOutput_1Process(globalMap);

				row1Struct row1 = new row1Struct();

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row1");
				}

				int tos_count_tMap_1 = 0;

// ###############################
// # Lookup's keys initialization

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct> tHash_Lookup_row2 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct>) globalMap
						.get("tHash_Lookup_row2"));

				row2Struct row2HashKey = new row2Struct();
				row2Struct row2Default = new row2Struct();

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct> tHash_Lookup_row3 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct>) globalMap
						.get("tHash_Lookup_row3"));

				tHash_Lookup_row3.initGet();

				row3Struct row3HashKey = new row3Struct();
				row3Struct row3Default = new row3Struct();

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct> tHash_Lookup_row4 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct>) globalMap
						.get("tHash_Lookup_row4"));

				tHash_Lookup_row4.initGet();

				row4Struct row4HashKey = new row4Struct();
				row4Struct row4Default = new row4Struct();

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row5Struct> tHash_Lookup_row5 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row5Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row5Struct>) globalMap
						.get("tHash_Lookup_row5"));

				tHash_Lookup_row5.initGet();

				row5Struct row5HashKey = new row5Struct();
				row5Struct row5Default = new row5Struct();

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row6Struct> tHash_Lookup_row6 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row6Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row6Struct>) globalMap
						.get("tHash_Lookup_row6"));

				tHash_Lookup_row6.initGet();

				row6Struct row6HashKey = new row6Struct();
				row6Struct row6Default = new row6Struct();

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row7Struct> tHash_Lookup_row7 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row7Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row7Struct>) globalMap
						.get("tHash_Lookup_row7"));

				tHash_Lookup_row7.initGet();

				row7Struct row7HashKey = new row7Struct();
				row7Struct row7Default = new row7Struct();

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row9Struct> tHash_Lookup_row9 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row9Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row9Struct>) globalMap
						.get("tHash_Lookup_row9"));

				tHash_Lookup_row9.initGet();

				row9Struct row9HashKey = new row9Struct();
				row9Struct row9Default = new row9Struct();

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct> tHash_Lookup_row8 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct>) globalMap
						.get("tHash_Lookup_row8"));

				tHash_Lookup_row8.initGet();

				row8Struct row8HashKey = new row8Struct();
				row8Struct row8Default = new row8Struct();
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tFileInputExcel_1 begin ] start
				 */

				ok_Hash.put("tFileInputExcel_1", false);
				start_Hash.put("tFileInputExcel_1", System.currentTimeMillis());

				currentComponent = "tFileInputExcel_1";

				int tos_count_tFileInputExcel_1 = 0;

				final String decryptedPassword_tFileInputExcel_1 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:OA72JZEq/oTxKfq+eEZe4ZHE7iA4vRlmpkgxXQ==");
				String password_tFileInputExcel_1 = decryptedPassword_tFileInputExcel_1;
				if (password_tFileInputExcel_1.isEmpty()) {
					password_tFileInputExcel_1 = null;
				}
				Object source_tFileInputExcel_1 = "C:/Users/Mega Pc/Desktop/stage_4eme_STAR_assurance/donnees2/RapportPrimeEmiss_Afin_062026_stag.xlsx";
				com.talend.excel.xssf.event.ExcelReader excelReader_tFileInputExcel_1 = null;

				if (source_tFileInputExcel_1 instanceof java.io.InputStream
						|| source_tFileInputExcel_1 instanceof String) {
					excelReader_tFileInputExcel_1 = new com.talend.excel.xssf.event.ExcelReader();
					excelReader_tFileInputExcel_1.setIncludePhoneticRuns(true);
				} else {
					throw new java.lang.Exception("The data source should be specified as Inputstream or File Path!");
				}

				try {
					excelReader_tFileInputExcel_1.addSheetName(".*", true);
					int start_column_tFileInputExcel_1 = 1 - 1;
					int end_column_tFileInputExcel_1 = -1;
					if (start_column_tFileInputExcel_1 >= 0) {// follow start column

						end_column_tFileInputExcel_1 = start_column_tFileInputExcel_1 + 36 - 1;

					} else if (end_column_tFileInputExcel_1 >= 0) {// follow end column
						start_column_tFileInputExcel_1 = end_column_tFileInputExcel_1 - 36 + 1;
					}

					if (end_column_tFileInputExcel_1 < 0 || start_column_tFileInputExcel_1 < 0) {
						throw new RuntimeException("Error start column and end column.");
					}
					int actual_end_column_tFileInputExcel_1 = end_column_tFileInputExcel_1;

					int header_tFileInputExcel_1 = 1;
					int limit_tFileInputExcel_1 = -1;

					int nb_line_tFileInputExcel_1 = 0;

					// for the number format
					java.text.DecimalFormat df_tFileInputExcel_1 = new java.text.DecimalFormat(
							"#.####################################");
					char decimalChar_tFileInputExcel_1 = df_tFileInputExcel_1.getDecimalFormatSymbols()
							.getDecimalSeparator();

					if (source_tFileInputExcel_1 instanceof String) {
						excelReader_tFileInputExcel_1.parse((String) source_tFileInputExcel_1, "UTF-8",
								password_tFileInputExcel_1);
					} else if (source_tFileInputExcel_1 instanceof java.io.InputStream) {
						excelReader_tFileInputExcel_1.parse((java.io.InputStream) source_tFileInputExcel_1, "UTF-8",
								password_tFileInputExcel_1);
					}

					while ((header_tFileInputExcel_1--) > 0 && excelReader_tFileInputExcel_1.hasNext()) {// skip the
																											// header
						excelReader_tFileInputExcel_1.next();
					}

					while (excelReader_tFileInputExcel_1.hasNext()) {
						int emptyColumnCount_tFileInputExcel_1 = 0;

						if (limit_tFileInputExcel_1 != -1 && nb_line_tFileInputExcel_1 >= limit_tFileInputExcel_1) {
							excelReader_tFileInputExcel_1.stopRead();
							break;
						}

						java.util.List<String> row_tFileInputExcel_1 = excelReader_tFileInputExcel_1.next();
						row1 = null;
						int tempRowLength_tFileInputExcel_1 = 36;

						int columnIndex_tFileInputExcel_1 = 0;

						String[] temp_row_tFileInputExcel_1 = new String[tempRowLength_tFileInputExcel_1];

						for (int i_tFileInputExcel_1 = 0; i_tFileInputExcel_1 < tempRowLength_tFileInputExcel_1; i_tFileInputExcel_1++) {
							int current_tFileInputExcel_1 = i_tFileInputExcel_1 + start_column_tFileInputExcel_1;
							if (current_tFileInputExcel_1 <= actual_end_column_tFileInputExcel_1) {
								if (current_tFileInputExcel_1 < row_tFileInputExcel_1.size()) {
									String column_tFileInputExcel_1 = row_tFileInputExcel_1
											.get(current_tFileInputExcel_1);
									if (column_tFileInputExcel_1 != null) {
										temp_row_tFileInputExcel_1[i_tFileInputExcel_1] = column_tFileInputExcel_1;
									} else {
										temp_row_tFileInputExcel_1[i_tFileInputExcel_1] = "";
									}
								} else {
									temp_row_tFileInputExcel_1[i_tFileInputExcel_1] = "";
								}
							} else {
								temp_row_tFileInputExcel_1[i_tFileInputExcel_1] = "";
							}
						}

						boolean whetherReject_tFileInputExcel_1 = false;
						row1 = new row1Struct();
						int curColNum_tFileInputExcel_1 = -1;
						String curColName_tFileInputExcel_1 = "";

						try {
							columnIndex_tFileInputExcel_1 = 0;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "MOIS";

								row1.MOIS = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.MOIS = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 1;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "ANNEE";

								row1.ANNEE = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(
										temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1], null,
										'.' == decimalChar_tFileInputExcel_1 ? null : decimalChar_tFileInputExcel_1));
							} else {
								row1.ANNEE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 2;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "BRANCHE";

								row1.BRANCHE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.BRANCHE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 3;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "POLICE";

								row1.POLICE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.POLICE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 4;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "EFFET_ORIGINE";

								row1.EFFET_ORIGINE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.EFFET_ORIGINE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 5;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "EFFET_COURANTE";

								row1.EFFET_COURANTE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.EFFET_COURANTE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 6;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "ECHEANCE_ORIGINE";

								row1.ECHEANCE_ORIGINE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.ECHEANCE_ORIGINE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 7;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "ECHEANCE_COURANTE";

								row1.ECHEANCE_COURANTE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.ECHEANCE_COURANTE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 8;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "DATE_RESILIATION";

								row1.DATE_RESILIATION = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.DATE_RESILIATION = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 9;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "PT_DE_VENTE";

								row1.PT_DE_VENTE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.PT_DE_VENTE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 10;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "TYPE_POINT_VENTE";

								row1.TYPE_POINT_VENTE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.TYPE_POINT_VENTE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 11;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "TYPE_PACK";

								row1.TYPE_PACK = ParserUtils
										.parseTo_Character(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
							} else {
								row1.TYPE_PACK = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 12;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "CODE_PRODUIT";

								row1.CODE_PRODUIT = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.CODE_PRODUIT = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 13;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "CODE_USAGE";

								row1.CODE_USAGE = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(
										temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1], null,
										'.' == decimalChar_tFileInputExcel_1 ? null : decimalChar_tFileInputExcel_1));
							} else {
								row1.CODE_USAGE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 14;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "TACITE_RECONDUCTION";

								row1.TACITE_RECONDUCTION = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.TACITE_RECONDUCTION = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 15;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "FRACTIONNEMENT";

								row1.FRACTIONNEMENT = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.FRACTIONNEMENT = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 16;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "ETAT_POLICE";

								row1.ETAT_POLICE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.ETAT_POLICE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 17;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "TYPE_POLICE";

								row1.TYPE_POLICE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.TYPE_POLICE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 18;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "CONVENTION";

								row1.CONVENTION = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.CONVENTION = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 19;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "EMMISSION_ACTE";

								row1.EMMISSION_ACTE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.EMMISSION_ACTE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 20;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "ANNULATION_ACTE";

								row1.ANNULATION_ACTE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.ANNULATION_ACTE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 21;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "DATE_ANNUL_SYSTEM";

								row1.DATE_ANNUL_SYSTEM = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.DATE_ANNUL_SYSTEM = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 22;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "EFFET_ACTE";

								row1.EFFET_ACTE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.EFFET_ACTE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 23;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "STATUT_QUITT";

								row1.STATUT_QUITT = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(
										temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1], null,
										'.' == decimalChar_tFileInputExcel_1 ? null : decimalChar_tFileInputExcel_1));
							} else {
								row1.STATUT_QUITT = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 24;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "TYPE_AVENANT";

								row1.TYPE_AVENANT = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.TYPE_AVENANT = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 25;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "PRIME_ARRIERE";

								row1.PRIME_ARRIERE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.PRIME_ARRIERE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 26;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "PRIME_ENCAISSE";

								row1.PRIME_ENCAISSE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.PRIME_ENCAISSE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 27;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "RESTOURNE_ARRIERE";

								row1.RESTOURNE_ARRIERE = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(
										temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1], null,
										'.' == decimalChar_tFileInputExcel_1 ? null : decimalChar_tFileInputExcel_1));
							} else {
								row1.RESTOURNE_ARRIERE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 28;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "RES_AR_ANNEECOURANTE";

								row1.RES_AR_ANNEECOURANTE = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(
										temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1], null,
										'.' == decimalChar_tFileInputExcel_1 ? null : decimalChar_tFileInputExcel_1));
							} else {
								row1.RES_AR_ANNEECOURANTE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 29;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "RESTOURNE_ENCAISSE";

								row1.RESTOURNE_ENCAISSE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.RESTOURNE_ENCAISSE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 30;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "RES_EN_ANNEECOURANTE";

								row1.RES_EN_ANNEECOURANTE = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(
										temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1], null,
										'.' == decimalChar_tFileInputExcel_1 ? null : decimalChar_tFileInputExcel_1));
							} else {
								row1.RES_EN_ANNEECOURANTE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 31;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "MONTANT_PARTIEL";

								row1.MONTANT_PARTIEL = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(
										temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1], null,
										'.' == decimalChar_tFileInputExcel_1 ? null : decimalChar_tFileInputExcel_1));
							} else {
								row1.MONTANT_PARTIEL = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 32;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "PRIME_HT";

								row1.PRIME_HT = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.PRIME_HT = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 33;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "TYPE_QUITTANCE";

								row1.TYPE_QUITTANCE = ParserUtils
										.parseTo_Character(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
							} else {
								row1.TYPE_QUITTANCE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 34;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "SOUS_TYPE_QUITTANCE";

								row1.SOUS_TYPE_QUITTANCE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.SOUS_TYPE_QUITTANCE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							columnIndex_tFileInputExcel_1 = 35;

							if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
								curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
										+ start_column_tFileInputExcel_1 + 1;
								curColName_tFileInputExcel_1 = "REGION_COMMERCIALE";

								row1.REGION_COMMERCIALE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
							} else {
								row1.REGION_COMMERCIALE = null;
								emptyColumnCount_tFileInputExcel_1++;
							}
							nb_line_tFileInputExcel_1++;

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputExcel_1_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputExcel_1 = true;
							System.err.println(e.getMessage());
							row1 = null;
						}

						/**
						 * [tFileInputExcel_1 begin ] stop
						 */

						/**
						 * [tFileInputExcel_1 main ] start
						 */

						currentComponent = "tFileInputExcel_1";

						tos_count_tFileInputExcel_1++;

						/**
						 * [tFileInputExcel_1 main ] stop
						 */

						/**
						 * [tFileInputExcel_1 process_data_begin ] start
						 */

						currentComponent = "tFileInputExcel_1";

						/**
						 * [tFileInputExcel_1 process_data_begin ] stop
						 */
// Start of branch "row1"
						if (row1 != null) {

							/**
							 * [tMap_1 main ] start
							 */

							currentComponent = "tMap_1";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row1"

								);
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_1 = false;
							boolean mainRowRejected_tMap_1 = false;

							///////////////////////////////////////////////
							// Starting Lookup Table "row2"
							///////////////////////////////////////////////

							boolean forceLooprow2 = false;

							row2Struct row2ObjectFromLookup = null;

							if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								hasCasePrimitiveKeyWithNull_tMap_1 = false;

								row2HashKey.POLICE = row1.POLICE;

								row2HashKey.hashCodeDirty = true;

								tHash_Lookup_row2.lookup(row2HashKey);

							} // G_TM_M_020

							if (tHash_Lookup_row2 != null && tHash_Lookup_row2.getCount(row2HashKey) > 1) { // G 071

								// System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row2'
								// and it contains more one result from keys : row2.POLICE = '" +
								// row2HashKey.POLICE + "'");
							} // G 071

							row2Struct row2 = null;

							row2Struct fromLookup_row2 = null;
							row2 = row2Default;

							if (tHash_Lookup_row2 != null && tHash_Lookup_row2.hasNext()) { // G 099

								fromLookup_row2 = tHash_Lookup_row2.next();

							} // G 099

							if (fromLookup_row2 != null) {
								row2 = fromLookup_row2;
							}

							///////////////////////////////////////////////
							// Starting Lookup Table "row3"
							///////////////////////////////////////////////

							boolean forceLooprow3 = false;

							row3Struct row3ObjectFromLookup = null;

							if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								tHash_Lookup_row3.lookup(row3HashKey);

								if (!tHash_Lookup_row3.hasNext()) { // G_TM_M_090

									forceLooprow3 = true;

								} // G_TM_M_090

							} // G_TM_M_020

							else { // G 20 - G 21
								forceLooprow3 = true;
							} // G 21

							row3Struct row3 = null;

							while ((tHash_Lookup_row3 != null && tHash_Lookup_row3.hasNext()) || forceLooprow3) { // G_TM_M_043

								// CALL close loop of lookup 'row3'

								row3Struct fromLookup_row3 = null;
								row3 = row3Default;

								if (!forceLooprow3) { // G 46

									fromLookup_row3 = tHash_Lookup_row3.next();

									if (fromLookup_row3 != null) {
										row3 = fromLookup_row3;
									}

								} // G 46

								forceLooprow3 = false;

								///////////////////////////////////////////////
								// Starting Lookup Table "row4"
								///////////////////////////////////////////////

								boolean forceLooprow4 = false;

								row4Struct row4ObjectFromLookup = null;

								if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

									tHash_Lookup_row4.lookup(row4HashKey);

									if (!tHash_Lookup_row4.hasNext()) { // G_TM_M_090

										forceLooprow4 = true;

									} // G_TM_M_090

								} // G_TM_M_020

								else { // G 20 - G 21
									forceLooprow4 = true;
								} // G 21

								row4Struct row4 = null;

								while ((tHash_Lookup_row4 != null && tHash_Lookup_row4.hasNext()) || forceLooprow4) { // G_TM_M_043

									// CALL close loop of lookup 'row4'

									row4Struct fromLookup_row4 = null;
									row4 = row4Default;

									if (!forceLooprow4) { // G 46

										fromLookup_row4 = tHash_Lookup_row4.next();

										if (fromLookup_row4 != null) {
											row4 = fromLookup_row4;
										}

									} // G 46

									forceLooprow4 = false;

									///////////////////////////////////////////////
									// Starting Lookup Table "row5"
									///////////////////////////////////////////////

									boolean forceLooprow5 = false;

									row5Struct row5ObjectFromLookup = null;

									if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

										tHash_Lookup_row5.lookup(row5HashKey);

										if (!tHash_Lookup_row5.hasNext()) { // G_TM_M_090

											forceLooprow5 = true;

										} // G_TM_M_090

									} // G_TM_M_020

									else { // G 20 - G 21
										forceLooprow5 = true;
									} // G 21

									row5Struct row5 = null;

									while ((tHash_Lookup_row5 != null && tHash_Lookup_row5.hasNext())
											|| forceLooprow5) { // G_TM_M_043

										// CALL close loop of lookup 'row5'

										row5Struct fromLookup_row5 = null;
										row5 = row5Default;

										if (!forceLooprow5) { // G 46

											fromLookup_row5 = tHash_Lookup_row5.next();

											if (fromLookup_row5 != null) {
												row5 = fromLookup_row5;
											}

										} // G 46

										forceLooprow5 = false;

										///////////////////////////////////////////////
										// Starting Lookup Table "row6"
										///////////////////////////////////////////////

										boolean forceLooprow6 = false;

										row6Struct row6ObjectFromLookup = null;

										if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

											tHash_Lookup_row6.lookup(row6HashKey);

											if (!tHash_Lookup_row6.hasNext()) { // G_TM_M_090

												forceLooprow6 = true;

											} // G_TM_M_090

										} // G_TM_M_020

										else { // G 20 - G 21
											forceLooprow6 = true;
										} // G 21

										row6Struct row6 = null;

										while ((tHash_Lookup_row6 != null && tHash_Lookup_row6.hasNext())
												|| forceLooprow6) { // G_TM_M_043

											// CALL close loop of lookup 'row6'

											row6Struct fromLookup_row6 = null;
											row6 = row6Default;

											if (!forceLooprow6) { // G 46

												fromLookup_row6 = tHash_Lookup_row6.next();

												if (fromLookup_row6 != null) {
													row6 = fromLookup_row6;
												}

											} // G 46

											forceLooprow6 = false;

											///////////////////////////////////////////////
											// Starting Lookup Table "row7"
											///////////////////////////////////////////////

											boolean forceLooprow7 = false;

											row7Struct row7ObjectFromLookup = null;

											if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

												tHash_Lookup_row7.lookup(row7HashKey);

												if (!tHash_Lookup_row7.hasNext()) { // G_TM_M_090

													forceLooprow7 = true;

												} // G_TM_M_090

											} // G_TM_M_020

											else { // G 20 - G 21
												forceLooprow7 = true;
											} // G 21

											row7Struct row7 = null;

											while ((tHash_Lookup_row7 != null && tHash_Lookup_row7.hasNext())
													|| forceLooprow7) { // G_TM_M_043

												// CALL close loop of lookup 'row7'

												row7Struct fromLookup_row7 = null;
												row7 = row7Default;

												if (!forceLooprow7) { // G 46

													fromLookup_row7 = tHash_Lookup_row7.next();

													if (fromLookup_row7 != null) {
														row7 = fromLookup_row7;
													}

												} // G 46

												forceLooprow7 = false;

												///////////////////////////////////////////////
												// Starting Lookup Table "row9"
												///////////////////////////////////////////////

												boolean forceLooprow9 = false;

												row9Struct row9ObjectFromLookup = null;

												if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

													tHash_Lookup_row9.lookup(row9HashKey);

													if (!tHash_Lookup_row9.hasNext()) { // G_TM_M_090

														forceLooprow9 = true;

													} // G_TM_M_090

												} // G_TM_M_020

												else { // G 20 - G 21
													forceLooprow9 = true;
												} // G 21

												row9Struct row9 = null;

												while ((tHash_Lookup_row9 != null && tHash_Lookup_row9.hasNext())
														|| forceLooprow9) { // G_TM_M_043

													// CALL close loop of lookup 'row9'

													row9Struct fromLookup_row9 = null;
													row9 = row9Default;

													if (!forceLooprow9) { // G 46

														fromLookup_row9 = tHash_Lookup_row9.next();

														if (fromLookup_row9 != null) {
															row9 = fromLookup_row9;
														}

													} // G 46

													forceLooprow9 = false;

													///////////////////////////////////////////////
													// Starting Lookup Table "row8"
													///////////////////////////////////////////////

													boolean forceLooprow8 = false;

													row8Struct row8ObjectFromLookup = null;

													if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

														tHash_Lookup_row8.lookup(row8HashKey);

														if (!tHash_Lookup_row8.hasNext()) { // G_TM_M_090

															forceLooprow8 = true;

														} // G_TM_M_090

													} // G_TM_M_020

													else { // G 20 - G 21
														forceLooprow8 = true;
													} // G 21

													row8Struct row8 = null;

													while ((tHash_Lookup_row8 != null && tHash_Lookup_row8.hasNext())
															|| forceLooprow8) { // G_TM_M_043

														// CALL close loop of lookup 'row8'

														row8Struct fromLookup_row8 = null;
														row8 = row8Default;

														if (!forceLooprow8) { // G 46

															fromLookup_row8 = tHash_Lookup_row8.next();

															if (fromLookup_row8 != null) {
																row8 = fromLookup_row8;
															}

														} // G 46

														forceLooprow8 = false;

														// ###############################
														{ // start of Var scope

															// ###############################
															// # Vars tables

															Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
															// ###############################
															// # Output tables

// ###############################

														} // end of Var scope

														rejectedInnerJoin_tMap_1 = false;

														tos_count_tMap_1++;

														/**
														 * [tMap_1 main ] stop
														 */

														/**
														 * [tMap_1 process_data_begin ] start
														 */

														currentComponent = "tMap_1";

														/**
														 * [tMap_1 process_data_begin ] stop
														 */
													} // close loop of lookup 'row8' // G_TM_M_043

												} // close loop of lookup 'row9' // G_TM_M_043

											} // close loop of lookup 'row7' // G_TM_M_043

										} // close loop of lookup 'row6' // G_TM_M_043

									} // close loop of lookup 'row5' // G_TM_M_043

								} // close loop of lookup 'row4' // G_TM_M_043

							} // close loop of lookup 'row3' // G_TM_M_043

							/**
							 * [tMap_1 process_data_end ] start
							 */

							currentComponent = "tMap_1";

							/**
							 * [tMap_1 process_data_end ] stop
							 */

						} // End of branch "row1"

						/**
						 * [tFileInputExcel_1 process_data_end ] start
						 */

						currentComponent = "tFileInputExcel_1";

						/**
						 * [tFileInputExcel_1 process_data_end ] stop
						 */

						/**
						 * [tFileInputExcel_1 end ] start
						 */

						currentComponent = "tFileInputExcel_1";

					}

					try {
						if (excelReader_tFileInputExcel_1 != null) {
							excelReader_tFileInputExcel_1.handleException();
						}
					} catch (java.lang.Exception e_tFileInputExcel_1) {
						globalMap.put("tFileInputExcel_1_ERROR_MESSAGE", e_tFileInputExcel_1.getMessage());
						if (!(e_tFileInputExcel_1
								.getCause() instanceof com.talend.excel.xssf.event.EnoughDataException)) {

							System.err.println(e_tFileInputExcel_1.getMessage());

						}
					}

					globalMap.put("tFileInputExcel_1_NB_LINE", nb_line_tFileInputExcel_1);

				} finally {

				}

				ok_Hash.put("tFileInputExcel_1", true);
				end_Hash.put("tFileInputExcel_1", System.currentTimeMillis());

				/**
				 * [tFileInputExcel_1 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

// ###############################
// # Lookup hashes releasing
				if (tHash_Lookup_row2 != null) {
					tHash_Lookup_row2.endGet();
				}
				globalMap.remove("tHash_Lookup_row2");

				if (tHash_Lookup_row3 != null) {
					tHash_Lookup_row3.endGet();
				}
				globalMap.remove("tHash_Lookup_row3");

				if (tHash_Lookup_row4 != null) {
					tHash_Lookup_row4.endGet();
				}
				globalMap.remove("tHash_Lookup_row4");

				if (tHash_Lookup_row5 != null) {
					tHash_Lookup_row5.endGet();
				}
				globalMap.remove("tHash_Lookup_row5");

				if (tHash_Lookup_row6 != null) {
					tHash_Lookup_row6.endGet();
				}
				globalMap.remove("tHash_Lookup_row6");

				if (tHash_Lookup_row7 != null) {
					tHash_Lookup_row7.endGet();
				}
				globalMap.remove("tHash_Lookup_row7");

				if (tHash_Lookup_row9 != null) {
					tHash_Lookup_row9.endGet();
				}
				globalMap.remove("tHash_Lookup_row9");

				if (tHash_Lookup_row8 != null) {
					tHash_Lookup_row8.endGet();
				}
				globalMap.remove("tHash_Lookup_row8");

// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row1");
				}

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_row2");

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_row3");

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_row4");

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_row5");

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_row6");

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_row7");

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_row8");

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_row9");

			try {

				/**
				 * [tFileInputExcel_1 finally ] start
				 */

				currentComponent = "tFileInputExcel_1";

				/**
				 * [tFileInputExcel_1 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 1);
	}

	public static class row2Struct implements routines.system.IPersistableComparableLookupRow<row2Struct> {
		final static byte[] commonByteArrayLock_STAR_ASSURANCE_factPrime = new byte[0];
		static byte[] commonByteArray_STAR_ASSURANCE_factPrime = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int PK_Police;

		public int getPK_Police() {
			return this.PK_Police;
		}

		public String POLICE;

		public String getPOLICE() {
			return this.POLICE;
		}

		public String TYPE_POLICE;

		public String getTYPE_POLICE() {
			return this.TYPE_POLICE;
		}

		public String TACITE_RECONDUCTION;

		public String getTACITE_RECONDUCTION() {
			return this.TACITE_RECONDUCTION;
		}

		public String FRACTIONNEMENT;

		public String getFRACTIONNEMENT() {
			return this.FRACTIONNEMENT;
		}

		public java.util.Date EFFET_ORIGINE;

		public java.util.Date getEFFET_ORIGINE() {
			return this.EFFET_ORIGINE;
		}

		public java.util.Date ECHEANCE_ORIGINE;

		public java.util.Date getECHEANCE_ORIGINE() {
			return this.ECHEANCE_ORIGINE;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.POLICE == null) ? 0 : this.POLICE.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row2Struct other = (row2Struct) obj;

			if (this.POLICE == null) {
				if (other.POLICE != null)
					return false;

			} else if (!this.POLICE.equals(other.POLICE))

				return false;

			return true;
		}

		public void copyDataTo(row2Struct other) {

			other.PK_Police = this.PK_Police;
			other.POLICE = this.POLICE;
			other.TYPE_POLICE = this.TYPE_POLICE;
			other.TACITE_RECONDUCTION = this.TACITE_RECONDUCTION;
			other.FRACTIONNEMENT = this.FRACTIONNEMENT;
			other.EFFET_ORIGINE = this.EFFET_ORIGINE;
			other.ECHEANCE_ORIGINE = this.ECHEANCE_ORIGINE;

		}

		public void copyKeysDataTo(row2Struct other) {

			other.POLICE = this.POLICE;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_factPrime.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_factPrime.length == 0) {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_STAR_ASSURANCE_factPrime, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_factPrime, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_factPrime.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_factPrime.length == 0) {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_STAR_ASSURANCE_factPrime, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_factPrime, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				dis.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				unmarshaller.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private java.util.Date readDate(DataInputStream dis, ObjectInputStream ois) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.POLICE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.POLICE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.POLICE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.POLICE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

				this.PK_Police = dis.readInt();

				this.TYPE_POLICE = readString(dis, ois);

				this.TACITE_RECONDUCTION = readString(dis, ois);

				this.FRACTIONNEMENT = readString(dis, ois);

				this.EFFET_ORIGINE = readDate(dis, ois);

				this.ECHEANCE_ORIGINE = readDate(dis, ois);

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
			try {
				int length = 0;

				this.PK_Police = objectIn.readInt();

				this.TYPE_POLICE = readString(dis, objectIn);

				this.TACITE_RECONDUCTION = readString(dis, objectIn);

				this.FRACTIONNEMENT = readString(dis, objectIn);

				this.EFFET_ORIGINE = readDate(dis, objectIn);

				this.ECHEANCE_ORIGINE = readDate(dis, objectIn);

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

				dos.writeInt(this.PK_Police);

				writeString(this.TYPE_POLICE, dos, oos);

				writeString(this.TACITE_RECONDUCTION, dos, oos);

				writeString(this.FRACTIONNEMENT, dos, oos);

				writeDate(this.EFFET_ORIGINE, dos, oos);

				writeDate(this.ECHEANCE_ORIGINE, dos, oos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut) {
			try {

				objectOut.writeInt(this.PK_Police);

				writeString(this.TYPE_POLICE, dos, objectOut);

				writeString(this.TACITE_RECONDUCTION, dos, objectOut);

				writeString(this.FRACTIONNEMENT, dos, objectOut);

				writeDate(this.EFFET_ORIGINE, dos, objectOut);

				writeDate(this.ECHEANCE_ORIGINE, dos, objectOut);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		public boolean supportMarshaller() {
			return true;
		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PK_Police=" + String.valueOf(PK_Police));
			sb.append(",POLICE=" + POLICE);
			sb.append(",TYPE_POLICE=" + TYPE_POLICE);
			sb.append(",TACITE_RECONDUCTION=" + TACITE_RECONDUCTION);
			sb.append(",FRACTIONNEMENT=" + FRACTIONNEMENT);
			sb.append(",EFFET_ORIGINE=" + String.valueOf(EFFET_ORIGINE));
			sb.append(",ECHEANCE_ORIGINE=" + String.valueOf(ECHEANCE_ORIGINE));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.POLICE, other.POLICE);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row2Struct row2 = new row2Struct();

				/**
				 * [tAdvancedHash_row2 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row2", false);
				start_Hash.put("tAdvancedHash_row2", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row2";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row2");
				}

				int tos_count_tAdvancedHash_row2 = 0;

				// connection name:row2
				// source node:tDBInput_1 - inputs:(after_tFileInputExcel_1) outputs:(row2,row2)
				// | target node:tAdvancedHash_row2 - inputs:(row2) outputs:()
				// linked node: tMap_1 - inputs:(row1,row2,row3,row4,row5,row6,row7,row8,row9)
				// outputs:()

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row2 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct> tHash_Lookup_row2 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row2Struct>getLookup(matchingModeEnum_row2);

				globalMap.put("tHash_Lookup_row2", tHash_Lookup_row2);

				/**
				 * [tAdvancedHash_row2 begin ] stop
				 */

				/**
				 * [tDBInput_1 begin ] start
				 */

				ok_Hash.put("tDBInput_1", false);
				start_Hash.put("tDBInput_1", System.currentTimeMillis());

				currentComponent = "tDBInput_1";

				int tos_count_tDBInput_1 = 0;

				org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_1 = org.talend.designer.components.util.mssql.MSSqlUtilFactory
						.getMSSqlGenerateTimestampUtil();

				java.util.List<String> talendToDBList_tDBInput_1 = new java.util.ArrayList();
				String[] talendToDBArray_tDBInput_1 = new String[] { "FLOAT", "NUMERIC", "NUMERIC IDENTITY", "DECIMAL",
						"DECIMAL IDENTITY", "REAL" };
				java.util.Collections.addAll(talendToDBList_tDBInput_1, talendToDBArray_tDBInput_1);
				int nb_line_tDBInput_1 = 0;
				java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
				java.lang.Class jdbcclazz_tDBInput_1 = java.lang.Class.forName(driverClass_tDBInput_1);
				String dbUser_tDBInput_1 = "talend_user";

				final String decryptedPassword_tDBInput_1 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:vMO4klarWxLHffL8XN7bmczAyzqUr0kcSl/gt8P3ltIN/4ZbKYA=");

				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;

				String port_tDBInput_1 = "1433";
				String dbname_tDBInput_1 = "AUTO_DWH";
				String url_tDBInput_1 = "jdbc:sqlserver://" + "DESKTOP-6EEKMMP";
				if (!"".equals(port_tDBInput_1)) {
					url_tDBInput_1 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBInput_1)) {
					url_tDBInput_1 += ";databaseName=" + "AUTO_DWH";
				}
				url_tDBInput_1 += ";appName=" + projectName + ";" + "trustServerCertificate=true";
				String dbschema_tDBInput_1 = "dbo";

				conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1, dbUser_tDBInput_1,
						dbPwd_tDBInput_1);

				java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

				String dbquery_tDBInput_1 = "SELECT dbo.Dim_Contrat.PK_Police,\n		dbo.Dim_Contrat.POLICE,\n		dbo.Dim_Contrat.TYPE_POLICE,\n		dbo.Dim_Contrat.TACITE_REC"
						+ "ONDUCTION,\n		dbo.Dim_Contrat.FRACTIONNEMENT,\n		dbo.Dim_Contrat.EFFET_ORIGINE,\n		dbo.Dim_Contrat.ECHEANCE_ORIGINE\nFROM	db"
						+ "o.Dim_Contrat";

				globalMap.put("tDBInput_1_QUERY", dbquery_tDBInput_1);
				java.sql.ResultSet rs_tDBInput_1 = null;

				try {
					rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
					java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
					int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

					String tmpContent_tDBInput_1 = null;

					while (rs_tDBInput_1.next()) {
						nb_line_tDBInput_1++;

						if (colQtyInRs_tDBInput_1 < 1) {
							row2.PK_Police = 0;
						} else {

							row2.PK_Police = rs_tDBInput_1.getInt(1);
							if (rs_tDBInput_1.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_1 < 2) {
							row2.POLICE = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(2);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(2).toUpperCase(java.util.Locale.ENGLISH))) {
									row2.POLICE = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row2.POLICE = tmpContent_tDBInput_1;
								}
							} else {
								row2.POLICE = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 3) {
							row2.TYPE_POLICE = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(3);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
									row2.TYPE_POLICE = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row2.TYPE_POLICE = tmpContent_tDBInput_1;
								}
							} else {
								row2.TYPE_POLICE = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 4) {
							row2.TACITE_RECONDUCTION = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(4);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
									row2.TACITE_RECONDUCTION = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row2.TACITE_RECONDUCTION = tmpContent_tDBInput_1;
								}
							} else {
								row2.TACITE_RECONDUCTION = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 5) {
							row2.FRACTIONNEMENT = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(5);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(5).toUpperCase(java.util.Locale.ENGLISH))) {
									row2.FRACTIONNEMENT = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row2.FRACTIONNEMENT = tmpContent_tDBInput_1;
								}
							} else {
								row2.FRACTIONNEMENT = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 6) {
							row2.EFFET_ORIGINE = null;
						} else {

							row2.EFFET_ORIGINE = mssqlGTU_tDBInput_1.getDate(rsmd_tDBInput_1, rs_tDBInput_1, 6);

						}
						if (colQtyInRs_tDBInput_1 < 7) {
							row2.ECHEANCE_ORIGINE = null;
						} else {

							row2.ECHEANCE_ORIGINE = mssqlGTU_tDBInput_1.getDate(rsmd_tDBInput_1, rs_tDBInput_1, 7);

						}

						/**
						 * [tDBInput_1 begin ] stop
						 */

						/**
						 * [tDBInput_1 main ] start
						 */

						currentComponent = "tDBInput_1";

						tos_count_tDBInput_1++;

						/**
						 * [tDBInput_1 main ] stop
						 */

						/**
						 * [tDBInput_1 process_data_begin ] start
						 */

						currentComponent = "tDBInput_1";

						/**
						 * [tDBInput_1 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_row2 main ] start
						 */

						currentComponent = "tAdvancedHash_row2";

						if (execStat) {
							runStat.updateStatOnConnection(iterateId, 1, 1

									, "row2"

							);
						}

						row2Struct row2_HashRow = new row2Struct();

						row2_HashRow.PK_Police = row2.PK_Police;

						row2_HashRow.POLICE = row2.POLICE;

						row2_HashRow.TYPE_POLICE = row2.TYPE_POLICE;

						row2_HashRow.TACITE_RECONDUCTION = row2.TACITE_RECONDUCTION;

						row2_HashRow.FRACTIONNEMENT = row2.FRACTIONNEMENT;

						row2_HashRow.EFFET_ORIGINE = row2.EFFET_ORIGINE;

						row2_HashRow.ECHEANCE_ORIGINE = row2.ECHEANCE_ORIGINE;

						tHash_Lookup_row2.put(row2_HashRow);

						tos_count_tAdvancedHash_row2++;

						/**
						 * [tAdvancedHash_row2 main ] stop
						 */

						/**
						 * [tAdvancedHash_row2 process_data_begin ] start
						 */

						currentComponent = "tAdvancedHash_row2";

						/**
						 * [tAdvancedHash_row2 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_row2 process_data_end ] start
						 */

						currentComponent = "tAdvancedHash_row2";

						/**
						 * [tAdvancedHash_row2 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 process_data_end ] start
						 */

						currentComponent = "tDBInput_1";

						/**
						 * [tDBInput_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 end ] start
						 */

						currentComponent = "tDBInput_1";

					}
				} finally {
					if (rs_tDBInput_1 != null) {
						rs_tDBInput_1.close();
					}
					if (stmt_tDBInput_1 != null) {
						stmt_tDBInput_1.close();
					}
					if (conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {

						conn_tDBInput_1.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

					}
				}
				globalMap.put("tDBInput_1_NB_LINE", nb_line_tDBInput_1);

				ok_Hash.put("tDBInput_1", true);
				end_Hash.put("tDBInput_1", System.currentTimeMillis());

				/**
				 * [tDBInput_1 end ] stop
				 */

				/**
				 * [tAdvancedHash_row2 end ] start
				 */

				currentComponent = "tAdvancedHash_row2";

				tHash_Lookup_row2.endPut();

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row2");
				}

				ok_Hash.put("tAdvancedHash_row2", true);
				end_Hash.put("tAdvancedHash_row2", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row2 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_1 finally ] start
				 */

				currentComponent = "tDBInput_1";

				/**
				 * [tDBInput_1 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row2 finally ] start
				 */

				currentComponent = "tAdvancedHash_row2";

				/**
				 * [tAdvancedHash_row2 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}

	public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_STAR_ASSURANCE_factPrime = new byte[0];
		static byte[] commonByteArray_STAR_ASSURANCE_factPrime = new byte[0];

		public int Date_PK;

		public int getDate_PK() {
			return this.Date_PK;
		}

		public java.util.Date Date;

		public java.util.Date getDate() {
			return this.Date;
		}

		public String Jour_Moi_Annee;

		public String getJour_Moi_Annee() {
			return this.Jour_Moi_Annee;
		}

		public Integer Annee;

		public Integer getAnnee() {
			return this.Annee;
		}

		public String ID_Semestre;

		public String getID_Semestre() {
			return this.ID_Semestre;
		}

		public String Semestre;

		public String getSemestre() {
			return this.Semestre;
		}

		public String ID_Trimestre;

		public String getID_Trimestre() {
			return this.ID_Trimestre;
		}

		public String Trimestre;

		public String getTrimestre() {
			return this.Trimestre;
		}

		public Integer ID_Mois;

		public Integer getID_Mois() {
			return this.ID_Mois;
		}

		public Integer Mois;

		public Integer getMois() {
			return this.Mois;
		}

		public String Lib_Mois;

		public String getLib_Mois() {
			return this.Lib_Mois;
		}

		public Integer Jour;

		public Integer getJour() {
			return this.Jour;
		}

		public Integer Id_Lib_Jour;

		public Integer getId_Lib_Jour() {
			return this.Id_Lib_Jour;
		}

		public String Lib_Jour;

		public String getLib_Jour() {
			return this.Lib_Jour;
		}

		public Integer Semaine;

		public Integer getSemaine() {
			return this.Semaine;
		}

		public Integer JourDeAnnee;

		public Integer getJourDeAnnee() {
			return this.JourDeAnnee;
		}

		public String Jour_mois_lettre;

		public String getJour_mois_lettre() {
			return this.Jour_mois_lettre;
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_factPrime.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_factPrime.length == 0) {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_STAR_ASSURANCE_factPrime, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_factPrime, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_factPrime.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_factPrime.length == 0) {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_STAR_ASSURANCE_factPrime, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_factPrime, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.Date_PK = dis.readInt();

					this.Date = readDate(dis);

					this.Jour_Moi_Annee = readString(dis);

					this.Annee = readInteger(dis);

					this.ID_Semestre = readString(dis);

					this.Semestre = readString(dis);

					this.ID_Trimestre = readString(dis);

					this.Trimestre = readString(dis);

					this.ID_Mois = readInteger(dis);

					this.Mois = readInteger(dis);

					this.Lib_Mois = readString(dis);

					this.Jour = readInteger(dis);

					this.Id_Lib_Jour = readInteger(dis);

					this.Lib_Jour = readString(dis);

					this.Semaine = readInteger(dis);

					this.JourDeAnnee = readInteger(dis);

					this.Jour_mois_lettre = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.Date_PK = dis.readInt();

					this.Date = readDate(dis);

					this.Jour_Moi_Annee = readString(dis);

					this.Annee = readInteger(dis);

					this.ID_Semestre = readString(dis);

					this.Semestre = readString(dis);

					this.ID_Trimestre = readString(dis);

					this.Trimestre = readString(dis);

					this.ID_Mois = readInteger(dis);

					this.Mois = readInteger(dis);

					this.Lib_Mois = readString(dis);

					this.Jour = readInteger(dis);

					this.Id_Lib_Jour = readInteger(dis);

					this.Lib_Jour = readString(dis);

					this.Semaine = readInteger(dis);

					this.JourDeAnnee = readInteger(dis);

					this.Jour_mois_lettre = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.Date_PK);

				// java.util.Date

				writeDate(this.Date, dos);

				// String

				writeString(this.Jour_Moi_Annee, dos);

				// Integer

				writeInteger(this.Annee, dos);

				// String

				writeString(this.ID_Semestre, dos);

				// String

				writeString(this.Semestre, dos);

				// String

				writeString(this.ID_Trimestre, dos);

				// String

				writeString(this.Trimestre, dos);

				// Integer

				writeInteger(this.ID_Mois, dos);

				// Integer

				writeInteger(this.Mois, dos);

				// String

				writeString(this.Lib_Mois, dos);

				// Integer

				writeInteger(this.Jour, dos);

				// Integer

				writeInteger(this.Id_Lib_Jour, dos);

				// String

				writeString(this.Lib_Jour, dos);

				// Integer

				writeInteger(this.Semaine, dos);

				// Integer

				writeInteger(this.JourDeAnnee, dos);

				// String

				writeString(this.Jour_mois_lettre, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.Date_PK);

				// java.util.Date

				writeDate(this.Date, dos);

				// String

				writeString(this.Jour_Moi_Annee, dos);

				// Integer

				writeInteger(this.Annee, dos);

				// String

				writeString(this.ID_Semestre, dos);

				// String

				writeString(this.Semestre, dos);

				// String

				writeString(this.ID_Trimestre, dos);

				// String

				writeString(this.Trimestre, dos);

				// Integer

				writeInteger(this.ID_Mois, dos);

				// Integer

				writeInteger(this.Mois, dos);

				// String

				writeString(this.Lib_Mois, dos);

				// Integer

				writeInteger(this.Jour, dos);

				// Integer

				writeInteger(this.Id_Lib_Jour, dos);

				// String

				writeString(this.Lib_Jour, dos);

				// Integer

				writeInteger(this.Semaine, dos);

				// Integer

				writeInteger(this.JourDeAnnee, dos);

				// String

				writeString(this.Jour_mois_lettre, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Date_PK=" + String.valueOf(Date_PK));
			sb.append(",Date=" + String.valueOf(Date));
			sb.append(",Jour_Moi_Annee=" + Jour_Moi_Annee);
			sb.append(",Annee=" + String.valueOf(Annee));
			sb.append(",ID_Semestre=" + ID_Semestre);
			sb.append(",Semestre=" + Semestre);
			sb.append(",ID_Trimestre=" + ID_Trimestre);
			sb.append(",Trimestre=" + Trimestre);
			sb.append(",ID_Mois=" + String.valueOf(ID_Mois));
			sb.append(",Mois=" + String.valueOf(Mois));
			sb.append(",Lib_Mois=" + Lib_Mois);
			sb.append(",Jour=" + String.valueOf(Jour));
			sb.append(",Id_Lib_Jour=" + String.valueOf(Id_Lib_Jour));
			sb.append(",Lib_Jour=" + Lib_Jour);
			sb.append(",Semaine=" + String.valueOf(Semaine));
			sb.append(",JourDeAnnee=" + String.valueOf(JourDeAnnee));
			sb.append(",Jour_mois_lettre=" + Jour_mois_lettre);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row3Struct row3 = new row3Struct();

				/**
				 * [tAdvancedHash_row3 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row3", false);
				start_Hash.put("tAdvancedHash_row3", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row3";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row3");
				}

				int tos_count_tAdvancedHash_row3 = 0;

				// connection name:row3
				// source node:tDBInput_2 - inputs:(after_tFileInputExcel_1) outputs:(row3,row3)
				// | target node:tAdvancedHash_row3 - inputs:(row3) outputs:()
				// linked node: tMap_1 - inputs:(row1,row2,row3,row4,row5,row6,row7,row8,row9)
				// outputs:()

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row3 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.ALL_ROWS;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct> tHash_Lookup_row3 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row3Struct>getLookup(matchingModeEnum_row3);

				globalMap.put("tHash_Lookup_row3", tHash_Lookup_row3);

				/**
				 * [tAdvancedHash_row3 begin ] stop
				 */

				/**
				 * [tDBInput_2 begin ] start
				 */

				ok_Hash.put("tDBInput_2", false);
				start_Hash.put("tDBInput_2", System.currentTimeMillis());

				currentComponent = "tDBInput_2";

				int tos_count_tDBInput_2 = 0;

				org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_2 = org.talend.designer.components.util.mssql.MSSqlUtilFactory
						.getMSSqlGenerateTimestampUtil();

				java.util.List<String> talendToDBList_tDBInput_2 = new java.util.ArrayList();
				String[] talendToDBArray_tDBInput_2 = new String[] { "FLOAT", "NUMERIC", "NUMERIC IDENTITY", "DECIMAL",
						"DECIMAL IDENTITY", "REAL" };
				java.util.Collections.addAll(talendToDBList_tDBInput_2, talendToDBArray_tDBInput_2);
				int nb_line_tDBInput_2 = 0;
				java.sql.Connection conn_tDBInput_2 = null;
				String driverClass_tDBInput_2 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
				java.lang.Class jdbcclazz_tDBInput_2 = java.lang.Class.forName(driverClass_tDBInput_2);
				String dbUser_tDBInput_2 = "talend_user";

				final String decryptedPassword_tDBInput_2 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:7mqxmyR/i5sNeMiwDd/nYfjbApkcgvZKmVwjCNVMai+0s8Gy6pk=");

				String dbPwd_tDBInput_2 = decryptedPassword_tDBInput_2;

				String port_tDBInput_2 = "1433";
				String dbname_tDBInput_2 = "AUTO_DWH";
				String url_tDBInput_2 = "jdbc:sqlserver://" + "DESKTOP-6EEKMMP";
				if (!"".equals(port_tDBInput_2)) {
					url_tDBInput_2 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBInput_2)) {
					url_tDBInput_2 += ";databaseName=" + "AUTO_DWH";
				}
				url_tDBInput_2 += ";appName=" + projectName + ";" + "trustServerCertificate=true";
				String dbschema_tDBInput_2 = "dbo";

				conn_tDBInput_2 = java.sql.DriverManager.getConnection(url_tDBInput_2, dbUser_tDBInput_2,
						dbPwd_tDBInput_2);

				java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();

				String dbquery_tDBInput_2 = "SELECT [Date_PK]\n      ,[Date]\n      ,[Jour_Moi_Annee]\n      ,[Annee]\n      ,[ID_Semestre]\n      ,[Semestre]\n    "
						+ "  ,[ID_Trimestre]\n      ,[Trimestre]\n      ,[ID_Mois]\n      ,[Mois]\n      ,[Lib_Mois]\n      ,[Jour]\n      ,[Id_Lib"
						+ "_Jour]\n      ,[Lib_Jour]\n      ,[Semaine]\n      ,[JourDeAnnee]\n      ,[Jour_mois_lettre]\n  FROM [AUTO_DWH].[dbo].[D"
						+ "imDates]";

				globalMap.put("tDBInput_2_QUERY", dbquery_tDBInput_2);
				java.sql.ResultSet rs_tDBInput_2 = null;

				try {
					rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
					java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
					int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

					String tmpContent_tDBInput_2 = null;

					while (rs_tDBInput_2.next()) {
						nb_line_tDBInput_2++;

						if (colQtyInRs_tDBInput_2 < 1) {
							row3.Date_PK = 0;
						} else {

							row3.Date_PK = rs_tDBInput_2.getInt(1);
							if (rs_tDBInput_2.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_2 < 2) {
							row3.Date = null;
						} else {

							row3.Date = mssqlGTU_tDBInput_2.getDate(rsmd_tDBInput_2, rs_tDBInput_2, 2);

						}
						if (colQtyInRs_tDBInput_2 < 3) {
							row3.Jour_Moi_Annee = null;
						} else {

							tmpContent_tDBInput_2 = rs_tDBInput_2.getString(3);
							if (tmpContent_tDBInput_2 != null) {
								if (talendToDBList_tDBInput_2.contains(
										rsmd_tDBInput_2.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
									row3.Jour_Moi_Annee = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
								} else {
									row3.Jour_Moi_Annee = tmpContent_tDBInput_2;
								}
							} else {
								row3.Jour_Moi_Annee = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 4) {
							row3.Annee = null;
						} else {

							row3.Annee = rs_tDBInput_2.getInt(4);
							if (rs_tDBInput_2.wasNull()) {
								row3.Annee = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 5) {
							row3.ID_Semestre = null;
						} else {

							tmpContent_tDBInput_2 = rs_tDBInput_2.getString(5);
							if (tmpContent_tDBInput_2 != null) {
								if (talendToDBList_tDBInput_2.contains(
										rsmd_tDBInput_2.getColumnTypeName(5).toUpperCase(java.util.Locale.ENGLISH))) {
									row3.ID_Semestre = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
								} else {
									row3.ID_Semestre = tmpContent_tDBInput_2;
								}
							} else {
								row3.ID_Semestre = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 6) {
							row3.Semestre = null;
						} else {

							tmpContent_tDBInput_2 = rs_tDBInput_2.getString(6);
							if (tmpContent_tDBInput_2 != null) {
								if (talendToDBList_tDBInput_2.contains(
										rsmd_tDBInput_2.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
									row3.Semestre = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
								} else {
									row3.Semestre = tmpContent_tDBInput_2;
								}
							} else {
								row3.Semestre = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 7) {
							row3.ID_Trimestre = null;
						} else {

							tmpContent_tDBInput_2 = rs_tDBInput_2.getString(7);
							if (tmpContent_tDBInput_2 != null) {
								if (talendToDBList_tDBInput_2.contains(
										rsmd_tDBInput_2.getColumnTypeName(7).toUpperCase(java.util.Locale.ENGLISH))) {
									row3.ID_Trimestre = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
								} else {
									row3.ID_Trimestre = tmpContent_tDBInput_2;
								}
							} else {
								row3.ID_Trimestre = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 8) {
							row3.Trimestre = null;
						} else {

							tmpContent_tDBInput_2 = rs_tDBInput_2.getString(8);
							if (tmpContent_tDBInput_2 != null) {
								if (talendToDBList_tDBInput_2.contains(
										rsmd_tDBInput_2.getColumnTypeName(8).toUpperCase(java.util.Locale.ENGLISH))) {
									row3.Trimestre = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
								} else {
									row3.Trimestre = tmpContent_tDBInput_2;
								}
							} else {
								row3.Trimestre = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 9) {
							row3.ID_Mois = null;
						} else {

							row3.ID_Mois = rs_tDBInput_2.getInt(9);
							if (rs_tDBInput_2.wasNull()) {
								row3.ID_Mois = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 10) {
							row3.Mois = null;
						} else {

							row3.Mois = rs_tDBInput_2.getInt(10);
							if (rs_tDBInput_2.wasNull()) {
								row3.Mois = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 11) {
							row3.Lib_Mois = null;
						} else {

							tmpContent_tDBInput_2 = rs_tDBInput_2.getString(11);
							if (tmpContent_tDBInput_2 != null) {
								if (talendToDBList_tDBInput_2.contains(
										rsmd_tDBInput_2.getColumnTypeName(11).toUpperCase(java.util.Locale.ENGLISH))) {
									row3.Lib_Mois = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
								} else {
									row3.Lib_Mois = tmpContent_tDBInput_2;
								}
							} else {
								row3.Lib_Mois = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 12) {
							row3.Jour = null;
						} else {

							row3.Jour = rs_tDBInput_2.getInt(12);
							if (rs_tDBInput_2.wasNull()) {
								row3.Jour = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 13) {
							row3.Id_Lib_Jour = null;
						} else {

							row3.Id_Lib_Jour = rs_tDBInput_2.getInt(13);
							if (rs_tDBInput_2.wasNull()) {
								row3.Id_Lib_Jour = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 14) {
							row3.Lib_Jour = null;
						} else {

							tmpContent_tDBInput_2 = rs_tDBInput_2.getString(14);
							if (tmpContent_tDBInput_2 != null) {
								if (talendToDBList_tDBInput_2.contains(
										rsmd_tDBInput_2.getColumnTypeName(14).toUpperCase(java.util.Locale.ENGLISH))) {
									row3.Lib_Jour = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
								} else {
									row3.Lib_Jour = tmpContent_tDBInput_2;
								}
							} else {
								row3.Lib_Jour = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 15) {
							row3.Semaine = null;
						} else {

							row3.Semaine = rs_tDBInput_2.getInt(15);
							if (rs_tDBInput_2.wasNull()) {
								row3.Semaine = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 16) {
							row3.JourDeAnnee = null;
						} else {

							row3.JourDeAnnee = rs_tDBInput_2.getInt(16);
							if (rs_tDBInput_2.wasNull()) {
								row3.JourDeAnnee = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 17) {
							row3.Jour_mois_lettre = null;
						} else {

							tmpContent_tDBInput_2 = rs_tDBInput_2.getString(17);
							if (tmpContent_tDBInput_2 != null) {
								if (talendToDBList_tDBInput_2.contains(
										rsmd_tDBInput_2.getColumnTypeName(17).toUpperCase(java.util.Locale.ENGLISH))) {
									row3.Jour_mois_lettre = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
								} else {
									row3.Jour_mois_lettre = tmpContent_tDBInput_2;
								}
							} else {
								row3.Jour_mois_lettre = null;
							}
						}

						/**
						 * [tDBInput_2 begin ] stop
						 */

						/**
						 * [tDBInput_2 main ] start
						 */

						currentComponent = "tDBInput_2";

						tos_count_tDBInput_2++;

						/**
						 * [tDBInput_2 main ] stop
						 */

						/**
						 * [tDBInput_2 process_data_begin ] start
						 */

						currentComponent = "tDBInput_2";

						/**
						 * [tDBInput_2 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_row3 main ] start
						 */

						currentComponent = "tAdvancedHash_row3";

						if (execStat) {
							runStat.updateStatOnConnection(iterateId, 1, 1

									, "row3"

							);
						}

						row3Struct row3_HashRow = new row3Struct();

						row3_HashRow.Date_PK = row3.Date_PK;

						row3_HashRow.Date = row3.Date;

						row3_HashRow.Jour_Moi_Annee = row3.Jour_Moi_Annee;

						row3_HashRow.Annee = row3.Annee;

						row3_HashRow.ID_Semestre = row3.ID_Semestre;

						row3_HashRow.Semestre = row3.Semestre;

						row3_HashRow.ID_Trimestre = row3.ID_Trimestre;

						row3_HashRow.Trimestre = row3.Trimestre;

						row3_HashRow.ID_Mois = row3.ID_Mois;

						row3_HashRow.Mois = row3.Mois;

						row3_HashRow.Lib_Mois = row3.Lib_Mois;

						row3_HashRow.Jour = row3.Jour;

						row3_HashRow.Id_Lib_Jour = row3.Id_Lib_Jour;

						row3_HashRow.Lib_Jour = row3.Lib_Jour;

						row3_HashRow.Semaine = row3.Semaine;

						row3_HashRow.JourDeAnnee = row3.JourDeAnnee;

						row3_HashRow.Jour_mois_lettre = row3.Jour_mois_lettre;

						tHash_Lookup_row3.put(row3_HashRow);

						tos_count_tAdvancedHash_row3++;

						/**
						 * [tAdvancedHash_row3 main ] stop
						 */

						/**
						 * [tAdvancedHash_row3 process_data_begin ] start
						 */

						currentComponent = "tAdvancedHash_row3";

						/**
						 * [tAdvancedHash_row3 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_row3 process_data_end ] start
						 */

						currentComponent = "tAdvancedHash_row3";

						/**
						 * [tAdvancedHash_row3 process_data_end ] stop
						 */

						/**
						 * [tDBInput_2 process_data_end ] start
						 */

						currentComponent = "tDBInput_2";

						/**
						 * [tDBInput_2 process_data_end ] stop
						 */

						/**
						 * [tDBInput_2 end ] start
						 */

						currentComponent = "tDBInput_2";

					}
				} finally {
					if (rs_tDBInput_2 != null) {
						rs_tDBInput_2.close();
					}
					if (stmt_tDBInput_2 != null) {
						stmt_tDBInput_2.close();
					}
					if (conn_tDBInput_2 != null && !conn_tDBInput_2.isClosed()) {

						conn_tDBInput_2.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

					}
				}
				globalMap.put("tDBInput_2_NB_LINE", nb_line_tDBInput_2);

				ok_Hash.put("tDBInput_2", true);
				end_Hash.put("tDBInput_2", System.currentTimeMillis());

				/**
				 * [tDBInput_2 end ] stop
				 */

				/**
				 * [tAdvancedHash_row3 end ] start
				 */

				currentComponent = "tAdvancedHash_row3";

				tHash_Lookup_row3.endPut();

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row3");
				}

				ok_Hash.put("tAdvancedHash_row3", true);
				end_Hash.put("tAdvancedHash_row3", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row3 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_2 finally ] start
				 */

				currentComponent = "tDBInput_2";

				/**
				 * [tDBInput_2 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row3 finally ] start
				 */

				currentComponent = "tAdvancedHash_row3";

				/**
				 * [tAdvancedHash_row3 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}

	public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
		final static byte[] commonByteArrayLock_STAR_ASSURANCE_factPrime = new byte[0];
		static byte[] commonByteArray_STAR_ASSURANCE_factPrime = new byte[0];

		public int idPack;

		public int getIdPack() {
			return this.idPack;
		}

		public String TYPE_PACK;

		public String getTYPE_PACK() {
			return this.TYPE_PACK;
		}

		public Integer CODE_PRODUIT;

		public Integer getCODE_PRODUIT() {
			return this.CODE_PRODUIT;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_factPrime.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_factPrime.length == 0) {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_STAR_ASSURANCE_factPrime, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_factPrime, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_factPrime.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_factPrime.length == 0) {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_STAR_ASSURANCE_factPrime, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_factPrime, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.idPack = dis.readInt();

					this.TYPE_PACK = readString(dis);

					this.CODE_PRODUIT = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.idPack = dis.readInt();

					this.TYPE_PACK = readString(dis);

					this.CODE_PRODUIT = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.idPack);

				// String

				writeString(this.TYPE_PACK, dos);

				// Integer

				writeInteger(this.CODE_PRODUIT, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.idPack);

				// String

				writeString(this.TYPE_PACK, dos);

				// Integer

				writeInteger(this.CODE_PRODUIT, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("idPack=" + String.valueOf(idPack));
			sb.append(",TYPE_PACK=" + TYPE_PACK);
			sb.append(",CODE_PRODUIT=" + String.valueOf(CODE_PRODUIT));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row4Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_3_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row4Struct row4 = new row4Struct();

				/**
				 * [tAdvancedHash_row4 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row4", false);
				start_Hash.put("tAdvancedHash_row4", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row4";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row4");
				}

				int tos_count_tAdvancedHash_row4 = 0;

				// connection name:row4
				// source node:tDBInput_3 - inputs:(after_tFileInputExcel_1) outputs:(row4,row4)
				// | target node:tAdvancedHash_row4 - inputs:(row4) outputs:()
				// linked node: tMap_1 - inputs:(row1,row2,row3,row4,row5,row6,row7,row8,row9)
				// outputs:()

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row4 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.ALL_ROWS;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct> tHash_Lookup_row4 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row4Struct>getLookup(matchingModeEnum_row4);

				globalMap.put("tHash_Lookup_row4", tHash_Lookup_row4);

				/**
				 * [tAdvancedHash_row4 begin ] stop
				 */

				/**
				 * [tDBInput_3 begin ] start
				 */

				ok_Hash.put("tDBInput_3", false);
				start_Hash.put("tDBInput_3", System.currentTimeMillis());

				currentComponent = "tDBInput_3";

				int tos_count_tDBInput_3 = 0;

				org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_3 = org.talend.designer.components.util.mssql.MSSqlUtilFactory
						.getMSSqlGenerateTimestampUtil();

				java.util.List<String> talendToDBList_tDBInput_3 = new java.util.ArrayList();
				String[] talendToDBArray_tDBInput_3 = new String[] { "FLOAT", "NUMERIC", "NUMERIC IDENTITY", "DECIMAL",
						"DECIMAL IDENTITY", "REAL" };
				java.util.Collections.addAll(talendToDBList_tDBInput_3, talendToDBArray_tDBInput_3);
				int nb_line_tDBInput_3 = 0;
				java.sql.Connection conn_tDBInput_3 = null;
				String driverClass_tDBInput_3 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
				java.lang.Class jdbcclazz_tDBInput_3 = java.lang.Class.forName(driverClass_tDBInput_3);
				String dbUser_tDBInput_3 = "talend_user";

				final String decryptedPassword_tDBInput_3 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:MkLtJJYnHdPe/4k9bZz3qBCukn8vxhshUVV5+zztdSYmiIArhns=");

				String dbPwd_tDBInput_3 = decryptedPassword_tDBInput_3;

				String port_tDBInput_3 = "1433";
				String dbname_tDBInput_3 = "AUTO_DWH";
				String url_tDBInput_3 = "jdbc:sqlserver://" + "DESKTOP-6EEKMMP";
				if (!"".equals(port_tDBInput_3)) {
					url_tDBInput_3 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBInput_3)) {
					url_tDBInput_3 += ";databaseName=" + "AUTO_DWH";
				}
				url_tDBInput_3 += ";appName=" + projectName + ";" + "trustServerCertificate=true";
				String dbschema_tDBInput_3 = "dbo";

				conn_tDBInput_3 = java.sql.DriverManager.getConnection(url_tDBInput_3, dbUser_tDBInput_3,
						dbPwd_tDBInput_3);

				java.sql.Statement stmt_tDBInput_3 = conn_tDBInput_3.createStatement();

				String dbquery_tDBInput_3 = "SELECT [idPack]\n      ,[TYPE_PACK]\n      ,[CODE_PRODUIT]\n  FROM [AUTO_DWH].[dbo].[DimPack]\n\n";

				globalMap.put("tDBInput_3_QUERY", dbquery_tDBInput_3);
				java.sql.ResultSet rs_tDBInput_3 = null;

				try {
					rs_tDBInput_3 = stmt_tDBInput_3.executeQuery(dbquery_tDBInput_3);
					java.sql.ResultSetMetaData rsmd_tDBInput_3 = rs_tDBInput_3.getMetaData();
					int colQtyInRs_tDBInput_3 = rsmd_tDBInput_3.getColumnCount();

					String tmpContent_tDBInput_3 = null;

					while (rs_tDBInput_3.next()) {
						nb_line_tDBInput_3++;

						if (colQtyInRs_tDBInput_3 < 1) {
							row4.idPack = 0;
						} else {

							row4.idPack = rs_tDBInput_3.getInt(1);
							if (rs_tDBInput_3.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_3 < 2) {
							row4.TYPE_PACK = null;
						} else {

							tmpContent_tDBInput_3 = rs_tDBInput_3.getString(2);
							if (tmpContent_tDBInput_3 != null) {
								if (talendToDBList_tDBInput_3.contains(
										rsmd_tDBInput_3.getColumnTypeName(2).toUpperCase(java.util.Locale.ENGLISH))) {
									row4.TYPE_PACK = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
								} else {
									row4.TYPE_PACK = tmpContent_tDBInput_3;
								}
							} else {
								row4.TYPE_PACK = null;
							}
						}
						if (colQtyInRs_tDBInput_3 < 3) {
							row4.CODE_PRODUIT = null;
						} else {

							row4.CODE_PRODUIT = rs_tDBInput_3.getInt(3);
							if (rs_tDBInput_3.wasNull()) {
								row4.CODE_PRODUIT = null;
							}
						}

						/**
						 * [tDBInput_3 begin ] stop
						 */

						/**
						 * [tDBInput_3 main ] start
						 */

						currentComponent = "tDBInput_3";

						tos_count_tDBInput_3++;

						/**
						 * [tDBInput_3 main ] stop
						 */

						/**
						 * [tDBInput_3 process_data_begin ] start
						 */

						currentComponent = "tDBInput_3";

						/**
						 * [tDBInput_3 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_row4 main ] start
						 */

						currentComponent = "tAdvancedHash_row4";

						if (execStat) {
							runStat.updateStatOnConnection(iterateId, 1, 1

									, "row4"

							);
						}

						row4Struct row4_HashRow = new row4Struct();

						row4_HashRow.idPack = row4.idPack;

						row4_HashRow.TYPE_PACK = row4.TYPE_PACK;

						row4_HashRow.CODE_PRODUIT = row4.CODE_PRODUIT;

						tHash_Lookup_row4.put(row4_HashRow);

						tos_count_tAdvancedHash_row4++;

						/**
						 * [tAdvancedHash_row4 main ] stop
						 */

						/**
						 * [tAdvancedHash_row4 process_data_begin ] start
						 */

						currentComponent = "tAdvancedHash_row4";

						/**
						 * [tAdvancedHash_row4 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_row4 process_data_end ] start
						 */

						currentComponent = "tAdvancedHash_row4";

						/**
						 * [tAdvancedHash_row4 process_data_end ] stop
						 */

						/**
						 * [tDBInput_3 process_data_end ] start
						 */

						currentComponent = "tDBInput_3";

						/**
						 * [tDBInput_3 process_data_end ] stop
						 */

						/**
						 * [tDBInput_3 end ] start
						 */

						currentComponent = "tDBInput_3";

					}
				} finally {
					if (rs_tDBInput_3 != null) {
						rs_tDBInput_3.close();
					}
					if (stmt_tDBInput_3 != null) {
						stmt_tDBInput_3.close();
					}
					if (conn_tDBInput_3 != null && !conn_tDBInput_3.isClosed()) {

						conn_tDBInput_3.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

					}
				}
				globalMap.put("tDBInput_3_NB_LINE", nb_line_tDBInput_3);

				ok_Hash.put("tDBInput_3", true);
				end_Hash.put("tDBInput_3", System.currentTimeMillis());

				/**
				 * [tDBInput_3 end ] stop
				 */

				/**
				 * [tAdvancedHash_row4 end ] start
				 */

				currentComponent = "tAdvancedHash_row4";

				tHash_Lookup_row4.endPut();

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row4");
				}

				ok_Hash.put("tAdvancedHash_row4", true);
				end_Hash.put("tAdvancedHash_row4", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row4 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_3 finally ] start
				 */

				currentComponent = "tDBInput_3";

				/**
				 * [tDBInput_3 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row4 finally ] start
				 */

				currentComponent = "tAdvancedHash_row4";

				/**
				 * [tAdvancedHash_row4 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_3_SUBPROCESS_STATE", 1);
	}

	public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
		final static byte[] commonByteArrayLock_STAR_ASSURANCE_factPrime = new byte[0];
		static byte[] commonByteArray_STAR_ASSURANCE_factPrime = new byte[0];

		public int id_point_vente;

		public int getId_point_vente() {
			return this.id_point_vente;
		}

		public Integer Code_point_vente;

		public Integer getCode_point_vente() {
			return this.Code_point_vente;
		}

		public String Type_point_vente;

		public String getType_point_vente() {
			return this.Type_point_vente;
		}

		public String Libelle;

		public String getLibelle() {
			return this.Libelle;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_factPrime.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_factPrime.length == 0) {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_STAR_ASSURANCE_factPrime, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_factPrime, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_factPrime.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_factPrime.length == 0) {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_STAR_ASSURANCE_factPrime, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_factPrime, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.id_point_vente = dis.readInt();

					this.Code_point_vente = readInteger(dis);

					this.Type_point_vente = readString(dis);

					this.Libelle = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.id_point_vente = dis.readInt();

					this.Code_point_vente = readInteger(dis);

					this.Type_point_vente = readString(dis);

					this.Libelle = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.id_point_vente);

				// Integer

				writeInteger(this.Code_point_vente, dos);

				// String

				writeString(this.Type_point_vente, dos);

				// String

				writeString(this.Libelle, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.id_point_vente);

				// Integer

				writeInteger(this.Code_point_vente, dos);

				// String

				writeString(this.Type_point_vente, dos);

				// String

				writeString(this.Libelle, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id_point_vente=" + String.valueOf(id_point_vente));
			sb.append(",Code_point_vente=" + String.valueOf(Code_point_vente));
			sb.append(",Type_point_vente=" + Type_point_vente);
			sb.append(",Libelle=" + Libelle);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row5Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_4_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row5Struct row5 = new row5Struct();

				/**
				 * [tAdvancedHash_row5 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row5", false);
				start_Hash.put("tAdvancedHash_row5", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row5";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row5");
				}

				int tos_count_tAdvancedHash_row5 = 0;

				// connection name:row5
				// source node:tDBInput_4 - inputs:(after_tFileInputExcel_1) outputs:(row5,row5)
				// | target node:tAdvancedHash_row5 - inputs:(row5) outputs:()
				// linked node: tMap_1 - inputs:(row1,row2,row3,row4,row5,row6,row7,row8,row9)
				// outputs:()

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row5 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.ALL_ROWS;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row5Struct> tHash_Lookup_row5 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row5Struct>getLookup(matchingModeEnum_row5);

				globalMap.put("tHash_Lookup_row5", tHash_Lookup_row5);

				/**
				 * [tAdvancedHash_row5 begin ] stop
				 */

				/**
				 * [tDBInput_4 begin ] start
				 */

				ok_Hash.put("tDBInput_4", false);
				start_Hash.put("tDBInput_4", System.currentTimeMillis());

				currentComponent = "tDBInput_4";

				int tos_count_tDBInput_4 = 0;

				org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_4 = org.talend.designer.components.util.mssql.MSSqlUtilFactory
						.getMSSqlGenerateTimestampUtil();

				java.util.List<String> talendToDBList_tDBInput_4 = new java.util.ArrayList();
				String[] talendToDBArray_tDBInput_4 = new String[] { "FLOAT", "NUMERIC", "NUMERIC IDENTITY", "DECIMAL",
						"DECIMAL IDENTITY", "REAL" };
				java.util.Collections.addAll(talendToDBList_tDBInput_4, talendToDBArray_tDBInput_4);
				int nb_line_tDBInput_4 = 0;
				java.sql.Connection conn_tDBInput_4 = null;
				String driverClass_tDBInput_4 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
				java.lang.Class jdbcclazz_tDBInput_4 = java.lang.Class.forName(driverClass_tDBInput_4);
				String dbUser_tDBInput_4 = "talend_user";

				final String decryptedPassword_tDBInput_4 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:WrfD8BSuMv3qkgSsXEBtu9qAANtCJO4f8feu0/wbEjWk6jZC4sA=");

				String dbPwd_tDBInput_4 = decryptedPassword_tDBInput_4;

				String port_tDBInput_4 = "1433";
				String dbname_tDBInput_4 = "AUTO_DWH";
				String url_tDBInput_4 = "jdbc:sqlserver://" + "DESKTOP-6EEKMMP";
				if (!"".equals(port_tDBInput_4)) {
					url_tDBInput_4 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBInput_4)) {
					url_tDBInput_4 += ";databaseName=" + "AUTO_DWH";
				}
				url_tDBInput_4 += ";appName=" + projectName + ";" + "trustServerCertificate=true";
				String dbschema_tDBInput_4 = "dbo";

				conn_tDBInput_4 = java.sql.DriverManager.getConnection(url_tDBInput_4, dbUser_tDBInput_4,
						dbPwd_tDBInput_4);

				java.sql.Statement stmt_tDBInput_4 = conn_tDBInput_4.createStatement();

				String dbquery_tDBInput_4 = "SELECT [id_point_vente]\n      ,[Code_point_vente]\n      ,[Type_point_vente]\n      ,[Libelle]\n  FROM [AUTO_DWH].[dbo"
						+ "].[DimPointVente]\n\n";

				globalMap.put("tDBInput_4_QUERY", dbquery_tDBInput_4);
				java.sql.ResultSet rs_tDBInput_4 = null;

				try {
					rs_tDBInput_4 = stmt_tDBInput_4.executeQuery(dbquery_tDBInput_4);
					java.sql.ResultSetMetaData rsmd_tDBInput_4 = rs_tDBInput_4.getMetaData();
					int colQtyInRs_tDBInput_4 = rsmd_tDBInput_4.getColumnCount();

					String tmpContent_tDBInput_4 = null;

					while (rs_tDBInput_4.next()) {
						nb_line_tDBInput_4++;

						if (colQtyInRs_tDBInput_4 < 1) {
							row5.id_point_vente = 0;
						} else {

							row5.id_point_vente = rs_tDBInput_4.getInt(1);
							if (rs_tDBInput_4.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_4 < 2) {
							row5.Code_point_vente = null;
						} else {

							row5.Code_point_vente = rs_tDBInput_4.getInt(2);
							if (rs_tDBInput_4.wasNull()) {
								row5.Code_point_vente = null;
							}
						}
						if (colQtyInRs_tDBInput_4 < 3) {
							row5.Type_point_vente = null;
						} else {

							tmpContent_tDBInput_4 = rs_tDBInput_4.getString(3);
							if (tmpContent_tDBInput_4 != null) {
								if (talendToDBList_tDBInput_4.contains(
										rsmd_tDBInput_4.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
									row5.Type_point_vente = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
								} else {
									row5.Type_point_vente = tmpContent_tDBInput_4;
								}
							} else {
								row5.Type_point_vente = null;
							}
						}
						if (colQtyInRs_tDBInput_4 < 4) {
							row5.Libelle = null;
						} else {

							tmpContent_tDBInput_4 = rs_tDBInput_4.getString(4);
							if (tmpContent_tDBInput_4 != null) {
								if (talendToDBList_tDBInput_4.contains(
										rsmd_tDBInput_4.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
									row5.Libelle = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
								} else {
									row5.Libelle = tmpContent_tDBInput_4;
								}
							} else {
								row5.Libelle = null;
							}
						}

						/**
						 * [tDBInput_4 begin ] stop
						 */

						/**
						 * [tDBInput_4 main ] start
						 */

						currentComponent = "tDBInput_4";

						tos_count_tDBInput_4++;

						/**
						 * [tDBInput_4 main ] stop
						 */

						/**
						 * [tDBInput_4 process_data_begin ] start
						 */

						currentComponent = "tDBInput_4";

						/**
						 * [tDBInput_4 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_row5 main ] start
						 */

						currentComponent = "tAdvancedHash_row5";

						if (execStat) {
							runStat.updateStatOnConnection(iterateId, 1, 1

									, "row5"

							);
						}

						row5Struct row5_HashRow = new row5Struct();

						row5_HashRow.id_point_vente = row5.id_point_vente;

						row5_HashRow.Code_point_vente = row5.Code_point_vente;

						row5_HashRow.Type_point_vente = row5.Type_point_vente;

						row5_HashRow.Libelle = row5.Libelle;

						tHash_Lookup_row5.put(row5_HashRow);

						tos_count_tAdvancedHash_row5++;

						/**
						 * [tAdvancedHash_row5 main ] stop
						 */

						/**
						 * [tAdvancedHash_row5 process_data_begin ] start
						 */

						currentComponent = "tAdvancedHash_row5";

						/**
						 * [tAdvancedHash_row5 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_row5 process_data_end ] start
						 */

						currentComponent = "tAdvancedHash_row5";

						/**
						 * [tAdvancedHash_row5 process_data_end ] stop
						 */

						/**
						 * [tDBInput_4 process_data_end ] start
						 */

						currentComponent = "tDBInput_4";

						/**
						 * [tDBInput_4 process_data_end ] stop
						 */

						/**
						 * [tDBInput_4 end ] start
						 */

						currentComponent = "tDBInput_4";

					}
				} finally {
					if (rs_tDBInput_4 != null) {
						rs_tDBInput_4.close();
					}
					if (stmt_tDBInput_4 != null) {
						stmt_tDBInput_4.close();
					}
					if (conn_tDBInput_4 != null && !conn_tDBInput_4.isClosed()) {

						conn_tDBInput_4.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

					}
				}
				globalMap.put("tDBInput_4_NB_LINE", nb_line_tDBInput_4);

				ok_Hash.put("tDBInput_4", true);
				end_Hash.put("tDBInput_4", System.currentTimeMillis());

				/**
				 * [tDBInput_4 end ] stop
				 */

				/**
				 * [tAdvancedHash_row5 end ] start
				 */

				currentComponent = "tAdvancedHash_row5";

				tHash_Lookup_row5.endPut();

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row5");
				}

				ok_Hash.put("tAdvancedHash_row5", true);
				end_Hash.put("tAdvancedHash_row5", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row5 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_4 finally ] start
				 */

				currentComponent = "tDBInput_4";

				/**
				 * [tDBInput_4 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row5 finally ] start
				 */

				currentComponent = "tAdvancedHash_row5";

				/**
				 * [tAdvancedHash_row5 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_4_SUBPROCESS_STATE", 1);
	}

	public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
		final static byte[] commonByteArrayLock_STAR_ASSURANCE_factPrime = new byte[0];
		static byte[] commonByteArray_STAR_ASSURANCE_factPrime = new byte[0];

		public int idProduit;

		public int getIdProduit() {
			return this.idProduit;
		}

		public Integer CODE_PRODUIT_AUTOMOBILE;

		public Integer getCODE_PRODUIT_AUTOMOBILE() {
			return this.CODE_PRODUIT_AUTOMOBILE;
		}

		public String SOUS_BRANCHE_produit;

		public String getSOUS_BRANCHE_produit() {
			return this.SOUS_BRANCHE_produit;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_factPrime.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_factPrime.length == 0) {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_STAR_ASSURANCE_factPrime, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_factPrime, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_factPrime.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_factPrime.length == 0) {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_STAR_ASSURANCE_factPrime, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_factPrime, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.idProduit = dis.readInt();

					this.CODE_PRODUIT_AUTOMOBILE = readInteger(dis);

					this.SOUS_BRANCHE_produit = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.idProduit = dis.readInt();

					this.CODE_PRODUIT_AUTOMOBILE = readInteger(dis);

					this.SOUS_BRANCHE_produit = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.idProduit);

				// Integer

				writeInteger(this.CODE_PRODUIT_AUTOMOBILE, dos);

				// String

				writeString(this.SOUS_BRANCHE_produit, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.idProduit);

				// Integer

				writeInteger(this.CODE_PRODUIT_AUTOMOBILE, dos);

				// String

				writeString(this.SOUS_BRANCHE_produit, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("idProduit=" + String.valueOf(idProduit));
			sb.append(",CODE_PRODUIT_AUTOMOBILE=" + String.valueOf(CODE_PRODUIT_AUTOMOBILE));
			sb.append(",SOUS_BRANCHE_produit=" + SOUS_BRANCHE_produit);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row6Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_5_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row6Struct row6 = new row6Struct();

				/**
				 * [tAdvancedHash_row6 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row6", false);
				start_Hash.put("tAdvancedHash_row6", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row6";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row6");
				}

				int tos_count_tAdvancedHash_row6 = 0;

				// connection name:row6
				// source node:tDBInput_5 - inputs:(after_tFileInputExcel_1) outputs:(row6,row6)
				// | target node:tAdvancedHash_row6 - inputs:(row6) outputs:()
				// linked node: tMap_1 - inputs:(row1,row2,row3,row4,row5,row6,row7,row8,row9)
				// outputs:()

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row6 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.ALL_ROWS;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row6Struct> tHash_Lookup_row6 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row6Struct>getLookup(matchingModeEnum_row6);

				globalMap.put("tHash_Lookup_row6", tHash_Lookup_row6);

				/**
				 * [tAdvancedHash_row6 begin ] stop
				 */

				/**
				 * [tDBInput_5 begin ] start
				 */

				ok_Hash.put("tDBInput_5", false);
				start_Hash.put("tDBInput_5", System.currentTimeMillis());

				currentComponent = "tDBInput_5";

				int tos_count_tDBInput_5 = 0;

				org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_5 = org.talend.designer.components.util.mssql.MSSqlUtilFactory
						.getMSSqlGenerateTimestampUtil();

				java.util.List<String> talendToDBList_tDBInput_5 = new java.util.ArrayList();
				String[] talendToDBArray_tDBInput_5 = new String[] { "FLOAT", "NUMERIC", "NUMERIC IDENTITY", "DECIMAL",
						"DECIMAL IDENTITY", "REAL" };
				java.util.Collections.addAll(talendToDBList_tDBInput_5, talendToDBArray_tDBInput_5);
				int nb_line_tDBInput_5 = 0;
				java.sql.Connection conn_tDBInput_5 = null;
				String driverClass_tDBInput_5 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
				java.lang.Class jdbcclazz_tDBInput_5 = java.lang.Class.forName(driverClass_tDBInput_5);
				String dbUser_tDBInput_5 = "talend_user";

				final String decryptedPassword_tDBInput_5 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:BUNzOwHZRYVh4THeAWNojJ00pRVl5j589VZLFz81fIINoNpWpKE=");

				String dbPwd_tDBInput_5 = decryptedPassword_tDBInput_5;

				String port_tDBInput_5 = "1433";
				String dbname_tDBInput_5 = "AUTO_DWH";
				String url_tDBInput_5 = "jdbc:sqlserver://" + "DESKTOP-6EEKMMP";
				if (!"".equals(port_tDBInput_5)) {
					url_tDBInput_5 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBInput_5)) {
					url_tDBInput_5 += ";databaseName=" + "AUTO_DWH";
				}
				url_tDBInput_5 += ";appName=" + projectName + ";" + "trustServerCertificate=true";
				String dbschema_tDBInput_5 = "dbo";

				conn_tDBInput_5 = java.sql.DriverManager.getConnection(url_tDBInput_5, dbUser_tDBInput_5,
						dbPwd_tDBInput_5);

				java.sql.Statement stmt_tDBInput_5 = conn_tDBInput_5.createStatement();

				String dbquery_tDBInput_5 = "SELECT [idProduit]\n      ,[CODE_PRODUIT_AUTOMOBILE]\n      ,[SOUS_BRANCHE_produit]\n  FROM [AUTO_DWH].[dbo].[DimProdui"
						+ "t]\n";

				globalMap.put("tDBInput_5_QUERY", dbquery_tDBInput_5);
				java.sql.ResultSet rs_tDBInput_5 = null;

				try {
					rs_tDBInput_5 = stmt_tDBInput_5.executeQuery(dbquery_tDBInput_5);
					java.sql.ResultSetMetaData rsmd_tDBInput_5 = rs_tDBInput_5.getMetaData();
					int colQtyInRs_tDBInput_5 = rsmd_tDBInput_5.getColumnCount();

					String tmpContent_tDBInput_5 = null;

					while (rs_tDBInput_5.next()) {
						nb_line_tDBInput_5++;

						if (colQtyInRs_tDBInput_5 < 1) {
							row6.idProduit = 0;
						} else {

							row6.idProduit = rs_tDBInput_5.getInt(1);
							if (rs_tDBInput_5.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_5 < 2) {
							row6.CODE_PRODUIT_AUTOMOBILE = null;
						} else {

							row6.CODE_PRODUIT_AUTOMOBILE = rs_tDBInput_5.getInt(2);
							if (rs_tDBInput_5.wasNull()) {
								row6.CODE_PRODUIT_AUTOMOBILE = null;
							}
						}
						if (colQtyInRs_tDBInput_5 < 3) {
							row6.SOUS_BRANCHE_produit = null;
						} else {

							tmpContent_tDBInput_5 = rs_tDBInput_5.getString(3);
							if (tmpContent_tDBInput_5 != null) {
								if (talendToDBList_tDBInput_5.contains(
										rsmd_tDBInput_5.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
									row6.SOUS_BRANCHE_produit = FormatterUtils.formatUnwithE(tmpContent_tDBInput_5);
								} else {
									row6.SOUS_BRANCHE_produit = tmpContent_tDBInput_5;
								}
							} else {
								row6.SOUS_BRANCHE_produit = null;
							}
						}

						/**
						 * [tDBInput_5 begin ] stop
						 */

						/**
						 * [tDBInput_5 main ] start
						 */

						currentComponent = "tDBInput_5";

						tos_count_tDBInput_5++;

						/**
						 * [tDBInput_5 main ] stop
						 */

						/**
						 * [tDBInput_5 process_data_begin ] start
						 */

						currentComponent = "tDBInput_5";

						/**
						 * [tDBInput_5 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_row6 main ] start
						 */

						currentComponent = "tAdvancedHash_row6";

						if (execStat) {
							runStat.updateStatOnConnection(iterateId, 1, 1

									, "row6"

							);
						}

						row6Struct row6_HashRow = new row6Struct();

						row6_HashRow.idProduit = row6.idProduit;

						row6_HashRow.CODE_PRODUIT_AUTOMOBILE = row6.CODE_PRODUIT_AUTOMOBILE;

						row6_HashRow.SOUS_BRANCHE_produit = row6.SOUS_BRANCHE_produit;

						tHash_Lookup_row6.put(row6_HashRow);

						tos_count_tAdvancedHash_row6++;

						/**
						 * [tAdvancedHash_row6 main ] stop
						 */

						/**
						 * [tAdvancedHash_row6 process_data_begin ] start
						 */

						currentComponent = "tAdvancedHash_row6";

						/**
						 * [tAdvancedHash_row6 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_row6 process_data_end ] start
						 */

						currentComponent = "tAdvancedHash_row6";

						/**
						 * [tAdvancedHash_row6 process_data_end ] stop
						 */

						/**
						 * [tDBInput_5 process_data_end ] start
						 */

						currentComponent = "tDBInput_5";

						/**
						 * [tDBInput_5 process_data_end ] stop
						 */

						/**
						 * [tDBInput_5 end ] start
						 */

						currentComponent = "tDBInput_5";

					}
				} finally {
					if (rs_tDBInput_5 != null) {
						rs_tDBInput_5.close();
					}
					if (stmt_tDBInput_5 != null) {
						stmt_tDBInput_5.close();
					}
					if (conn_tDBInput_5 != null && !conn_tDBInput_5.isClosed()) {

						conn_tDBInput_5.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

					}
				}
				globalMap.put("tDBInput_5_NB_LINE", nb_line_tDBInput_5);

				ok_Hash.put("tDBInput_5", true);
				end_Hash.put("tDBInput_5", System.currentTimeMillis());

				/**
				 * [tDBInput_5 end ] stop
				 */

				/**
				 * [tAdvancedHash_row6 end ] start
				 */

				currentComponent = "tAdvancedHash_row6";

				tHash_Lookup_row6.endPut();

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row6");
				}

				ok_Hash.put("tAdvancedHash_row6", true);
				end_Hash.put("tAdvancedHash_row6", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row6 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_5 finally ] start
				 */

				currentComponent = "tDBInput_5";

				/**
				 * [tDBInput_5 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row6 finally ] start
				 */

				currentComponent = "tAdvancedHash_row6";

				/**
				 * [tAdvancedHash_row6 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_5_SUBPROCESS_STATE", 1);
	}

	public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
		final static byte[] commonByteArrayLock_STAR_ASSURANCE_factPrime = new byte[0];
		static byte[] commonByteArray_STAR_ASSURANCE_factPrime = new byte[0];

		public int idQuittance;

		public int getIdQuittance() {
			return this.idQuittance;
		}

		public String TYPE_QUITTANCE;

		public String getTYPE_QUITTANCE() {
			return this.TYPE_QUITTANCE;
		}

		public String SOUS_TYPE_QUITTANCE;

		public String getSOUS_TYPE_QUITTANCE() {
			return this.SOUS_TYPE_QUITTANCE;
		}

		public String Description;

		public String getDescription() {
			return this.Description;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_factPrime.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_factPrime.length == 0) {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_STAR_ASSURANCE_factPrime, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_factPrime, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_factPrime.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_factPrime.length == 0) {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_STAR_ASSURANCE_factPrime, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_factPrime, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.idQuittance = dis.readInt();

					this.TYPE_QUITTANCE = readString(dis);

					this.SOUS_TYPE_QUITTANCE = readString(dis);

					this.Description = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.idQuittance = dis.readInt();

					this.TYPE_QUITTANCE = readString(dis);

					this.SOUS_TYPE_QUITTANCE = readString(dis);

					this.Description = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.idQuittance);

				// String

				writeString(this.TYPE_QUITTANCE, dos);

				// String

				writeString(this.SOUS_TYPE_QUITTANCE, dos);

				// String

				writeString(this.Description, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.idQuittance);

				// String

				writeString(this.TYPE_QUITTANCE, dos);

				// String

				writeString(this.SOUS_TYPE_QUITTANCE, dos);

				// String

				writeString(this.Description, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("idQuittance=" + String.valueOf(idQuittance));
			sb.append(",TYPE_QUITTANCE=" + TYPE_QUITTANCE);
			sb.append(",SOUS_TYPE_QUITTANCE=" + SOUS_TYPE_QUITTANCE);
			sb.append(",Description=" + Description);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row7Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_6_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row7Struct row7 = new row7Struct();

				/**
				 * [tAdvancedHash_row7 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row7", false);
				start_Hash.put("tAdvancedHash_row7", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row7";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row7");
				}

				int tos_count_tAdvancedHash_row7 = 0;

				// connection name:row7
				// source node:tDBInput_6 - inputs:(after_tFileInputExcel_1) outputs:(row7,row7)
				// | target node:tAdvancedHash_row7 - inputs:(row7) outputs:()
				// linked node: tMap_1 - inputs:(row1,row2,row3,row4,row5,row6,row7,row8,row9)
				// outputs:()

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row7 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.ALL_ROWS;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row7Struct> tHash_Lookup_row7 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row7Struct>getLookup(matchingModeEnum_row7);

				globalMap.put("tHash_Lookup_row7", tHash_Lookup_row7);

				/**
				 * [tAdvancedHash_row7 begin ] stop
				 */

				/**
				 * [tDBInput_6 begin ] start
				 */

				ok_Hash.put("tDBInput_6", false);
				start_Hash.put("tDBInput_6", System.currentTimeMillis());

				currentComponent = "tDBInput_6";

				int tos_count_tDBInput_6 = 0;

				org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_6 = org.talend.designer.components.util.mssql.MSSqlUtilFactory
						.getMSSqlGenerateTimestampUtil();

				java.util.List<String> talendToDBList_tDBInput_6 = new java.util.ArrayList();
				String[] talendToDBArray_tDBInput_6 = new String[] { "FLOAT", "NUMERIC", "NUMERIC IDENTITY", "DECIMAL",
						"DECIMAL IDENTITY", "REAL" };
				java.util.Collections.addAll(talendToDBList_tDBInput_6, talendToDBArray_tDBInput_6);
				int nb_line_tDBInput_6 = 0;
				java.sql.Connection conn_tDBInput_6 = null;
				String driverClass_tDBInput_6 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
				java.lang.Class jdbcclazz_tDBInput_6 = java.lang.Class.forName(driverClass_tDBInput_6);
				String dbUser_tDBInput_6 = "talend_user";

				final String decryptedPassword_tDBInput_6 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:tYDx6f67ROPxOHaN/SWQnIGrpBQk6cSXhHXKFgyB/u2NdOuX8MY=");

				String dbPwd_tDBInput_6 = decryptedPassword_tDBInput_6;

				String port_tDBInput_6 = "1433";
				String dbname_tDBInput_6 = "AUTO_DWH";
				String url_tDBInput_6 = "jdbc:sqlserver://" + "DESKTOP-6EEKMMP";
				if (!"".equals(port_tDBInput_6)) {
					url_tDBInput_6 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBInput_6)) {
					url_tDBInput_6 += ";databaseName=" + "AUTO_DWH";
				}
				url_tDBInput_6 += ";appName=" + projectName + ";" + "trustServerCertificate=true";
				String dbschema_tDBInput_6 = "dbo";

				conn_tDBInput_6 = java.sql.DriverManager.getConnection(url_tDBInput_6, dbUser_tDBInput_6,
						dbPwd_tDBInput_6);

				java.sql.Statement stmt_tDBInput_6 = conn_tDBInput_6.createStatement();

				String dbquery_tDBInput_6 = "SELECT [idQuittance]\n      ,[TYPE_QUITTANCE]\n      ,[SOUS_TYPE_QUITTANCE]\n      ,[Description]\n  FROM [AUTO_DWH].[d"
						+ "bo].[DimQuittance]\n";

				globalMap.put("tDBInput_6_QUERY", dbquery_tDBInput_6);
				java.sql.ResultSet rs_tDBInput_6 = null;

				try {
					rs_tDBInput_6 = stmt_tDBInput_6.executeQuery(dbquery_tDBInput_6);
					java.sql.ResultSetMetaData rsmd_tDBInput_6 = rs_tDBInput_6.getMetaData();
					int colQtyInRs_tDBInput_6 = rsmd_tDBInput_6.getColumnCount();

					String tmpContent_tDBInput_6 = null;

					while (rs_tDBInput_6.next()) {
						nb_line_tDBInput_6++;

						if (colQtyInRs_tDBInput_6 < 1) {
							row7.idQuittance = 0;
						} else {

							row7.idQuittance = rs_tDBInput_6.getInt(1);
							if (rs_tDBInput_6.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_6 < 2) {
							row7.TYPE_QUITTANCE = null;
						} else {

							tmpContent_tDBInput_6 = rs_tDBInput_6.getString(2);
							if (tmpContent_tDBInput_6 != null) {
								if (talendToDBList_tDBInput_6.contains(
										rsmd_tDBInput_6.getColumnTypeName(2).toUpperCase(java.util.Locale.ENGLISH))) {
									row7.TYPE_QUITTANCE = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
								} else {
									row7.TYPE_QUITTANCE = tmpContent_tDBInput_6;
								}
							} else {
								row7.TYPE_QUITTANCE = null;
							}
						}
						if (colQtyInRs_tDBInput_6 < 3) {
							row7.SOUS_TYPE_QUITTANCE = null;
						} else {

							tmpContent_tDBInput_6 = rs_tDBInput_6.getString(3);
							if (tmpContent_tDBInput_6 != null) {
								if (talendToDBList_tDBInput_6.contains(
										rsmd_tDBInput_6.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
									row7.SOUS_TYPE_QUITTANCE = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
								} else {
									row7.SOUS_TYPE_QUITTANCE = tmpContent_tDBInput_6;
								}
							} else {
								row7.SOUS_TYPE_QUITTANCE = null;
							}
						}
						if (colQtyInRs_tDBInput_6 < 4) {
							row7.Description = null;
						} else {

							tmpContent_tDBInput_6 = rs_tDBInput_6.getString(4);
							if (tmpContent_tDBInput_6 != null) {
								if (talendToDBList_tDBInput_6.contains(
										rsmd_tDBInput_6.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
									row7.Description = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
								} else {
									row7.Description = tmpContent_tDBInput_6;
								}
							} else {
								row7.Description = null;
							}
						}

						/**
						 * [tDBInput_6 begin ] stop
						 */

						/**
						 * [tDBInput_6 main ] start
						 */

						currentComponent = "tDBInput_6";

						tos_count_tDBInput_6++;

						/**
						 * [tDBInput_6 main ] stop
						 */

						/**
						 * [tDBInput_6 process_data_begin ] start
						 */

						currentComponent = "tDBInput_6";

						/**
						 * [tDBInput_6 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_row7 main ] start
						 */

						currentComponent = "tAdvancedHash_row7";

						if (execStat) {
							runStat.updateStatOnConnection(iterateId, 1, 1

									, "row7"

							);
						}

						row7Struct row7_HashRow = new row7Struct();

						row7_HashRow.idQuittance = row7.idQuittance;

						row7_HashRow.TYPE_QUITTANCE = row7.TYPE_QUITTANCE;

						row7_HashRow.SOUS_TYPE_QUITTANCE = row7.SOUS_TYPE_QUITTANCE;

						row7_HashRow.Description = row7.Description;

						tHash_Lookup_row7.put(row7_HashRow);

						tos_count_tAdvancedHash_row7++;

						/**
						 * [tAdvancedHash_row7 main ] stop
						 */

						/**
						 * [tAdvancedHash_row7 process_data_begin ] start
						 */

						currentComponent = "tAdvancedHash_row7";

						/**
						 * [tAdvancedHash_row7 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_row7 process_data_end ] start
						 */

						currentComponent = "tAdvancedHash_row7";

						/**
						 * [tAdvancedHash_row7 process_data_end ] stop
						 */

						/**
						 * [tDBInput_6 process_data_end ] start
						 */

						currentComponent = "tDBInput_6";

						/**
						 * [tDBInput_6 process_data_end ] stop
						 */

						/**
						 * [tDBInput_6 end ] start
						 */

						currentComponent = "tDBInput_6";

					}
				} finally {
					if (rs_tDBInput_6 != null) {
						rs_tDBInput_6.close();
					}
					if (stmt_tDBInput_6 != null) {
						stmt_tDBInput_6.close();
					}
					if (conn_tDBInput_6 != null && !conn_tDBInput_6.isClosed()) {

						conn_tDBInput_6.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

					}
				}
				globalMap.put("tDBInput_6_NB_LINE", nb_line_tDBInput_6);

				ok_Hash.put("tDBInput_6", true);
				end_Hash.put("tDBInput_6", System.currentTimeMillis());

				/**
				 * [tDBInput_6 end ] stop
				 */

				/**
				 * [tAdvancedHash_row7 end ] start
				 */

				currentComponent = "tAdvancedHash_row7";

				tHash_Lookup_row7.endPut();

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row7");
				}

				ok_Hash.put("tAdvancedHash_row7", true);
				end_Hash.put("tAdvancedHash_row7", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row7 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_6 finally ] start
				 */

				currentComponent = "tDBInput_6";

				/**
				 * [tDBInput_6 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row7 finally ] start
				 */

				currentComponent = "tAdvancedHash_row7";

				/**
				 * [tAdvancedHash_row7 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_6_SUBPROCESS_STATE", 1);
	}

	public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
		final static byte[] commonByteArrayLock_STAR_ASSURANCE_factPrime = new byte[0];
		static byte[] commonByteArray_STAR_ASSURANCE_factPrime = new byte[0];

		public int CODE_USAGE;

		public int getCODE_USAGE() {
			return this.CODE_USAGE;
		}

		public String NOM_USAGE;

		public String getNOM_USAGE() {
			return this.NOM_USAGE;
		}

		public int id_usage;

		public int getId_usage() {
			return this.id_usage;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_factPrime.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_factPrime.length == 0) {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_STAR_ASSURANCE_factPrime, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_factPrime, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_STAR_ASSURANCE_factPrime.length) {
					if (length < 1024 && commonByteArray_STAR_ASSURANCE_factPrime.length == 0) {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[1024];
					} else {
						commonByteArray_STAR_ASSURANCE_factPrime = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_STAR_ASSURANCE_factPrime, 0, length);
				strReturn = new String(commonByteArray_STAR_ASSURANCE_factPrime, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.CODE_USAGE = dis.readInt();

					this.NOM_USAGE = readString(dis);

					this.id_usage = dis.readInt();

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.CODE_USAGE = dis.readInt();

					this.NOM_USAGE = readString(dis);

					this.id_usage = dis.readInt();

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.CODE_USAGE);

				// String

				writeString(this.NOM_USAGE, dos);

				// int

				dos.writeInt(this.id_usage);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.CODE_USAGE);

				// String

				writeString(this.NOM_USAGE, dos);

				// int

				dos.writeInt(this.id_usage);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("CODE_USAGE=" + String.valueOf(CODE_USAGE));
			sb.append(",NOM_USAGE=" + NOM_USAGE);
			sb.append(",id_usage=" + String.valueOf(id_usage));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row8Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_7_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row8Struct row8 = new row8Struct();

				/**
				 * [tAdvancedHash_row8 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row8", false);
				start_Hash.put("tAdvancedHash_row8", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row8";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row8");
				}

				int tos_count_tAdvancedHash_row8 = 0;

				// connection name:row8
				// source node:tDBInput_7 - inputs:(after_tFileInputExcel_1) outputs:(row8,row8)
				// | target node:tAdvancedHash_row8 - inputs:(row8) outputs:()
				// linked node: tMap_1 - inputs:(row1,row2,row3,row4,row5,row6,row7,row8,row9)
				// outputs:()

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row8 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.ALL_ROWS;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct> tHash_Lookup_row8 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row8Struct>getLookup(matchingModeEnum_row8);

				globalMap.put("tHash_Lookup_row8", tHash_Lookup_row8);

				/**
				 * [tAdvancedHash_row8 begin ] stop
				 */

				/**
				 * [tDBInput_7 begin ] start
				 */

				ok_Hash.put("tDBInput_7", false);
				start_Hash.put("tDBInput_7", System.currentTimeMillis());

				currentComponent = "tDBInput_7";

				int tos_count_tDBInput_7 = 0;

				org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_7 = org.talend.designer.components.util.mssql.MSSqlUtilFactory
						.getMSSqlGenerateTimestampUtil();

				java.util.List<String> talendToDBList_tDBInput_7 = new java.util.ArrayList();
				String[] talendToDBArray_tDBInput_7 = new String[] { "FLOAT", "NUMERIC", "NUMERIC IDENTITY", "DECIMAL",
						"DECIMAL IDENTITY", "REAL" };
				java.util.Collections.addAll(talendToDBList_tDBInput_7, talendToDBArray_tDBInput_7);
				int nb_line_tDBInput_7 = 0;
				java.sql.Connection conn_tDBInput_7 = null;
				String driverClass_tDBInput_7 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
				java.lang.Class jdbcclazz_tDBInput_7 = java.lang.Class.forName(driverClass_tDBInput_7);
				String dbUser_tDBInput_7 = "talend_user";

				final String decryptedPassword_tDBInput_7 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:E1mx7jlnlPri6bFC9biyjmXpNaKrytOQvBz7MwxYASS3/i7Aci4=");

				String dbPwd_tDBInput_7 = decryptedPassword_tDBInput_7;

				String port_tDBInput_7 = "1433";
				String dbname_tDBInput_7 = "AUTO_DWH";
				String url_tDBInput_7 = "jdbc:sqlserver://" + "DESKTOP-6EEKMMP";
				if (!"".equals(port_tDBInput_7)) {
					url_tDBInput_7 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBInput_7)) {
					url_tDBInput_7 += ";databaseName=" + "AUTO_DWH";
				}
				url_tDBInput_7 += ";appName=" + projectName + ";" + "trustServerCertificate=true";
				String dbschema_tDBInput_7 = "dbo";

				conn_tDBInput_7 = java.sql.DriverManager.getConnection(url_tDBInput_7, dbUser_tDBInput_7,
						dbPwd_tDBInput_7);

				java.sql.Statement stmt_tDBInput_7 = conn_tDBInput_7.createStatement();

				String dbquery_tDBInput_7 = "SELECT [CODE_USAGE]\n      ,[NOM_USAGE]\n      ,[id_usage]\n  FROM [AUTO_DWH].[dbo].[DimUsage]\n";

				globalMap.put("tDBInput_7_QUERY", dbquery_tDBInput_7);
				java.sql.ResultSet rs_tDBInput_7 = null;

				try {
					rs_tDBInput_7 = stmt_tDBInput_7.executeQuery(dbquery_tDBInput_7);
					java.sql.ResultSetMetaData rsmd_tDBInput_7 = rs_tDBInput_7.getMetaData();
					int colQtyInRs_tDBInput_7 = rsmd_tDBInput_7.getColumnCount();

					String tmpContent_tDBInput_7 = null;

					while (rs_tDBInput_7.next()) {
						nb_line_tDBInput_7++;

						if (colQtyInRs_tDBInput_7 < 1) {
							row8.CODE_USAGE = 0;
						} else {

							row8.CODE_USAGE = rs_tDBInput_7.getInt(1);
							if (rs_tDBInput_7.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_7 < 2) {
							row8.NOM_USAGE = null;
						} else {

							tmpContent_tDBInput_7 = rs_tDBInput_7.getString(2);
							if (tmpContent_tDBInput_7 != null) {
								if (talendToDBList_tDBInput_7.contains(
										rsmd_tDBInput_7.getColumnTypeName(2).toUpperCase(java.util.Locale.ENGLISH))) {
									row8.NOM_USAGE = FormatterUtils.formatUnwithE(tmpContent_tDBInput_7);
								} else {
									row8.NOM_USAGE = tmpContent_tDBInput_7;
								}
							} else {
								row8.NOM_USAGE = null;
							}
						}
						if (colQtyInRs_tDBInput_7 < 3) {
							row8.id_usage = 0;
						} else {

							row8.id_usage = rs_tDBInput_7.getInt(3);
							if (rs_tDBInput_7.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}

						/**
						 * [tDBInput_7 begin ] stop
						 */

						/**
						 * [tDBInput_7 main ] start
						 */

						currentComponent = "tDBInput_7";

						tos_count_tDBInput_7++;

						/**
						 * [tDBInput_7 main ] stop
						 */

						/**
						 * [tDBInput_7 process_data_begin ] start
						 */

						currentComponent = "tDBInput_7";

						/**
						 * [tDBInput_7 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_row8 main ] start
						 */

						currentComponent = "tAdvancedHash_row8";

						if (execStat) {
							runStat.updateStatOnConnection(iterateId, 1, 1

									, "row8"

							);
						}

						row8Struct row8_HashRow = new row8Struct();

						row8_HashRow.CODE_USAGE = row8.CODE_USAGE;

						row8_HashRow.NOM_USAGE = row8.NOM_USAGE;

						row8_HashRow.id_usage = row8.id_usage;

						tHash_Lookup_row8.put(row8_HashRow);

						tos_count_tAdvancedHash_row8++;

						/**
						 * [tAdvancedHash_row8 main ] stop
						 */

						/**
						 * [tAdvancedHash_row8 process_data_begin ] start
						 */

						currentComponent = "tAdvancedHash_row8";

						/**
						 * [tAdvancedHash_row8 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_row8 process_data_end ] start
						 */

						currentComponent = "tAdvancedHash_row8";

						/**
						 * [tAdvancedHash_row8 process_data_end ] stop
						 */

						/**
						 * [tDBInput_7 process_data_end ] start
						 */

						currentComponent = "tDBInput_7";

						/**
						 * [tDBInput_7 process_data_end ] stop
						 */

						/**
						 * [tDBInput_7 end ] start
						 */

						currentComponent = "tDBInput_7";

					}
				} finally {
					if (rs_tDBInput_7 != null) {
						rs_tDBInput_7.close();
					}
					if (stmt_tDBInput_7 != null) {
						stmt_tDBInput_7.close();
					}
					if (conn_tDBInput_7 != null && !conn_tDBInput_7.isClosed()) {

						conn_tDBInput_7.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

					}
				}
				globalMap.put("tDBInput_7_NB_LINE", nb_line_tDBInput_7);

				ok_Hash.put("tDBInput_7", true);
				end_Hash.put("tDBInput_7", System.currentTimeMillis());

				/**
				 * [tDBInput_7 end ] stop
				 */

				/**
				 * [tAdvancedHash_row8 end ] start
				 */

				currentComponent = "tAdvancedHash_row8";

				tHash_Lookup_row8.endPut();

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row8");
				}

				ok_Hash.put("tAdvancedHash_row8", true);
				end_Hash.put("tAdvancedHash_row8", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row8 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_7 finally ] start
				 */

				currentComponent = "tDBInput_7";

				/**
				 * [tDBInput_7 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row8 finally ] start
				 */

				currentComponent = "tAdvancedHash_row8";

				/**
				 * [tAdvancedHash_row8 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_7_SUBPROCESS_STATE", 1);
	}

	public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
		final static byte[] commonByteArrayLock_STAR_ASSURANCE_factPrime = new byte[0];
		static byte[] commonByteArray_STAR_ASSURANCE_factPrime = new byte[0];

		public int PK_Fact_Primes;

		public int getPK_Fact_Primes() {
			return this.PK_Fact_Primes;
		}

		public int FK_Police;

		public int getFK_Police() {
			return this.FK_Police;
		}

		public int FK_PointDeVente;

		public int getFK_PointDeVente() {
			return this.FK_PointDeVente;
		}

		public int FK_Produit;

		public int getFK_Produit() {
			return this.FK_Produit;
		}

		public int FK_Pack;

		public int getFK_Pack() {
			return this.FK_Pack;
		}

		public int FK_Usage;

		public int getFK_Usage() {
			return this.FK_Usage;
		}

		public int FK_Quittance;

		public int getFK_Quittance() {
			return this.FK_Quittance;
		}

		public int FK_Date_Emission;

		public int getFK_Date_Emission() {
			return this.FK_Date_Emission;
		}

		public BigDecimal Prime_HT;

		public BigDecimal getPrime_HT() {
			return this.Prime_HT;
		}

		public BigDecimal Prime_Encaissee;

		public BigDecimal getPrime_Encaissee() {
			return this.Prime_Encaissee;
		}

		public BigDecimal Prime_Arriere;

		public BigDecimal getPrime_Arriere() {
			return this.Prime_Arriere;
		}

		public BigDecimal Montant_Partiel;

		public BigDecimal getMontant_Partiel() {
			return this.Montant_Partiel;
		}

		public BigDecimal Restourne_Encaisse;

		public BigDecimal getRestourne_Encaisse() {
			return this.Restourne_Encaisse;
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.PK_Fact_Primes = dis.readInt();

					this.FK_Police = dis.readInt();

					this.FK_PointDeVente = dis.readInt();

					this.FK_Produit = dis.readInt();

					this.FK_Pack = dis.readInt();

					this.FK_Usage = dis.readInt();

					this.FK_Quittance = dis.readInt();

					this.FK_Date_Emission = dis.readInt();

					this.Prime_HT = (BigDecimal) dis.readObject();

					this.Prime_Encaissee = (BigDecimal) dis.readObject();

					this.Prime_Arriere = (BigDecimal) dis.readObject();

					this.Montant_Partiel = (BigDecimal) dis.readObject();

					this.Restourne_Encaisse = (BigDecimal) dis.readObject();

				} catch (IOException e) {
					throw new RuntimeException(e);

				} catch (ClassNotFoundException eCNFE) {
					throw new RuntimeException(eCNFE);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_STAR_ASSURANCE_factPrime) {

				try {

					int length = 0;

					this.PK_Fact_Primes = dis.readInt();

					this.FK_Police = dis.readInt();

					this.FK_PointDeVente = dis.readInt();

					this.FK_Produit = dis.readInt();

					this.FK_Pack = dis.readInt();

					this.FK_Usage = dis.readInt();

					this.FK_Quittance = dis.readInt();

					this.FK_Date_Emission = dis.readInt();

					this.Prime_HT = (BigDecimal) dis.readObject();

					this.Prime_Encaissee = (BigDecimal) dis.readObject();

					this.Prime_Arriere = (BigDecimal) dis.readObject();

					this.Montant_Partiel = (BigDecimal) dis.readObject();

					this.Restourne_Encaisse = (BigDecimal) dis.readObject();

				} catch (IOException e) {
					throw new RuntimeException(e);

				} catch (ClassNotFoundException eCNFE) {
					throw new RuntimeException(eCNFE);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.PK_Fact_Primes);

				// int

				dos.writeInt(this.FK_Police);

				// int

				dos.writeInt(this.FK_PointDeVente);

				// int

				dos.writeInt(this.FK_Produit);

				// int

				dos.writeInt(this.FK_Pack);

				// int

				dos.writeInt(this.FK_Usage);

				// int

				dos.writeInt(this.FK_Quittance);

				// int

				dos.writeInt(this.FK_Date_Emission);

				// BigDecimal

				dos.writeObject(this.Prime_HT);

				// BigDecimal

				dos.writeObject(this.Prime_Encaissee);

				// BigDecimal

				dos.writeObject(this.Prime_Arriere);

				// BigDecimal

				dos.writeObject(this.Montant_Partiel);

				// BigDecimal

				dos.writeObject(this.Restourne_Encaisse);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.PK_Fact_Primes);

				// int

				dos.writeInt(this.FK_Police);

				// int

				dos.writeInt(this.FK_PointDeVente);

				// int

				dos.writeInt(this.FK_Produit);

				// int

				dos.writeInt(this.FK_Pack);

				// int

				dos.writeInt(this.FK_Usage);

				// int

				dos.writeInt(this.FK_Quittance);

				// int

				dos.writeInt(this.FK_Date_Emission);

				// BigDecimal

				dos.writeObject(this.Prime_HT);

				// BigDecimal

				dos.writeObject(this.Prime_Encaissee);

				// BigDecimal

				dos.writeObject(this.Prime_Arriere);

				// BigDecimal

				dos.writeObject(this.Montant_Partiel);

				// BigDecimal

				dos.writeObject(this.Restourne_Encaisse);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PK_Fact_Primes=" + String.valueOf(PK_Fact_Primes));
			sb.append(",FK_Police=" + String.valueOf(FK_Police));
			sb.append(",FK_PointDeVente=" + String.valueOf(FK_PointDeVente));
			sb.append(",FK_Produit=" + String.valueOf(FK_Produit));
			sb.append(",FK_Pack=" + String.valueOf(FK_Pack));
			sb.append(",FK_Usage=" + String.valueOf(FK_Usage));
			sb.append(",FK_Quittance=" + String.valueOf(FK_Quittance));
			sb.append(",FK_Date_Emission=" + String.valueOf(FK_Date_Emission));
			sb.append(",Prime_HT=" + String.valueOf(Prime_HT));
			sb.append(",Prime_Encaissee=" + String.valueOf(Prime_Encaissee));
			sb.append(",Prime_Arriere=" + String.valueOf(Prime_Arriere));
			sb.append(",Montant_Partiel=" + String.valueOf(Montant_Partiel));
			sb.append(",Restourne_Encaisse=" + String.valueOf(Restourne_Encaisse));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row9Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBOutput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBOutput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row9Struct row9 = new row9Struct();

				/**
				 * [tAdvancedHash_row9 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row9", false);
				start_Hash.put("tAdvancedHash_row9", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row9";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row9");
				}

				int tos_count_tAdvancedHash_row9 = 0;

				// connection name:row9
				// source node:tDBOutput_1 - inputs:(after_tFileInputExcel_1)
				// outputs:(row9,row9) | target node:tAdvancedHash_row9 - inputs:(row9)
				// outputs:()
				// linked node: tMap_1 - inputs:(row1,row2,row3,row4,row5,row6,row7,row8,row9)
				// outputs:()

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row9 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.ALL_ROWS;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row9Struct> tHash_Lookup_row9 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row9Struct>getLookup(matchingModeEnum_row9);

				globalMap.put("tHash_Lookup_row9", tHash_Lookup_row9);

				/**
				 * [tAdvancedHash_row9 begin ] stop
				 */

				/**
				 * [tDBOutput_1 begin ] start
				 */

				ok_Hash.put("tDBOutput_1", false);
				start_Hash.put("tDBOutput_1", System.currentTimeMillis());

				currentComponent = "tDBOutput_1";

				int tos_count_tDBOutput_1 = 0;

				int nb_line_tDBOutput_1 = 0;
				int nb_line_update_tDBOutput_1 = 0;
				int nb_line_inserted_tDBOutput_1 = 0;
				int nb_line_deleted_tDBOutput_1 = 0;
				int nb_line_rejected_tDBOutput_1 = 0;

				int deletedCount_tDBOutput_1 = 0;
				int updatedCount_tDBOutput_1 = 0;
				int insertedCount_tDBOutput_1 = 0;
				int rowsToCommitCount_tDBOutput_1 = 0;
				int rejectedCount_tDBOutput_1 = 0;
				String dbschema_tDBOutput_1 = null;
				String tableName_tDBOutput_1 = null;
				boolean whetherReject_tDBOutput_1 = false;

				java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar.getInstance();
				long year1_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_1;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_1 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				int updateKeyCount_tDBOutput_1 = 1;
				if (updateKeyCount_tDBOutput_1 < 1) {
					throw new RuntimeException("For update, Schema must have a key");
				} else if (updateKeyCount_tDBOutput_1 == 13 && true) {
					System.err.println("For update, every Schema column can not be a key");
				}

				java.sql.Connection conn_tDBOutput_1 = null;
				String dbUser_tDBOutput_1 = null;
				dbschema_tDBOutput_1 = "dbo";
				String driverClass_tDBOutput_1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";

				java.lang.Class.forName(driverClass_tDBOutput_1);
				String port_tDBOutput_1 = "1433";
				String dbname_tDBOutput_1 = "AUTO_DWH";
				String url_tDBOutput_1 = "jdbc:sqlserver://" + "DESKTOP-6EEKMMP";
				if (!"".equals(port_tDBOutput_1)) {
					url_tDBOutput_1 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_1)) {
					url_tDBOutput_1 += ";databaseName=" + "AUTO_DWH";

				}
				url_tDBOutput_1 += ";appName=" + projectName + ";" + "trustServerCertificate=true";
				dbUser_tDBOutput_1 = "talend_user";

				final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:tgUSZJAXWAtvW1u2mtXckN3nue71OG+bcC5LAiNk9WYReQvK/wI=");

				String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;
				conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1, dbUser_tDBOutput_1,
						dbPwd_tDBOutput_1);

				resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);

				conn_tDBOutput_1.setAutoCommit(false);
				int commitEvery_tDBOutput_1 = 10000;
				int commitCounter_tDBOutput_1 = 0;

				if (dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
					tableName_tDBOutput_1 = "Fact_Primes";
				} else {
					tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "].[" + "Fact_Primes";
				}
				int count_tDBOutput_1 = 0;

				String update_tDBOutput_1 = "UPDATE [" + tableName_tDBOutput_1
						+ "] SET [FK_Police] = ?,[FK_PointDeVente] = ?,[FK_Produit] = ?,[FK_Pack] = ?,[FK_Usage] = ?,[FK_Quittance] = ?,[FK_Date_Emission] = ?,[Prime_HT] = ?,[Prime_Encaissee] = ?,[Prime_Arriere] = ?,[Montant_Partiel] = ?,[Restourne_Encaisse] = ? WHERE [PK_Fact_Primes] = ?";
				java.sql.PreparedStatement pstmtUpdate_tDBOutput_1 = conn_tDBOutput_1
						.prepareStatement(update_tDBOutput_1);
				resourceMap.put("pstmtUpdate_tDBOutput_1", pstmtUpdate_tDBOutput_1);
				String insert_tDBOutput_1 = "INSERT INTO [" + tableName_tDBOutput_1
						+ "] ([PK_Fact_Primes],[FK_Police],[FK_PointDeVente],[FK_Produit],[FK_Pack],[FK_Usage],[FK_Quittance],[FK_Date_Emission],[Prime_HT],[Prime_Encaissee],[Prime_Arriere],[Montant_Partiel],[Restourne_Encaisse]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
				java.sql.PreparedStatement pstmtInsert_tDBOutput_1 = conn_tDBOutput_1
						.prepareStatement(insert_tDBOutput_1);
				resourceMap.put("pstmtInsert_tDBOutput_1", pstmtInsert_tDBOutput_1);

				/**
				 * [tDBOutput_1 begin ] stop
				 */

				/**
				 * [tDBOutput_1 main ] start
				 */

				currentComponent = "tDBOutput_1";

				row9 = null;
				row9 = null;
				whetherReject_tDBOutput_1 = false;
				int updateFlag_tDBOutput_1 = 0;
				pstmtUpdate_tDBOutput_1.setInt(1, after_tFileInputExcel_1.FK_Police);

				pstmtUpdate_tDBOutput_1.setInt(2, after_tFileInputExcel_1.FK_PointDeVente);

				pstmtUpdate_tDBOutput_1.setInt(3, after_tFileInputExcel_1.FK_Produit);

				pstmtUpdate_tDBOutput_1.setInt(4, after_tFileInputExcel_1.FK_Pack);

				pstmtUpdate_tDBOutput_1.setInt(5, after_tFileInputExcel_1.FK_Usage);

				pstmtUpdate_tDBOutput_1.setInt(6, after_tFileInputExcel_1.FK_Quittance);

				pstmtUpdate_tDBOutput_1.setInt(7, after_tFileInputExcel_1.FK_Date_Emission);

				pstmtUpdate_tDBOutput_1.setBigDecimal(8, after_tFileInputExcel_1.Prime_HT);

				pstmtUpdate_tDBOutput_1.setBigDecimal(9, after_tFileInputExcel_1.Prime_Encaissee);

				pstmtUpdate_tDBOutput_1.setBigDecimal(10, after_tFileInputExcel_1.Prime_Arriere);

				pstmtUpdate_tDBOutput_1.setBigDecimal(11, after_tFileInputExcel_1.Montant_Partiel);

				pstmtUpdate_tDBOutput_1.setBigDecimal(12, after_tFileInputExcel_1.Restourne_Encaisse);

				pstmtUpdate_tDBOutput_1.setInt(13 + count_tDBOutput_1, after_tFileInputExcel_1.PK_Fact_Primes);

				try {
					updateFlag_tDBOutput_1 = pstmtUpdate_tDBOutput_1.executeUpdate();
					updatedCount_tDBOutput_1 = updatedCount_tDBOutput_1 + updateFlag_tDBOutput_1;
					rowsToCommitCount_tDBOutput_1 += updateFlag_tDBOutput_1;
					if (updateFlag_tDBOutput_1 == 0) {

						pstmtInsert_tDBOutput_1.setInt(1, after_tFileInputExcel_1.PK_Fact_Primes);

						pstmtInsert_tDBOutput_1.setInt(2, after_tFileInputExcel_1.FK_Police);

						pstmtInsert_tDBOutput_1.setInt(3, after_tFileInputExcel_1.FK_PointDeVente);

						pstmtInsert_tDBOutput_1.setInt(4, after_tFileInputExcel_1.FK_Produit);

						pstmtInsert_tDBOutput_1.setInt(5, after_tFileInputExcel_1.FK_Pack);

						pstmtInsert_tDBOutput_1.setInt(6, after_tFileInputExcel_1.FK_Usage);

						pstmtInsert_tDBOutput_1.setInt(7, after_tFileInputExcel_1.FK_Quittance);

						pstmtInsert_tDBOutput_1.setInt(8, after_tFileInputExcel_1.FK_Date_Emission);

						pstmtInsert_tDBOutput_1.setBigDecimal(9, after_tFileInputExcel_1.Prime_HT);

						pstmtInsert_tDBOutput_1.setBigDecimal(10, after_tFileInputExcel_1.Prime_Encaissee);

						pstmtInsert_tDBOutput_1.setBigDecimal(11, after_tFileInputExcel_1.Prime_Arriere);

						pstmtInsert_tDBOutput_1.setBigDecimal(12, after_tFileInputExcel_1.Montant_Partiel);

						pstmtInsert_tDBOutput_1.setBigDecimal(13, after_tFileInputExcel_1.Restourne_Encaisse);

						int processedCount_tDBOutput_1 = pstmtInsert_tDBOutput_1.executeUpdate();
						insertedCount_tDBOutput_1 += processedCount_tDBOutput_1;
						rowsToCommitCount_tDBOutput_1 += processedCount_tDBOutput_1;
						nb_line_tDBOutput_1++;
					} else {
						nb_line_tDBOutput_1++;

					}
				} catch (java.lang.Exception e) {
					globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());
					whetherReject_tDBOutput_1 = true;
					nb_line_tDBOutput_1++;

					System.err.println(e.getMessage());
				} finally {

				}
				if (!whetherReject_tDBOutput_1) {
					row9 = new row9Struct();
					row9.PK_Fact_Primes = after_tFileInputExcel_1.PK_Fact_Primes;
					row9.FK_Police = after_tFileInputExcel_1.FK_Police;
					row9.FK_PointDeVente = after_tFileInputExcel_1.FK_PointDeVente;
					row9.FK_Produit = after_tFileInputExcel_1.FK_Produit;
					row9.FK_Pack = after_tFileInputExcel_1.FK_Pack;
					row9.FK_Usage = after_tFileInputExcel_1.FK_Usage;
					row9.FK_Quittance = after_tFileInputExcel_1.FK_Quittance;
					row9.FK_Date_Emission = after_tFileInputExcel_1.FK_Date_Emission;
					row9.Prime_HT = after_tFileInputExcel_1.Prime_HT;
					row9.Prime_Encaissee = after_tFileInputExcel_1.Prime_Encaissee;
					row9.Prime_Arriere = after_tFileInputExcel_1.Prime_Arriere;
					row9.Montant_Partiel = after_tFileInputExcel_1.Montant_Partiel;
					row9.Restourne_Encaisse = after_tFileInputExcel_1.Restourne_Encaisse;
					row9 = new row9Struct();
					row9.PK_Fact_Primes = after_tFileInputExcel_1.PK_Fact_Primes;
					row9.FK_Police = after_tFileInputExcel_1.FK_Police;
					row9.FK_PointDeVente = after_tFileInputExcel_1.FK_PointDeVente;
					row9.FK_Produit = after_tFileInputExcel_1.FK_Produit;
					row9.FK_Pack = after_tFileInputExcel_1.FK_Pack;
					row9.FK_Usage = after_tFileInputExcel_1.FK_Usage;
					row9.FK_Quittance = after_tFileInputExcel_1.FK_Quittance;
					row9.FK_Date_Emission = after_tFileInputExcel_1.FK_Date_Emission;
					row9.Prime_HT = after_tFileInputExcel_1.Prime_HT;
					row9.Prime_Encaissee = after_tFileInputExcel_1.Prime_Encaissee;
					row9.Prime_Arriere = after_tFileInputExcel_1.Prime_Arriere;
					row9.Montant_Partiel = after_tFileInputExcel_1.Montant_Partiel;
					row9.Restourne_Encaisse = after_tFileInputExcel_1.Restourne_Encaisse;
				}
				////////// batch execute by batch size///////
				class LimitBytesHelper_tDBOutput_1 {
					public int limitBytePart1(int counter, java.sql.PreparedStatement pstmt_tDBOutput_1)
							throws Exception {
						try {

							for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
								if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
									break;
								}
								counter += countEach_tDBOutput_1;
							}

						} catch (java.sql.BatchUpdateException e) {
							globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

							int countSum_tDBOutput_1 = 0;
							for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
								counter += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
							}

							System.err.println(e.getMessage());

						}
						return counter;
					}

					public int limitBytePart2(int counter, java.sql.PreparedStatement pstmt_tDBOutput_1)
							throws Exception {
						try {

							for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
								if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
									break;
								}
								counter += countEach_tDBOutput_1;
							}

						} catch (java.sql.BatchUpdateException e) {
							globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

							for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
								counter += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
							}

							System.err.println(e.getMessage());

						}
						return counter;
					}
				}

				//////////// commit every////////////

				commitCounter_tDBOutput_1++;
				if (commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
					if (rowsToCommitCount_tDBOutput_1 != 0) {

					}
					conn_tDBOutput_1.commit();
					if (rowsToCommitCount_tDBOutput_1 != 0) {

						rowsToCommitCount_tDBOutput_1 = 0;
					}
					commitCounter_tDBOutput_1 = 0;
				}

				tos_count_tDBOutput_1++;

				/**
				 * [tDBOutput_1 main ] stop
				 */

				/**
				 * [tDBOutput_1 process_data_begin ] start
				 */

				currentComponent = "tDBOutput_1";

				/**
				 * [tDBOutput_1 process_data_begin ] stop
				 */
// Start of branch "row9"
				if (row9 != null) {

					/**
					 * [tAdvancedHash_row9 main ] start
					 */

					currentComponent = "tAdvancedHash_row9";

					if (execStat) {
						runStat.updateStatOnConnection(iterateId, 1, 1

								, "row9"

						);
					}

					row9Struct row9_HashRow = new row9Struct();

					row9_HashRow.PK_Fact_Primes = row9.PK_Fact_Primes;

					row9_HashRow.FK_Police = row9.FK_Police;

					row9_HashRow.FK_PointDeVente = row9.FK_PointDeVente;

					row9_HashRow.FK_Produit = row9.FK_Produit;

					row9_HashRow.FK_Pack = row9.FK_Pack;

					row9_HashRow.FK_Usage = row9.FK_Usage;

					row9_HashRow.FK_Quittance = row9.FK_Quittance;

					row9_HashRow.FK_Date_Emission = row9.FK_Date_Emission;

					row9_HashRow.Prime_HT = row9.Prime_HT;

					row9_HashRow.Prime_Encaissee = row9.Prime_Encaissee;

					row9_HashRow.Prime_Arriere = row9.Prime_Arriere;

					row9_HashRow.Montant_Partiel = row9.Montant_Partiel;

					row9_HashRow.Restourne_Encaisse = row9.Restourne_Encaisse;

					tHash_Lookup_row9.put(row9_HashRow);

					tos_count_tAdvancedHash_row9++;

					/**
					 * [tAdvancedHash_row9 main ] stop
					 */

					/**
					 * [tAdvancedHash_row9 process_data_begin ] start
					 */

					currentComponent = "tAdvancedHash_row9";

					/**
					 * [tAdvancedHash_row9 process_data_begin ] stop
					 */

					/**
					 * [tAdvancedHash_row9 process_data_end ] start
					 */

					currentComponent = "tAdvancedHash_row9";

					/**
					 * [tAdvancedHash_row9 process_data_end ] stop
					 */

				} // End of branch "row9"

				/**
				 * [tDBOutput_1 process_data_end ] start
				 */

				currentComponent = "tDBOutput_1";

				/**
				 * [tDBOutput_1 process_data_end ] stop
				 */

				/**
				 * [tDBOutput_1 end ] start
				 */

				currentComponent = "tDBOutput_1";

				if (pstmtUpdate_tDBOutput_1 != null) {
					pstmtUpdate_tDBOutput_1.close();
					resourceMap.remove("pstmtUpdate_tDBOutput_1");
				}
				if (pstmtInsert_tDBOutput_1 != null) {
					pstmtInsert_tDBOutput_1.close();
					resourceMap.remove("pstmtInsert_tDBOutput_1");
				}
				resourceMap.put("statementClosed_tDBOutput_1", true);
				if (rowsToCommitCount_tDBOutput_1 != 0) {

				}
				conn_tDBOutput_1.commit();
				if (rowsToCommitCount_tDBOutput_1 != 0) {

					rowsToCommitCount_tDBOutput_1 = 0;
				}
				commitCounter_tDBOutput_1 = 0;
				conn_tDBOutput_1.close();
				resourceMap.put("finish_tDBOutput_1", true);

				nb_line_deleted_tDBOutput_1 = nb_line_deleted_tDBOutput_1 + deletedCount_tDBOutput_1;
				nb_line_update_tDBOutput_1 = nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
				nb_line_inserted_tDBOutput_1 = nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
				nb_line_rejected_tDBOutput_1 = nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;

				globalMap.put("tDBOutput_1_NB_LINE", nb_line_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_UPDATED", nb_line_update_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_DELETED", nb_line_deleted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);

				ok_Hash.put("tDBOutput_1", true);
				end_Hash.put("tDBOutput_1", System.currentTimeMillis());

				/**
				 * [tDBOutput_1 end ] stop
				 */

				/**
				 * [tAdvancedHash_row9 end ] start
				 */

				currentComponent = "tAdvancedHash_row9";

				tHash_Lookup_row9.endPut();

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row9");
				}

				ok_Hash.put("tAdvancedHash_row9", true);
				end_Hash.put("tAdvancedHash_row9", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row9 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBOutput_1 finally ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
						java.sql.PreparedStatement pstmtUpdateToClose_tDBOutput_1 = null;
						if ((pstmtUpdateToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmtUpdate_tDBOutput_1")) != null) {
							pstmtUpdateToClose_tDBOutput_1.close();
						}
						java.sql.PreparedStatement pstmtInsertToClose_tDBOutput_1 = null;
						if ((pstmtInsertToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmtInsert_tDBOutput_1")) != null) {
							pstmtInsertToClose_tDBOutput_1.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_1") == null) {
						java.sql.Connection ctn_tDBOutput_1 = null;
						if ((ctn_tDBOutput_1 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_1")) != null) {
							try {
								ctn_tDBOutput_1.close();
							} catch (java.sql.SQLException sqlEx_tDBOutput_1) {
								String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :"
										+ sqlEx_tDBOutput_1.getMessage();
								System.err.println(errorMessage_tDBOutput_1);
							}
						}
					}
				}

				/**
				 * [tDBOutput_1 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row9 finally ] start
				 */

				currentComponent = "tAdvancedHash_row9";

				/**
				 * [tAdvancedHash_row9 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBOutput_1_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final factPrime factPrimeClass = new factPrime();

		int exitCode = factPrimeClass.runJobInTOS(args);

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		if (inOSGi) {
			java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

			if (jobProperties != null && jobProperties.get("context") != null) {
				contextStr = (String) jobProperties.get("context");
			}
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = factPrime.class.getClassLoader()
					.getResourceAsStream("star_assurance/factprime_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = factPrime.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tFileInputExcel_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputExcel_1) {
			globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", -1);

			e_tFileInputExcel_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : factPrime");
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 297361 characters generated by Talend Open Studio for Data Integration on the
 * 14 juillet 2026 à 10:48:21 WAT
 ************************************************************************************************/